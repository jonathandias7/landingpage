<?php
$Read->ExeRead(DB_LP_PAGES, "WHERE page_name = :name", "name={$URL[0]}");
if ($Read->getResult()):
    extract($Read->getResult()[0]);
    if (!$page_date_start <= date('Y-m-d H:i:s') && !$page_date_and >= date('Y-m-d H:i:s') || !$page_status):
        header("Location: " . BASE);
    endif;
else:
    header("Location: " . BASE . "/404");
endif;
?>
<link rel="stylesheet" href="<?= BASE; ?>/_activepages/style.css"/>
<style>
    .lp_video, .lp_hunter, .lp_author_box header, .lp_book, .lp_confirm_video, .lp_thanks_cta,
    .lp_thanks_video, .lp_gates_video, .lp_gates_videos {
        background-color: #001A66;
        <?= $page_cover ? "background-image: url(" . BASE . "/_activepages/{$page_cover});" : '' ?>
    }
    .lp_social .lead_take .false_bg{
        background: rgba(0,0,0,0.5) left 15px bottom 15px no-repeat
    }

</style>
<script>
    $(document).ready(function () {
        $('b').addClass('color_<?= $page_ac_button_color ?>');

<?php if ($page_ac_type == 2): ?>
            $('input[type=submit]').addClass('btn');
            $('input[type=submit]').addClass('btn_<?= $page_ac_button_color ?>');
            $('input[type=submit]').val('<?= $page_ac_register ?>');
<?php endif; ?>
    });

</script>
<main>
    <?php
    //URL + LEAD $page_gate COOKIE
    $getUrl = filter_input(INPUT_GET, 'url');
    $setUrl = explode("/", $getUrl);
    $getCookie = filter_input(INPUT_COOKIE, "activemail", FILTER_DEFAULT);

    //TRAKING FACEBOOK PIXEL
    $GetFB = filter_input(INPUT_GET, 'fb', FILTER_VALIDATE_INT);
    if ($GetFB):
        $_SESSION['activefb'] = strip_tags(trim($GetFB));
    endif;

    //TRAKING GOOGLE PIXEL
    $GetGi = filter_input(INPUT_GET, 'gi', FILTER_VALIDATE_INT);
    $GetGl = filter_input(INPUT_GET, 'gl', FILTER_DEFAULT);
    if ($GetGi && $GetGl):
        $_SESSION['activegw'] = [strip_tags(trim($GetGi)), strip_tags(trim($GetGl))];
    endif;

    //REDIRECT BY PARAM
    if ($GetGi || $GetGl || $GetFB):
        header("Location: " . BASE . "/{$getUrl}");
    endif;

    //LEAD $page_gate
    if ($page_gate && !empty($setUrl[2]) && filter_var($setUrl[2], FILTER_VALIDATE_EMAIL)):
        $getCookie = true;
        setcookie("activemail", base64_encode($setUrl[2]), strtotime("+3months"), "/");
    endif;

    $gatePages = explode(",", $page_gate_name);

    if ($page_gate && !empty($setUrl[1]) && in_array($setUrl[1], $gatePages) && empty($getCookie)):
        header("location: " . BASE . "/" . $page_name);
    elseif ($page_gate && !empty($setUrl[2]) && filter_var($setUrl[2], FILTER_VALIDATE_EMAIL)):
        setcookie("activemail", base64_encode($setUrl[2]), strtotime("+3months"), "/");
        header("location: " . BASE . "/" . $page_name . "/{$setUrl[1]}");
    endif;

    //QUERY STRING
    $HomePages = explode(",", $page_teste);

    if (empty($setUrl[1])):
        require "_activepages/pages/home.php";
    elseif (in_array($setUrl[1], $HomePages)):
        require "_activepages/pages/home_{$setUrl[1]}.php";
    elseif (file_exists("_activepages/gates/{$setUrl[1]}.php") && !is_dir("_activepages/gates/{$setUrl[1]}.php")):
        if ($page_gate && !$getCookie):
            header("location: " . BASE);
        else:
            require "_activepages/gates/{$setUrl[1]}.php";
        endif;
    else:

        if (file_exists("_activepages/pages/{$setUrl[1]}.php") && !is_dir("_activepages/pages/{$setUrl[1]}.php")):
            require "_activepages/pages/{$setUrl[1]}.php";
        else:
            require $page_index;
        endif;
    endif;
    ?>
</main>

<footer class="ac_main_footer">
    <div class="content">
        <div class="footer_logo">
            <img width="200" src="<?= BASE; ?>/_activepages/<?= $page_logo ?>" alt="<?= $page_headline; ?>" title="<?= $page_headline; ?>"/>
        </div>
        <nav class="footer_terms">
            <ul>
                <li><a target="_blank" href="<?= $page_termos; ?>">Termos de Uso</a></li>
                <li><a target="_blank" href="<?= $page_politicas; ?>">Política de Privacidade</a></li>
                <li><a target="_blank" href="<?= $page_aviso; ?>">Aviso Legal</a></li>
            </ul>
        </nav>
    </div>
    <div class="footer_copy">&COPY; <?= date('Y'); ?> - <?= $page_copyright; ?></div>
</footer>

<!--SCRIPTS-->
<script src="<?= BASE; ?>/_activepages/scripts/jquery.js"></script>
<script src="<?= BASE; ?>/_activepages/scripts/landing.js"></script>
<script src="https://apis.google.com/js/platform.js"></script>

<!-- GOOGLE PIXEL -->
<?php require '_activepages/scripts/tracking_gw.php'; ?>
<?php require '_activepages/scripts/tracking_fb.php'; ?>
