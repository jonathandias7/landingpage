<div class="lp_confirm_video">
    <div class="content">
        <div class="lp_video_content">
            <div class="lp_video_content_yt">
                <div class="embed-container">
                    <?php if (is_numeric($page_video_confirma)): ?>
                            <iframe width="853" height="480" src="https://player.vimeo.com/video/<?= $page_video_confirma; ?>?title=0&amp;byline=0&amp;portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                        <?php else: ?>
                            <iframe width="853" height="480" src="https://www.youtube.com/embed/<?= $page_video_confirma; ?>?rel=0&amp;showinfo=0&amp;autoplay=1" frameborder="0" allowfullscreen></iframe>
                        <?php endif; ?>   
                    <iframe width="853" height="480" src="https://www.youtube.com/embed/<?= $page_video_confirma; ?>?rel=0&amp;showinfo=0&amp;autoplay=1" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<article class="lp_confirm" style="padding: 0;">
    <div class="content">
        <header>
            <img class="lp_confirm_inbox" src="<?= BASE; ?>/_activepages/images/inbox.png" alt="Obrigado por se cadastrar!" title="Obrigado por se cadastrar!"/>
            <h1><?= $page_confirme_title ?></h1>
            <p><?= $page_confirme_headline; ?></p>
        </header>

        <div class="lp_confirm_step">
            <div class="box box3">
                <div class="lp_confirm_step_content">
                    <span class="step rounded bg_<?= $page_ac_button_color; ?>">1</span>
                    <b>Acesse sua conta de e-mail:</b> Enviamos uma mensagem de confirmação para você!
                </div>
            </div><div class="box box3">
                <div class="lp_confirm_step_content">
                    <span class="step rounded bg_<?= $page_ac_button_color; ?>">2</span>
                    <b>Localize a mensagem:</b><?= $page_confirme_subject; ?>
                </div>
            </div><div class="box box3">
                <div class="lp_confirm_step_content">
                    <span class="step rounded bg_<?= $page_ac_button_color; ?>">3</span>
                    <b>Clique no link de confirmação:</b> No corpo do e-mail você deve clicar no link para confirmar!
                </div>
            </div>
        </div>

        <div class="lp_confirm_share">
            <p class="lp_confirm_share_title">Compartilhe com seus amigos:</p><div class="lp_confirm_share_items">
                <iframe src="https://www.facebook.com/plugins/share_button.php?href=<?= BASE; ?>&layout=button_count&size=large&mobile_iframe=true&width=143&height=28" width="156" height="40" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                <iframe src="https://platform.twitter.com/widgets/tweet_button.html?size=l&url=<?= BASE; ?>&via=<?= $page_twitter; ?>&text=<?= strip_tags($page_headline); ?>" width="77" height="40" title="Enviar para o Twitter!" style="border:none;overflow:hidden" frameborder="0" allowTransparency="true"></iframe>
            </div>
        </div>
    </div>
</article>

