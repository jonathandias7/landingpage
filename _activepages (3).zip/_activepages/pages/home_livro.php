<!--MODAL-->
<div class="lpoptin_modal j_optin_modal">
    <div class="lpoptin_modal_box">
        <div class="header bg_<?= $page_ac_button_color; ?>">
            <p><?= $page_headline; ?></p>
            <span class="j_optin_close lpoptin_modal_box_close">X</span>
        </div>
        <?php require '_activepages/require/formac.php'; ?>
    </div>
</div>

<!--OPTIN-->
<div class="lp_book">
    <div class="content">
        <article class="lp_book_optin">
            <div class="lp_book_book">
                <img src="<?= BASE; ?>/tim.php?src=_activepages/<?= $page_ebook_img ?>&w=250&h=350" alt="<?= $page_headline; ?>" title="<?= $page_headline; ?>"/>
            </div><header>
                <h1><?= $page_headline; ?></h1>
                <p class="tagline"><?= $page_tag_copy; ?></p>
                <?php
                if ($page_button):
                    $Section['section_button'] = $page_button;
                    require '_activepages/require/button.php';
                endif;
                ?>
            </header>
        </article>
    </div>
</div>
<?php if ($page_fb_page): ?>
<div class="lp_thanks_social">
    <div class="content">
        <p>Curta e acompanhe novidades no facebook</p>
        <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2F<?= $page_fb_page; ?>&width=420&layout=standard&action=like&size=small&show_faces=true&share=true&height=80" width="420" height="56" style="border:none; overflow:hidden; max-width: 80%;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
    </div>
</div>
<?php endif; ?>
