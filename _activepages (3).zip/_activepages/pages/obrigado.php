<?php

require "_activepages/pages/" . $page_tankyou . ".php";


$Read->ExeRead(DB_LP_SECTIONS, "WHERE section_status = 1 AND section_page = :id AND section_obrigado = 1 ORDER BY section_order", "id={$page_id}");

if ($Read->getResult()):
    require "_activepages/require/sessoes.php";
endif;

echo "<script>fbq('track', 'Lead');</script>";