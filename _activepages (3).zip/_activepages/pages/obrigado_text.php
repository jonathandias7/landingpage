<article class="lp_thanks_text">
    <div class="content">
        <header>
            <img class="lp_confirm_inbox" src="<?= BASE; ?>/_activepages/images/check.png" alt="Obrigado por se cadastrar!" title="Obrigado por se cadastrar!"/>
            <h1><?= $page_tanks_title ?></h1>
            <p><?= $page_tanks_content ?></p>
        </header>

        <a class="btn_link btn btn_<?= $page_ac_button_color ?>" href="<?= $page_tanks_link ?>" title="<?= $page_tanks_cta ?>"><?= $page_tanks_cta ?></a>
    </div>
</article>

<?php if ($page_fb_page): ?>
<div class="lp_thanks_social" style="background: #fff;">
    <div class="content">
        <p>Curta e acompanhe novidades no facebook</p>
        <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2F<?= $page_fb_page; ?>&width=420&layout=standard&action=like&size=small&show_faces=true&share=true&height=80" width="420" height="56" style="border:none; overflow:hidden; max-width: 80%;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
    </div>
</div>
<?php endif; ?>