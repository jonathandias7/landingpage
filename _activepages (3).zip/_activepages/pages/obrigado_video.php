<div class="lp_thanks_video">
    <div class="content">
        <div class="lp_thanks_video_box">
            <div class="lp_video_content_yt">
                <div class="embed-container">

                    <?php if (is_numeric($page_video_obrigado)): ?>
                        <iframe width="853" height="480" src="https://player.vimeo.com/video/<?= $page_video_obrigado; ?>?title=0&amp;byline=0&amp;portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                    <?php else: ?>
                        <iframe width="853" height="480" src="https://www.youtube.com/embed/<?= $page_video_obrigado; ?>?rel=0&amp;showinfo=0&amp;autoplay=1" frameborder="0" allowfullscreen></iframe>
                    <?php endif; ?>   
                </div>
            </div>

            <a class="btn_link btn btn_<?= $page_ac_button_color ?>" href="<?= $page_tanks_link; ?>" title="<?= $page_tanks_cta ?>"><?= $page_tanks_cta ?></a>
        </div>
    </div>
</div>

<?php if ($page_fb_page): ?>
    <div class="lp_thanks_social" style="background: #fff;">
        <div class="content">
            <p>Curta e acompanhe novidades no facebook</p>
            <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2F<?= $page_fb_page; ?>&width=420&layout=standard&action=like&size=small&show_faces=true&share=true&height=80" width="420" height="56" style="border:none; overflow:hidden; max-width: 80%;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
        </div>
    </div>
<?php endif; ?>