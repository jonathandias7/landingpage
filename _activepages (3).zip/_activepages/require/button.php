<?php
if ($Section['section_button'] == 1):
    ?>
    <div class="section_button">
        <span class="j_optin btn btn_<?= $page_ac_button_color; ?>"><?= $page_ac_button; ?></span>
    </div>
    <?php
elseif ($Section['section_button'] == 2):
    ?>

    <?php
    if ($page_venda_type == 1):
        if ($page_venda_hotlink):
            echo "<a class='btn_link btn " . (!empty($page_ac_button_color) ? 'btn_' . $page_ac_button_color : 'btn_green') . "' href='{$page_venda_hotlink}' title='{$page_venda_button}'>{$page_venda_button}</a>";
        elseif ($page_venda_pdt):
            $Read->ExeRead(DB_PDT, "WHERE pdt_id = :id", "id={$page_venda_pdt}");
            extract($Read->getResult()[0]);
            $Read->FullRead("SELECT stock_id, stock_code FROM " . DB_PDT_STOCK . " WHERE pdt_id = :id", "id={$pdt_id}");
            if ($Read->getResult()[0]['stock_code'] == 'default'):
                ?>
                <form class="wc_cart_add" style="width: 100%;" name="cart_add" method="post" enctype="multipart/form-data">
                    <input name="pdt_id" type="hidden" value="<?= $pdt_id; ?>"/>
                    <input name="stock_id" type="hidden" value="<?= $Read->getResult()[0]['stock_id']; ?>"/>
                    <input name="item_amount" type="hidden" value="1"/>
                    <button style="max-width: 100%;margin-left: 0;" class="btn <?= (!empty($page_ac_button_color) ? 'btn_' . $page_ac_button_color : 'btn_green'); ?>"><?= $page_venda_button; ?></button>
                </form>
                <?php
            else:
                $wcPdtLink = (!empty($pdt_hotlink) ? $pdt_hotlink : BASE . "/produto/{$pdt_name}");
                echo "<a class='btn_link btn " . (!empty($page_ac_button_color) ? 'btn_' . $page_ac_button_color : 'btn_green') . "' href='{$wcPdtLink}' title='Ver detalhes de {$pdt_title}'>VER DETALHES</a>";

            endif;
        endif;


    elseif ($page_venda_type == 2):
        if ($page_venda_hotlink):
            echo "<a class='btn_link btn " . (!empty($page_ac_button_color) ? 'btn_' . $page_ac_button_color : 'btn_green') . "' href='{$page_venda_hotlink}' title='{$page_venda_button}'>{$page_venda_button}</a>";
        elseif ($page_venda_curso):
            $Read->ExeRead(DB_EAD_COURSES, "WHERE course_id = :id", "id={$page_venda_curso}");
            extract($Read->getResult()[0]);
            ?>
            <a href="<?= $course_vendor_checkout ?>" class="btn <?= (!empty($page_ac_button_color) ? 'btn_' . $page_ac_button_color : 'btn_green') ?>"><?= $page_venda_button; ?></a>
            <?php
        endif;
    endif;
    ?>
    <?php
elseif ($Section['section_button'] == 3):
    $CartBtn = 'btn_' . $page_ac_button_color;
    ?>
    <a target="_blank" href="<?= $page_download_url ?>" class="btn_link btn <?= (!empty($page_ac_button_color) ? 'btn_' . $page_ac_button_color : 'btn_green') ?>"><?= $page_download_button; ?></a>
    <?php

endif;