<div id="optin">
    <?php if ($page_ac_type == 1): ?>
        <form action='//<?= $page_ac_host; ?>.activehosted.com/proc.php' method='post' id='_form_<?= $page_ac_form; ?>' accept-charset='utf-8' enctype='multipart/form-data'>
            <input type="hidden" name="u" value="<?= $page_ac_form; ?>" />
            <input type="hidden" name="f" value="<?= $page_ac_form; ?>" />
            <input type="hidden" name="s" />
            <input type="hidden" name="c" value="0" />
            <input type="hidden" name="m" value="0" />
            <input type="hidden" name="act" value="sub" />
            <input type="hidden" name="v" value="2" />
            <?php
            $Read->ExeRead(DB_LP_INPUTS, "WHERE input_page = :id", "id={$page_id}");
            $OPTIIN['ac_inputs'] = $Read->getResult();

            foreach ($OPTIIN['ac_inputs'] as $acInputs):
                $Required = $acInputs['input_required'] ? "required" : "";
                echo "<input class='{$acInputs['input_class']}' type='{$acInputs['input_type']}' name='{$acInputs['input_name']}' placeholder='{$acInputs['input_placeholder']}' {$Required} />";
            endforeach;
            ?>
            <button class="btn_<?= $page_ac_button_color ?>"><?= $page_ac_register; ?></button>
        </form>
        <?php
    elseif ($page_ac_type == 2):
        echo $page_ac_code;
    endif;
    ?>
    <p class="termos">Também Odiamos Spam!</p>
</div>

