<div class="testimony">
    <div class="testimony_content">
        <span class="testimony_close">X</span>
        <h1>Assistir Depoimento:</h1>
        <div class="embed-container"></div>

        <div class="content_like">
            <div class="box_like box box2">
                <p>Curta no Facebook</p>
                <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2F<?= $page_fb_page; ?>&width=240&layout=standard&action=like&size=small&show_faces=false&share=true&height=28" width="240" height="28" style="border:none; overflow:hidden; max-width: 80%;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
            </div><div class="box_like box box2">
                <p>Inscreva-se no YouTube</p>
                <div class="g-ytsubscribe" data-channelid="<?= $page_yt_channel; ?>" data-layout="full" data-count="default"></div>
            </div>
        </div>
    </div>
</div>

<?php
foreach ($Read->getResult() as $Video):
    ?><article id="<?= $Video['video_yt_id'] ?>" class="lead_take box box4 testimony_start">
        <div class="thumb">
            <?php
            $video = null;
            if (is_numeric($Video['video_yt_id'])):
                $video = unserialize(file_get_contents("http://vimeo.com/api/v2/video/{$Video['video_yt_id']}.php"));
            endif;
            ?>
            <img src="<?= $video ? $video[0]['thumbnail_large'] : "https://i1.ytimg.com/vi/{$Video['video_yt_id']}/mqdefault.jpg" ?>" alt="<?= $Video['video_user']; ?>" title="<?= $Video['video_user']; ?>"/>
            <div class="false_bg take_play"></div>
        </div>
        <h1><b><?= $Video['video_user'] ?></b> <?= $Video['video_desc'] ?></h1>
        <span class="take_play color_<?= $page_ac_button_color; ?>">Assistir Vídeo!</span>
    </article><?php
endforeach;
?>