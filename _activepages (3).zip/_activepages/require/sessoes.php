<?php
foreach ($Read->getResult() as $Section):
    switch ($Section['section_type']):
        case 1:
            $InstaId = $Section['insta_id'];
            $InstaToken = $Section['insta_token'];
            $Instagram = new Instagram($InstaId, $InstaToken);
            $InstaArray = $Instagram->getRecent();
            if (!empty($InstaArray->meta->code) && $InstaArray->meta->code == 200):
                echo "<section class='wc_conversion_insta'>";
                echo "<h1 class='wc_conversion_insta_title'><a target='_blank' href='https://www.instagram.com/" . SITE_SOCIAL_INSTAGRAM . "' title='" . $Section['section_title'] . " no Instagram!'><b>" . $Section['section_title'] . "</b> no Instagram!</a></h1>";
                echo "<div class='wc_conversion_insta_blur'></div>";
                foreach ($InstaArray->data as $InstaPost):
                    $InstaText = (!empty($InstaPost->caption->text) ? $InstaPost->caption->text : 'Imagem de ' . $Section['section_title'] . ' no Instagram!');
                    echo "<article><h1 class='site_title'>{$InstaText}</h1><img alt='{$InstaText}' title='{$InstaText}' width='100%' src='{$InstaPost->images->thumbnail->url}'/></article>";
                endforeach;

                if ($Section['section_button']):
                    require '_activepages/require/button.php';
                endif;


                echo "</section>";
            else:
                Erro('<div class="content" style="text-align:center"><b>INDEX.php//138</b> Configure o Instagram Aqui!</div>');
            endif;
            break;
        case 2:
            $Read->ExeRead(DB_LP_GALLERY_CAT, "WHERE cat_section = :id AND cat_status = 1", "id={$Section['section_id']}");
            if ($Read->getResult()):
                ?>
                <section class="lp_social lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content">
                        <header class="section_header">
                            <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </header>
                        <div class="gallery_cat">
                            <?php
                            $d = 0;
                            foreach ($Read->getResult() as $Cat):
                                $d++;
                                if ($d == 1):
                                    $CatAtiva = $Cat['cat_id'];
                                endif;
                                ?>
                                <a class="cat" href="" id="<?= $Cat['cat_id'] ?>"><?= $Cat['cat_title'] ?></a>
                                <?php
                            endforeach;
                            ?>
                        </div>
                        <div class="gallery_img">
                            <?php
                            $Read->ExeRead(DB_LP_GALLERY . "," . DB_LP_GALLERY_CAT, "WHERE cat_section = :id AND cat_status = 1 AND gallery_cat = cat_id", "id={$Section['section_id']}");
                            if ($Read->getResult()):
                                $i = 0;
                                foreach ($Read->getResult() as $Galeria):
                                    $i++;
                                    $tamanho = 250;
                                    $cls = '';
                                    if ($Galeria['cat_id'] != $CatAtiva):
                                        $cls = 'style="display: none;"';
                                    endif;
                                    echo "<a rel='shadowbox[img{$Galeria['cat_id']}]' class='cat_{$Galeria['cat_id']}' {$cls} title='{$Galeria['gallery_title']} - Foto {$i}' href='" . BASE . "/_activepages/{$Galeria['gallery_cover']}'>
                                       <img title='{$Galeria['gallery_title']} - Foto {$i}' alt='{$Galeria['gallery_title']} - Foto {$i}' src='" . BASE . "/tim.php?src=_activepages/{$Galeria['gallery_cover']}&w=" . $tamanho . "&h=" . $tamanho . "'/>
                                    </a>";
                                endforeach;
                            endif;
                            ?>
                        </div>

                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                    </div>
                </section>
                <?php
            endif;
            ?>
            <style>
                .gallery_cat{
                    text-align: center;
                    padding: 15px;
                }

                .gallery_cat a{
                    text-decoration: none;
                }
                .gallery_img{
                    text-align: center;
                    padding: 15px 0;
                }

                .gallery_cat .cat{
                    color: #fff !important;
                    font-size: 14px;
                    padding: 10px 22px;
                    display: inline-block;
                    text-shadow: none;
                    outline: none;
                    font-weight: 500;
                    text-transform: uppercase;
                    margin-right: 8px;
                    border-radius: 5px;
                    background: transparent !important;
                    border: 1px solid #fff;
                    -webkit-transition: all 0.3s ease 0s;
                    transition: all 0.3s ease 0s;
                    cursor: pointer;
                }

                .gallery_cat .cat.active, .gallery_cat .cat:hover, .gallery_cat .cat:focus {
                    background: #FF8C00 !important;
                    color: #ffffff !important;
                }

                .gallery_img img{
                    border-radius: 10px;
                    margin: 5px 0;
                }
            </style>
            <script>
                $('.cat').click(function () {
                    console.info('Aqui');
                    $('.gallery_img').find('a').fadeOut(0);
                    $('.gallery_img').find('.cat_' + $(this).attr('id')).fadeIn(500);

                    return false;
                });
            </script>
            <?php
            break;
        case 3:
            $Read->ExeRead(DB_LP_VIDEOS, "WHERE video_section = :pg", "pg={$Section['section_id']}");

            if ($Read->getResult()):
                ?>
                <!--SOCIAL-->
                <section class="lp_social lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content">
                        <header class="section_header">
                            <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </header>
                        <?php require '_activepages/require/reviews.php'; ?>
                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                    </div>
                </section>
                <?php
            endif;
            break;
        case 4:
            $Read->ExeRead(DB_LP_DEPOIMENTOS, "WHERE depoimento_section = :pg", "pg={$Section['section_id']}");
            if ($Read->getResult()):
                ?>

                <section class="wc_depoimento_content lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content">
                        <header class="section_header">
                            <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </header>

                        <?php
                        $cont = 0;
                        foreach ($Read->getResult() as $Depoimento):
                            extract($Depoimento);

                            $ativo = $cont == 0 ? 'depoimento_ativo' : '';
                            ?>
                            <div class="desc depoimentos depoimento_<?= $depoimento_id; ?> <?= $ativo ?>">

                                <p style="<?= $Section['section_text_color'] ? 'color:' . $Section['section_text_color'] . ';' : '' ?>"><b>"</b><?= $depoimento_text ?><b>"</b></p>
                                <p style="<?= $Section['section_text_color'] ? 'color:' . $Section['section_text_color'] . ';' : '' ?>" class="depoimento_user">  <?= $depoimento_user ?>  </p>
                            </div>
                            <?php
                            $cont++;
                        endforeach;
                        ?>
                        <div class="depoimento_paginas">
                            <?php
                            for ($i = 0; $i < $Read->getRowCount(); $i++):
                                $ativo = $i == 0 ? ' open' : '';
                                $rel = '0';
                                ?>
                                <span class="dopoimento_page<?= $ativo ?>" rel="<?= 6 ?>" id="<?= $Read->getResult()[$i]['depoimento_id']; ?>"  ></span>
                                <?php
                            endfor;
                            ?>
                        </div>
                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                        <div class="clear"></div>
                    </div>
                </section>
                <?php
            endif;
            break;
        case 5:
            $Read->ExeRead(DB_LP_VIDEOS, "WHERE video_section = :id", "id={$Section['section_id']}");
            $GATES['video'] = $Read->getResult()[0]['video_yt_id'];
            ?>
            <div class="lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                <div class="content">
                    <header class="section_header">
                        <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                        <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                    </header>
                    <div class="lp_gates_videos_content" style="background: #ccc;">
                        <div class="lp_gates_videos_content_yt">
                            <div class="embed-container">

                                <?php if (is_numeric($GATES['video'])): ?>
                                    <iframe class="j_play_this" width="853" height="480" src="https://player.vimeo.com/video/<?= $GATES['video']; ?>?title=0&amp;byline=0&amp;portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                                <?php else: ?>
                                    <iframe class="j_play_this" width="853" height="480" src="https://www.youtube.com/embed/<?= $GATES['video']; ?>?showinfo=0&amp;rel=0" frameborder="0" allowfullscreen></iframe>
                                <?php endif; ?>
            <!--<iframe class="j_play_this" width="853" height="480" src="https://www.youtube.com/embed/<?= $GATES['video']; ?>?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>-->
                            </div>
                        </div><nav class="lp_gates_videos_content_nav">
                            <?php
                            $vCount = 0;
                            $vActive = 0;
                            foreach ($Read->getResult() as $Launch):
                                $vCount ++;
                                $vActive ++;
                                $vStatus = (date("Y-m-d") >= $Launch['video_date'] ? "DIPOSNÍVEL" : date("d/m", strtotime($Launch['video_date'])));
                                ?>
                                <article class="lp_gates_videos_content_nav_item <?= $vActive == 1 ? "active_item bg_{$page_ac_button_color}" : ""; ?> j_launch_play" rel="<?= is_numeric($Launch['video_yt_id']) ? 'vimeo' : '' ?>" color="bg_<?= $page_ac_button_color ?>" id="<?= $vStatus == "DIPOSNÍVEL" ? $Launch['video_yt_id'] : null; ?>">
                                    <div class="thumb">

                                        <?php
                                        $video = null;
                                        if (is_numeric($Launch['video_yt_id'])):
                                            $video = unserialize(file_get_contents("https://vimeo.com/api/v2/video/{$Launch['video_yt_id']}.php"));
                                        endif;
                                        ?>

                                        <img src="<?= $video ? $video[0]['thumbnail_medium'] : "https://i1.ytimg.com/vi/{$Launch['video_yt_id']}/mqdefault.jpg" ?>" alt="<?= $Launch['video_user']; ?>" title="<?= $Launch['video_user']; ?>"/>
                                        <?php
                                        if ($vStatus != "DIPOSNÍVEL"):
                                            echo "<div class='false_bg'></div>";
                                        endif;
                                        ?>
                                    </div><div class="info">
                                        <?php
                                        if ($vStatus != "DIPOSNÍVEL"):
                                            echo "<p>{$Launch['video_user']}</p>";
                                            $vHolder = null;
                                        else:
                                            echo "<p>{$Launch['video_user']}</p>";
                                            $vHolder = "active color_{$page_ac_button_color}";
                                        endif;
                                        ?>
                                        <h1 class="<?= $vHolder; ?>"><?= $Launch['video_user']; ?></h1>
                                    </div>
                                </article>
                                <?php
                            endforeach;
                            ?>
                        </nav>
                    </div>
                    <?php
                    if ($Section['section_button']):
                        require '_activepages/require/button.php';
                    endif;
                    ?>
                </div>
            </div>

            <?php
            break;
        case 6:
            ?>
            <div class="container main_content lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                <div class="content">
                    <header class="section_header">
                        <h2 style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                        <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                    </header>
                    <?php
                    $Read->ExeRead(DB_LP_POSTS, "WHERE post_section = :id", "id={$Section['section_id']}");
                    if (!$Read->getResult()):
                        $Pager->ReturnPage();
                        echo Erro("Ainda não existe posts cadastrados. Por favor, volte mais tarde :)", E_USER_NOTICE);
                    else:
                        foreach ($Read->getResult() as $PostSection):
                            $Read->ExeRead(DB_POSTS, "WHERE post_id = :id", "id={$PostSection['post_id']}");
                            $Post = $Read->getResult()[0];
                            extract($Post);

                            $Read->ExeRead(DB_USERS, "WHERE user_id = :id", "id={$post_author}");
                            $User = $Read->getResult()[0];
                            $Read->ExeRead(DB_CATEGORIES, "WHERE category_id = :id", "id={$post_category}");
                            $Cat = $Read->getResult()[0];
                            $Read->ExeRead(DB_COMMENTS, "WHERE post_id = :id", "id={$post_id}");
                            $Comments = $Read->getRowCount();
                            ?>
                            <article class="box box3 post_list">
                                <div class="post_list_thumb">
                                    <a title="<?= $post_title ?>" href="<?= BASE ?>/artigo/<?= $post_name ?>">
                                        <img src="<?= BASE ?>/tim.php?src=uploads/<?= $post_cover ?>&w=480&h=270" alt="<?= $post_title ?>" title="<?= $post_title ?>">
                                    </a>
                                </div>
                                <div class="post_list_content jup_normalize_height_content" style="height: 229px;">
                                    <span class="post_list_breadcrumb">Em: <a href="<?= BASE ?>/artigos/<?= $Cat['category_name'] ?>" title="Mais em <?= $Cat['category_title'] ?>"><?= $Cat['category_title'] ?></a></span>
                                    <h2><a title="<?= $post_title ?>" href="<?= BASE ?>/artigo/<?= $post_name ?>"><?= $post_title ?></a></h2>
                                    <p><?= $post_subtitle ?></p>
                                </div>
                                <div class="post_list_author">
                                    <div class="post_list_author_info">
                                        <img class="post_list_author_info_thumb rounded" src="<?= BASE ?>/tim.php?src=uploads/<?= $User['user_thumb'] ?>&w=250&h=250" alt="Por <?= $User['user_name'] . " " . $User['user_lastname'] ?>" title="Por <?= $User['user_name'] . " " . $User['user_lastname'] ?>"><span class="post_list_author_info_name"><?= $User['user_name'] . " " . $User['user_lastname'] ?></span>
                                    </div><span class="post_list_author_date"><span class="post_list_comments icon-bubble"><?= $Comments ?></span> <?= date('d/m/Y', strtotime($post_date)) ?></span>
                                </div>
                            </article>
                            <?php
                        endforeach;
                    endif;
                    if ($Section['section_button']):
                        require '_activepages/require/button.php';
                    endif;
                    ?>
                    <div class="clear"></div>
                </div>
            </div>
            <?php
            break;
        case 7:

            if ($Section['section_promo_type'] == 1):
                $Read->ExeRead(DB_PDT, "WHERE pdt_id = :id", "id={$Section['section_pdt']}");
                extract($Read->getResult()[0]);
                ?>
                <section class="course_offer lp_section" id="offer" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content" style="<?= $Section['section_text_color'] ? 'color:' . $Section['section_text_color'] . ';' : '' ?>" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
                        <div class="course_offer_header">
                            <span class="icon-checkmark icon-notext"></span>
                            <h2 style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </div>
                        <div class="course_offer_price" itemprop="price">
                            <?php
                            $PdtPrice = null;
                            if ($pdt_offer_price && $pdt_offer_start <= date('Y-m-d H:i:s') && $pdt_offer_end >= date('Y-m-d H:i:s')):
                                $PdtPrice = $pdt_offer_price;
                                echo '<p class="lol">De <strike>' . number_format($pdt_price, '2', ',', '.') . '</strike> por</p>';
                            else:
                                $PdtPrice = $pdt_price;
                            endif;

                            if (ECOMMERCE_PAY_SPLIT):
                                $MakeSplit = intval($PdtPrice / ECOMMERCE_PAY_SPLIT_MIN);
                                $NumSplit = (!$MakeSplit ? 1 : ($MakeSplit && $MakeSplit <= ECOMMERCE_PAY_SPLIT_NUM ? $MakeSplit : ECOMMERCE_PAY_SPLIT_NUM));
                                if ($NumSplit <= ECOMMERCE_PAY_SPLIT_ACN):
                                    $SplitPrice = number_format(($PdtPrice / $NumSplit), '2', ',', '.');
                                elseif ($NumSplit - ECOMMERCE_PAY_SPLIT_ACN == 1):
                                    $SplitPrice = number_format(($PdtPrice * (pow(1 + (ECOMMERCE_PAY_SPLIT_ACM / 100), $NumSplit - ECOMMERCE_PAY_SPLIT_ACN)) / $NumSplit), '2', ',', '.');
                                else:
                                    $ParcSj = round($PdtPrice / $NumSplit, 2); // Valor das parcelas sem juros
                                    $ParcRest = (ECOMMERCE_PAY_SPLIT_ACN > 1 ? $NumSplit - ECOMMERCE_PAY_SPLIT_ACN : $NumSplit);
                                    $DiffParc = round(($PdtPrice * getFactor($ParcRest) * $ParcRest) - $PdtPrice, 2);
                                    $SplitPrice = number_format($ParcSj + ($DiffParc / $NumSplit), '2', ',', '.');
                                endif;
                                echo '<p class="pay">' . $NumSplit . ' x de ' . $SplitPrice . ' <span>Ou apenas ' . number_format($PdtPrice, '2', ',', '.') . ' à vista!</span></p>';
                            endif;
                            ?>


                        </div>

                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                    </div>
                </section>

                <?php
            elseif ($Section['section_promo_type'] == 2):
                $Read->ExeRead(DB_EAD_COURSES, "WHERE course_id = :id", "id={$Section['section_curso']}");
                if ($Read->getResult()):
                    extract($Read->getResult()[0]);
                    ?>
                    <section class="course_offer lp_section" id="offer" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                        <div class="content" style="<?= $Section['section_text_color'] ? 'color:' . $Section['section_text_color'] . ';' : '' ?>" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
                            <div class="course_offer_header">
                                <span class="icon-checkmark icon-notext"></span>
                                <h2 style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                                <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                            </div>
                            <div class="course_offer_price" itemprop="price">
                                <?php
                                $PdtPrice = $Section['section_promo_price'];
                                if (ECOMMERCE_PAY_SPLIT):
                                    $MakeSplit = intval($PdtPrice / $Section['section_promo_parcelas']);
                                    $NumSplit = $Section['section_promo_parcelas'];

                                    $SplitPrice = number_format(($PdtPrice / $NumSplit), '2', ',', '.');

                                endif;
                                echo '<p class="lol">De <strike>' . number_format($course_vendor_price, '2', ',', '.') . '</strike> por</p>';
                                echo '<p class="pay">' . $NumSplit . ' x de ' . $SplitPrice . ' <span>Ou apenas ' . number_format($Section['section_promo_price'], '2', ',', '.') . ' à vista!</span></p>';
                                ?>
                            </div>

                            <?php
                            if ($Section['section_button']):
                                require '_activepages/require/button.php';
                            endif;
                            ?>
                        </div>
                    </section>
                    <?php
                endif;
            elseif ($Section['section_promo_type'] == 3):
                ?>
                <section class="course_offer lp_section" id="offer" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content" style="<?= $Section['section_text_color'] ? 'color:' . $Section['section_text_color'] . ';' : '' ?>" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
                        <div class="course_offer_header">
                            <span class="icon-checkmark icon-notext"></span>
                            <h2 style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </div>
                        <div class="course_offer_price" itemprop="price">
                            <?php
                            $PdtPrice = $Section['section_promo_price'];
                            if (ECOMMERCE_PAY_SPLIT):
                                $MakeSplit = intval($PdtPrice / $Section['section_promo_parcelas']);
                                $NumSplit = $Section['section_promo_parcelas'];

                                $SplitPrice = number_format(($PdtPrice / $NumSplit), '2', ',', '.');

                            endif;
                            echo '<p class="lol">De <strike>' . number_format($Section['section_price'], '2', ',', '.') . '</strike> por</p>';
                            echo '<p class="pay">' . $NumSplit . ' x de ' . $SplitPrice . ' <span>Ou apenas ' . number_format($Section['section_promo_price'], '2', ',', '.') . ' à vista!</span></p>';
                            ?>
                        </div>

                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                    </div>
                </section>
                <?php
            endif;
            break;
        case 8:
            $Read->ExeRead(DB_LP_PERGUNTAS, "WHERE pergunta_section = :id", "id={$Section['section_id']}");
            if ($Read->getResult()):
                ?>
                <section class="lp_section club_section club_faq course_faq" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content">
                        <header class="section_header">
                            <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </header>
                        <?php foreach ($Read->getResult() as $Faq): ?>
                            <div class="box box2">
                                <article class="club_faq_question wc_accordion">
                                    <h3 class="icon-plus"><?= $Faq['pergunta_title'] ?></h3>
                                    <div class="club_faq_question_content wc_accordion_toogle htmlchars">
                                        <?= $Faq['pergunta_resposta'] ?>
                                    </div>
                                </article>
                            </div>
                        <?php endforeach; ?>

                        <!--CLIQUE AQUI e confira a lista de cursos! [ABRIR FULLW BRANCA COM TODOS OS CURSOS DO CLUB]-->
                    </div>

                    <?php
                    if ($Section['section_button']):
                        require '_activepages/require/button.php';
                    endif;
                    ?>
                </section>
                <?php
            endif;
            break;
        case 9:
            $Read->ExeRead(DB_LP_SERVICE, "WHERE service_section = :id", "id={$Section['section_id']}");
            if ($Read->getResult()):
                ?>
                <section class="lp_section lp_service" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content">
                        <header class="section_header">
                            <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </header>

                        <?php
                        foreach ($Read->getResult() as $Ser):
                            ?>
                            <article class="box box4 course_stats" style="<?= $Section['section_text_color'] ? 'color:' . $Section['section_text_color'] . ';' : '' ?>">
                                <span class="<?= $Ser['service_icon'] ?>"></span>
                                <h3><?= $Ser['service_title'] ?></h3>
                                <p><?= $Ser['service_desc'] ?></p>
                            </article>
                            <?php
                        endforeach;
                        ?>

                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                    </div>
                </section>

                <?php
            endif;
            break;
        case 10:
            $Read->ExeRead(DB_LP_SOBRE, "WHERE sobre_section = :pg", "pg={$Section['section_id']}");
            if ($Read->getResult()):
                $Sobre = $Read->getResult()[0];
                ?>
                <!--DESCRIÇÃO-->
                <section class="lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content wc_bio">

                        <header class="section_header">
                            <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </header>

                        <img title="<?= SITE_NAME; ?> Sobre" style='border-radius:none;' alt="<?= SITE_NAME; ?> Sobre"
                             src="<?= BASE; ?>/_activepages/<?= $Sobre['sobre_cover'] ?>"/><div class="htmlchars bio_content">
                                 <?= $Sobre['sobre_desc']; ?>
                            <div class="clear"></div>
                        </div>
                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                    </div>
                </section>
                <?php
            endif;
            break;
        case 11:
            $Read->ExeRead(DB_LP_AUTOR, "WHERE autor_section = :pg", "pg={$Section['section_id']}");
            $Autor = $Read->getResult()[0];
            ?>
            <!--AUTHOR-->
            <article class="lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                <div class="content">
                    <header class="section_header">
                        <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                        <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                    </header>
                    <article class="lp_author_box">
                        <header class="section_header">
                            <h1><?= $Autor['autor_title'] ?></h1>
                            <img class="lp_author_box_avatar" src="<?= BASE; ?>/_activepages/<?= $Autor['autor_cover'] ?>" alt="<?= $Autor['autor_title'] ?>" title="<?= $Autor['autor_title'] ?>"/>
                        </header>
                        <?= $Autor['autor_desc'] ?> 
                    </article>

                    <?php
                    if ($Section['section_button']):
                        require '_activepages/require/button.php';
                    endif;
                    ?>
                </div>
            </article>
            <?php
            break;
        case 12:
            $Read->ExeRead(DB_LP_PALESTRANTES, "WHERE palestrante_section = :id", "id={$Section['section_id']}");
            if ($Read->getResult()):
                ?>
                <section class="lp_section lp_palestrantes" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                    <div class="content">
                        <header class="section_header">
                            <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                            <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                        </header>

                        <?php
                        foreach ($Read->getResult() as $Pal):
                            ?>
                            <article class="box box4 course_stats" style="<?= $Section['section_text_color'] ? 'color:' . $Section['section_text_color'] . ';' : '' ?>">
                                <img src="<?= BASE ?>/tim.php?src=_activepages/<?= $Pal['palestrante_cover'] ?>&h=300&w=300" />
                                <h3><?= $Pal['palestrante_title'] ?></h3>
                                <p><?= $Pal['palestrante_desc'] ?></p>
                            </article>
                            <?php
                        endforeach;
                        ?>

                        <?php
                        if ($Section['section_button']):
                            require '_activepages/require/button.php';
                        endif;
                        ?>
                    </div>
                </section>

                <?php
            endif;
            break;
        case 13:
            $Read->ExeRead(DB_LP_MAP, "WHERE map_section = :id", "id={$Section['section_id']}");
            if ($Read->getResult()):
                $Map = $Read->getResult()[0];
                ?>
                <script src='https://maps.googleapis.com/maps/api/js?key=<?= $Map['map_key'] ?>&v=3.exp'></script>

                <div class="mapa" >

                    <div style='overflow:hidden;height:440px;width:100%;'>
                        <div id='gmap_canvas' style='height:440px;width:100%;'>

                        </div>
                        <div>
                            <small>
                                <a href="http://embedgooglemaps.com">https://embedgooglemaps.com/pt/</a>
                            </small>
                        </div>
                        <div>
                            <small>
                                <a href="http://www.proxysitereviews.com /lime-proxies/">lime proxies</a>
                            </small>
                        </div>
                        <style>#gmap_canvas img{max-width:none!important;background:none!important}</style>
                    </div>

                </div>
                <style>
                    .mapa{
                        position: relative;
                    }
                    .mapa .infor{
                        position: absolute;
                        right: 10px;
                        width: 100%;
                        max-width: 400px;
                        height: 260px;
                        top: calc(50% - 165px);
                        /*background: linear-gradient(to right, rgba(34, 71, 99, 0.58) 50%, rgba(34, 71, 99, 0.8) 100%);*/
                        background: rgba(34, 71, 99, 0.8);
                        opacity: 0.9;
                        padding: 20px;
                        z-index: 99999999999;
                    }
                    .mapa .infor ul{
                        float: left;
                        width: 100%;
                    }

                    .mapa .infor li{
                        padding: 10px;
                        padding-left: 30px;
                        width: 100%;
                        float: left;
                        color: #fff;
                        font-size: 1em;
                        list-style: none;
                        position: relative;
                    }

                    .mapa .infor li:before{
                        position: absolute !important;
                        top: 10px !important;
                        left: 0px !important;
                        font-size: 1em !important;
                        color: #fff!important;
                        margin-right: 0 !important;
                    }
                </style>

                <script type='text/javascript'>function init_map() {
                        var myOptions = {
                            zoom: 15,
                            //                panControl: false,
                            //                draggable: false,
                            //                zoomControl: false,
                            scrollwheel: false,
                            center: new google.maps.LatLng(<?= $Map['map_coord'] ?>),
                            mapTypeId: google.maps.MapTypeId.ROADMAP};
                        map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
                        marker = new google.maps.Marker({
                            map: map, position: new google.maps.LatLng(<?= $Map['map_coord'] ?>)
                        });
                        infowindow = new google.maps.InfoWindow({
                            content: '<strong><?= $Map['map_title'] ?></strong><br><?= $Map['map_addr'] ?><br>'
                        });
                        google.maps.event.addListener(marker, 'click', function () {
                            infowindow.open(map, marker);
                        });
                        infowindow.open(map, marker);
                    }
                    google.maps.event.addDomListener(window, 'load', init_map);</script>
                <?php
            endif;
            break;
        case 14:
            ?>
            <section class="lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                <div class="content">
                    <?= $Section['section_ads_code'] ?>
                </div>
            </section>
            <?php
            break;
        case 15:
            $datatime1 = new DateTime();
            $datatime2 = new DateTime($Section['section_date']);

            $data1 = $datatime1->format('Y-m-d H:i:s');
            $data2 = $datatime2->format('Y-m-d H:i:s');

            $diff = $datatime1->diff($datatime2);
            $dias = $diff->days;
            $horas = $diff->h;
            $minutos = $diff->i;
            $segundos = $diff->s;
            ?>
            <script>
                // TIME
                var YY = <?= $datatime2->format('Y') ?>;
                var MM = <?= $datatime2->format('m') ?>;
                var DD = <?= $datatime2->format('d') ?>;
                var HH = <?= $datatime2->format('H') ?>;
                var MI = <?= $datatime2->format('i') ?>;
                var SS = <?= $datatime2->format('s') ?>;

                window.onload = function () {
                    atualizaContador();
                };

                function atualizaContador()
                {
                    var hoje = new Date();
                    var futuro = new Date(YY, MM - 1, DD, HH, MI, SS);
                    var ss = parseInt((futuro - hoje) / 1000);
                    var mm = parseInt(ss / 60);
                    var hh = parseInt(mm / 60);
                    var dd = parseInt(hh / 24);
                    ss = ss - (mm * 60);
                    mm = mm - (hh * 60);
                    hh = hh - (dd * 24);
                    var faltam = '';
                    $('.days').html((dd && dd > 1) ? '<span>' + dd + '</span> <p>Dias</p>' : (dd == 1 ? '<span>1</span> <p>dia</p>' : ''));
                    $('.hours').html((toString(hh).length) ? '<span>' + hh + '</span> <p>Horas</p>' : '');
                    $('.minutes').html((toString(mm).length) ? '<span>' + mm + '</span> <p>Minutos</p>' : '');
                    $('.seconds').html('<span>' + ss + '</span> <p>Segundos</p>');

                    if (dd + hh + mm + ss > 0)
                    {
                        setTimeout(atualizaContador, 1000);
                    } else
                    {
                        setTimeout(atualizaContador, 1000);
                    }
                }
            </script>
            <section class="lp_section" style="<?= $Section['section_background_color'] ? "background-color: {$Section['section_background_color']};" : ''; ?><?= $Section['section_background_img'] ? "background-image: url(" . BASE . "/_activepages/{$Section['section_background_img']});" : '' ?>">
                <div class="content">
                    <header class="section_header">
                        <h2  style="<?= $Section['section_title_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_title'] ?></h2>
                        <p style="<?= $Section['section_hedline_color'] ? "color: {$Section['section_title_color']};" : ''; ?>"><?= $Section['section_hedline'] ?></p>
                    </header>
                    <div class="time">

                        <div class="time-count">

                            <div class="time-clock" style="<?= $Section['section_text_color'] ? 'color: ' . $Section['section_text_color'] : '' ?>">
                                <div class="days">
                                    <span><?= $dias ?></span> 
                                    <p>Dias</p>
                                </div> 
                                <div class="hours">
                                    <span><?= $horas ?></span> 
                                    <p>Horas</p>
                                </div> 
                                <div class="minutes">
                                    <span><?= $minutos ?></span> 
                                    <p>Minutos</p>
                                </div> 
                                <div class="seconds">
                                    <span><?= $segundos ?></span> 
                                    <p>Segundos</p>
                                </div> 
                            </div>
                        </div>
                    </div>

                    <?php
                    if ($Section['section_button']):
                        require '_activepages/require/button.php';
                    endif;
                    ?>
                </div>
            </section>

            <?php
            break;
        case 16:
            ?>
            <section class="main-box-slide">
                <div class="w-slider experts-slide">
                    <div class="w-slider-mask">
                        <div class="w-slide sld-1" id="slide">
                            <div class="box-profis">
                                <div class="cdr _04">
                                    <div class="foto-card _05">
                                        <div class="alt-card">
                                            <ul class="lista-profile">
                                                <li class="linha-lista">A empreendedora movida por paixão</li>
                                                <li class="linha-lista">Faturamento de R$ 30 milhões</li>
                                                <li class="linha-lista">A mulher que desafia o tempo</li>
                                                <li class="linha-lista">Muito além do networking - A criação de relacionamentos de valor</li>
                                                <li class="linha-lista">Atuação em mais de 40 países</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="txt-card _03">
                                        <div class="name-autor _03">Sofia Esteves</div>
                                        <div class="cargo-autor">Fundadora do Grupo DMRH e <br>Cia de Talentos</div>
                                    </div>
                                </div>
                                <div class="cdr _02">
                                    <div class="foto-card _02">
                                        <div class="alt-card">
                                            <ul class="lista-profile">
                                                <li class="linha-lista">De dentista a empreendedor</li>
                                                <li class="linha-lista">Criador da marca Top of Mind em culinária chinesa</li>
                                                <li class="linha-lista">Mais de 220 lojas em todo o Brasil</li>
                                                <li class="linha-lista">Forte crescimento por franquias</li>
                                                <li class="linha-lista">Faturamento de 400 milhões</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="txt-card _02">
                                        <div class="name-autor _02">Robinson Shiba</div>
                                        <div class="cargo-autor">Fundador do China In Box</div>
                                    </div>
                                </div>
                                <div class="cdr _01">
                                    <div class="foto-card _01">
                                        <div class="alt-card alt-flavio">
                                            <ul class="lista-profile">
                                                <li class="linha-lista">Multiempreendedor</li>
                                                <li class="linha-lista">Dono do Orlando City, clube de futebol nos EUA</li>
                                                <li class="linha-lista">Fundador do Geração de Valor</li>
                                                <li class="linha-lista">Visão, coragem e competência para empreender</li>
                                                <li class="linha-lista">Comunicação como ferramenta de liderança</li>
                                                <li class="linha-lista">Acredita no poder da venda</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="txt-card">
                                        <div class="name-autor main">Flávio Augusto</div>
                                        <div class="cargo-autor">Fundador da Wise Up</div>
                                    </div>
                                </div>
                                <div class="cdr _05">
                                    <div class="foto-card wizard _04">
                                        <div class="alt-card">
                                            <ul class="lista-profile">
                                                <li class="linha-lista">Fundador da Wizard e do Grupo Multi Educação. A escola foi vendida em 2013, por R$ 1,9 bilhão, e atualmente Carlos é dono das empresas Mundo Verde, Rainha, Topper, Ronald Academy, Vale-Presente e Taco Bell, entre outras marcas presentes no Brasil e no mundo.</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="txt-card _03">
                                        <div class="name-autor _03">Carlos Wizard</div>
                                        <div class="cargo-autor">Fundador da Wizard <br>e do Grupo Multi Educação</div>
                                    </div>
                                </div>
                                <div class="cdr _03">
                                    <div class="foto-card _03">
                                        <div class="alt-card">
                                            <ul class="lista-profile">
                                                <li class="linha-lista">Criou um novo mercado de reciclagem no Brasil</li>
                                                <li class="linha-lista">Liderança carismática - carinho com disciplina</li>
                                                <li class="linha-lista">Acredita no poder do pensamento positivo</li>
                                                <li class="linha-lista">Aposta na melhoria contínua dos negócios</li>
                                                <li class="linha-lista">Afirma que o poder da negociação é a chave para sair da crise</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="txt-card _02">
                                        <div class="name-autor _02">Geraldo Rufino</div>
                                        <div class="cargo-autor">Fundador da JR Diesel</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="w-slider-arrow-left arrow-1 _02">
                      <div class="w-icon-slider-left icon-seta"></div>
                    </div>
                    <div class="w-slider-arrow-right arrow-1">
                      <div class="w-icon-slider-right icon-seta"></div>
                    </div>
                    <div class="w-slider-nav w-round nav-dots">
                      <div class="w-slider-dot w-active"></div>
                      <div class="w-slider-dot"></div>
                    </div> -->
                </div>
                <div class="b-cta">
                    <div class="box-preco">
                        <div class="preco _03">R$ 75,00/mês</div>
                    </div>
                    <div class="box-cta-brinde">
                        <!-- <div class="brinde-msg">
                          <div><strong>Brinde Exclusivo</strong>
                            <br>Livro Geração de Valor</div>
                        </div>-->
                        <!-- <a class="button cta head md brinde" href="javascript:openModal('/popup/livroAutografado')">Assine o meuSucesso.com</a> -->
                        <a class="button cta head md brinde" data-backdrop="static" data-keyboard="false" href="/comprar/cadastro/assinatura-livro-davi-braga-145/">Assine Agora</a>    </div>
                </div>
            </section>
            <?php
            break;
    endswitch;
endforeach;
