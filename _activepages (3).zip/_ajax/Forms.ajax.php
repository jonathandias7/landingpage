<?php
session_start();
require '../_app/Config.inc.php';
$Email = new Email;
$jSON = array();
$getPost = filter_input_array(INPUT_POST, FILTER_DEFAULT);

if (empty($getPost['callback_action'])):
     $jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b>Meu querido, Já existe esse email: {$PostData['news_email']}", E_USER_NOTICE);
	
else:
    $Post = array_map("strip_tags", $getPost);
    $Action = $Post['callback_action'];
    unset($Post['callback'], $Post['callback_action']);

    $Create = new Create;
    $Read = new Read;
    $Update = new Update;
    $Delete = new Delete;

    switch ($Action):
            case 'logar':
        if (in_array('', $Post)):
            $jSON['trigger'] = AjaxErro("Favor informe seu E-mail e Senha para logar!", E_USER_WARNING);
        elseif (!Check::Email($Post['user_email']) || !filter_var($Post['user_email'], FILTER_VALIDATE_EMAIL)):
            $jSON['trigger'] = AjaxErro("O E-mail informado não tem um formato válido!", E_USER_WARNING);
        elseif (strlen($Post['user_password']) < 5):
            $jSON['trigger'] = AjaxErro("Sua senha deve conter no mínimo 5 caracteres!", E_USER_WARNING);
        else:
            $Password = hash("sha512", $Post['user_password']);
            $Read->ExeRead(DB_USERS, "WHERE user_email = :email AND user_password = :pass", "email={$Post['user_email']}&pass={$Password}");
            if (!$Read->getResult()):
                $jSON['trigger'] = AjaxErro("Os dados informados não conferem. Informe seu e-mail e senha!", E_USER_WARNING);
            else:
                $_SESSION['userLogin'] = $Read->getResult()[0];
                $jSON['clear'] = true;
                $jSON['redirect'] = BASE . "/conta/home#acc";

                $LoginUpdate = ['user_login' => time(), "user_lastaccess" => date("Y-m-d H:i:s")];
                $Update->ExeUpdate(DB_USERS, $LoginUpdate, "WHERE user_id = :id", "id={$Read->getResult()[0]['user_id']}");
            endif;
        endif;
        break;

                 case 'login':
            $jSON['typeform'] = true; 
             $jSON['typeforms'] = true; 
              $jSON['mdpcontent'] = "<div style='background:#fff;text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p>
    <div style='font-size: 1.2em;' class='jwc_return'></div>
     <div id='contentlogin'>
<form style='padding:4%;background:#fbfbfb' class='mdp_form' name='account_form' action='' method='post' enctype='multipart/form-data'>
	
	 <input name='callback' type='hidden' value='Forms' />
	 <input name='callback_action' type='hidden' value='logar' />
            <div style='text-align:left;' class='label_50'><label class='label'>
            <span>E-mail:</span>
            <input name='user_email' type='email' placeholder='E-mail:' required/>
            </label><label class='label'>
            <span>Senha:</span>
            <input name='user_password' type='password' placeholder='Senha:' required/>
            </label>
            
        </div>
        <div style='width:100%; margin-top:40px;text-align:center;'>
         <span>
		 <button type='submit' class='btn btn_medium btn_blue'>Fazer Login
		 <img class='wc_load' style='display:none;' alt='Criar minha Conta!' title='Criar minha Conta!' src='". BASE ."/_cdn/widgets/account/load.gif'/>
        </span>
        </div>
         
		 </button>

</form>

</div> ";
   
      
            break;
            case'pdt_download':
                 $jSON['typeform'] = true; 
                $pId = $Post['pdt_id'];
                 unset($Post['pdt_id']);
                $Read->ExeRead(DB_PDT," WHERE pdt_id = :id","id={$pId}");
                if($Read->getResult()):
                    extract($Read->getResult()[0]);
                 endif;
                 if($pdt_urldown):
                   
                 
                    
                if(isset($_SESSION['userLogin'])):
                    $Read->ExeRead("mdp_user_downloads"," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                 if(!$Read->getResult()):
                 $newDown = [
                 'user_id' => $_SESSION['userLogin']['user_id'],
                 'pdt_id'=> $pdt_id, 
                 'down_date' => date('Y-m-d H:i:s'),
                 'down_count' => 1,
                 'pdt_title' => $pdt_title,
                 'pdt_urldown' => $pdt_urldown
                 ];
                $Create->ExeCreate('mdp_user_downloads',$newDown);
                
                else:
                    $mdpdown = $Read->getResult()[0];
                    $countdown =  $mdpdown['down_count']+1;
                $UpDown = [
                 'down_date' => date('Y-m-d H:i:s'),
                 'down_count' =>  $countdown
                 ];
                $Update->ExeUpdate('mdp_user_downloads',$UpDown," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                endif;
                       $Email = new Email();
                    require '../_cdn/ass.email.php';
                     $ToCliente = "<div style='text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p><p style='font-size: 1.2em;'>Caro(a) <b>{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>,</p><p style='font-size: 1.2em;'>Você solicitou um download (<b>". strtolower($pdt_title)."</b>) em  nosso site para este endereço de email:<b>{$_SESSION['userLogin']['user_email']}</b>.Caso ainda não tenha efetuado o downloado, clique em Baixar no final do corpo deste email.<br/> <p>Para visualizar todos os seus projetos comprados ou ganhados, clicar em minhas compras:</p><p><a href='".  BASE ."/conta' style='font-size: 1.2em;text-decoration:none; background:#eee;padding:5px' class='btn btn_blue'>Minhas Compras</a></p>
                
                     <p style='padding:40px' ><hr><h3>{$pdt_title}</h3></p>
                     <p style='width:100%;height:100%;' ><img  src='". BASE ."/uploads/{$pdt_cover}'></p>
                         <p><a style='font-size: 1.5em;margin-top:20px;text-decoration:none; background:#00b594;color:#fff;padding:10px 15px'href='". $pdt_urldown ."'>BAIXAR</a></p>
                            <p><em>Atenciosamente,</em></p>
                        ";
                        $MailMensage = str_replace("#mail_body#", $ToCliente, $MailContent);
                        $Email->EnviarMontando("MDP LTDA - {$pdt_title} - Link de Download ", $MailMensage, SITE_NAME, MAIL_SENDER, $_SESSION['userLogin']['user_name'], $_SESSION['userLogin']['user_email']);
                    if($Email->getResult()):    
                $UpDown = [
                 'down_sendmail' => 1,
                 ];
                $Update->ExeUpdate('mdp_user_downloads',$UpDown," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                endif;
                        
                
               $jSON['mdpcontent'] = "<div style='background:#fff;text-align:center;position:relative' class='content'><p style='display:none;margin-top:-10px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p><div style='text-align:center;' class='content'><span style='text-align:center!important;background:#00b594;color:#fff;padding:10px;' class='ds_block'>Tudo certo <b> {$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>, Você já está logado!</span><br/><h1>Caro(a) <b>{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>,</h1><p style='font-size: 1.2em;'>Você receberá um e-mail no endereço de email:<b>{$_SESSION['userLogin']['user_email']}</b> contendo o link de download.Caso queira baixa-lo imediatamente, clique em Baixar.<br/><a style='font-size: 1.5em;margin-top:20px;width:100%;'class='btn btn_big btn_green'>BAIXAR</a></p></div>";
  $jSON['clear'] = true;
  else:
           
                $jSON['mdpcontent'] = "<div style='background:#fff;text-align:center;' class='content'><p style='display:none; margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p> <div style='padding:1%;margin-top:-20px;background:#eee' class='label_50'><label class='label'><a id='entrar' style='width:100%;'  class='fl_right btn btn_medium btn_green'>Fazer Login</a></label><label class='label'><a id='cadastrar' style='width:100%;'  class='fl_left btn btn_medium '>Fazer Cadastro</a></label></div>
    <div style='font-size: 1.2em;max-height:300px' class='jwc_return'></div>
     <div id='contentlogin'>
<form style='padding:2% 4% 0 2%;background:#fbfbfb' class='mdp_form' name='account_form' action='' method='post' enctype='multipart/form-data'>
	
	 <input name='pdt_id' type='hidden' value='{$pId}' />
	 <input name='callback' type='hidden' value='Forms' />
	 <input name='callback_action' type='hidden' value='wc_login' />
            <div style='text-align:left;' class='label_50'><label class='label'>
            <span>E-mail:</span>
            <input name='user_email' type='email' placeholder='E-mail:' required/>
            </label><label class='label'>
            <span>Senha:</span>
            <input name='user_password' type='password' placeholder='Senha:' required/>
            </label>
            
        </div>
        <div style='width:100%; margin-top:40px;text-align:center;'>
         <span>
		 <button type='submit' class='btn btn_medium btn_blue'>Fazer Login
		 <img class='wc_load' style='display:none;' alt='Criar minha Conta!' title='Criar minha Conta!' src='". BASE ."/_cdn/widgets/account/load.gif'/>
        </span>
        </div>
         
		 </button>

</form>
	</div><div style='display:none;' id='contentcreate'>
	<form style='padding:4%;background:#fbfbfb' class='mdp_form' name='account_form' action='' method='post' enctype='multipart/form-data'>
	 <input name='pdt_id' type='hidden' value='{$pId}' />
	 <input name='callback' type='hidden' value='Forms' />
	 <input name='callback_action' type='hidden' value='wc_create' />
    <div style='text-align:left;' class='label_50'>
      <label class='label'>
            <span>Nome:</span>
            <input name='user_name' type='text' placeholder='Nome:' required/>
       </label><label class='label'>
      
            <span>Sobrenome:</span>
            <input name='user_lastname' type='text' placeholder='Sobrenome:' required/>
         </label><label class='label'>
            <span>E-mail:</span>
            <input name='user_email' type='email' placeholder='E-mail:' required/>
        </label><label class='label'>
            <span>Senha:</span>
            <input name='user_password' type='password' placeholder='Senha:' required/>
        </label>
    </div>
		   <div style='width:100%; margin-top:40px;text-align:center;'>
         <span>
		 <button type='submit' class='btn btn_medium btn_blue'>Fazer Login
		 <img class='wc_load' style='display:none;' alt='Criar minha Conta!' title='Criar minha Conta!' src='". BASE ."/_cdn/widgets/account/load.gif'/>
        </span>
        </div>
         
		 </button>

     
</form>
</div> "; endif;
       else:
            $jSON['mdpcontent'] = "<div style='background:#fff;text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:200px; max-width:200px;' src='". INCLUDE_PATH ."/images/logo.png'></p><div style='text-align:center;' class='content'><span style='text-align:center!important;background:red;color:#fff;padding:10px;' class='ds_block'><b>O link de download ainda encontra-se indisponivel.</b><br/> Tente novamente mais tarde..</span></div>";
           endif;
            break;
         // CONTATO PATROCINADOR
	        case'pdt_demo':
	             $pId = $Post['pdt_id'];
                 unset($Post['pdt_id']);
	             $Read->ExeRead(DB_PDT,	" WHERE pdt_id = :id","id={$pId}");
                if($Read->getResult()):
                    extract($Read->getResult()[0]);
                 endif;
                 if($pdt_urldemo):
	           $jSON['mdpcontent'] = "
	      	<iframe style='width:100%; height: 100%;' type='text/html' src='{$pdt_urldemo}'></iframe>";
	         
	                 else:
            $jSON['mdpcontent'] = "<div style='text-align:center;margin-top:5%;' ><img style='max-height:150px; max-width:150px;' src='". INCLUDE_PATH ."/images/logo.png'></p><div style='text-align:center;' class='content'><br/><span style='text-align:center!important;background:red;color:#fff;padding:10px;' class='ds_block'>O link de demonstração para <b> {$pdt_title}</b> encontra-se <b>temporariamente indisponivel.</b><br/> Tente novamente mais tarde..</span></div>";
         
	            endif;
	        break;
      
         // CONTATO PATROCINADOR
	        case'new_inscricao':
	        
	        //1 ° - PRIMEIRA ETAPA
	        //se existir nome
	        if(!empty($Post['nome'])):
	            
	            $Post['date'] = (!empty($Post['date']) ? $Post['date'] : date('Y-m-d H:i:s'));
	            //Se existir sobrenome
	            if(!empty($Post['sobrenome'])):
                   
                  
    	            if (!empty($Post['email'])):     
        	            if(Check::Email($Post['email']) && filter_var($Post['email'], FILTER_VALIDATE_EMAIL)):
                            
                                $Read->ExeRead('ddesign_inscricao',"WHERE email = :email","email={$Post['email']}");
                                 if($Read->getResult()):
                                      $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O email {$Post['email']} já existe</b>.</span>", E_USER_NOTICE);
                                 else:
                     

                        	        // 2 ETAPA DE VALIDAÇÃO
                        	        //Se existir telephone
                        	        
                        	        if (empty($Post['telefone'])):     
                                    //Se Não existir Telefone
                                    $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, é necessário informar um número de contato</b>.</span>", E_USER_WARNING);
                                    else:
                                       
                                                //Se existir nome da empresa
                                                if (empty($Post['empresa'])):     
                                    	             //Se o email não for valido
                                	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe o nome da sua Empresa.</b>.</span>", E_USER_WARNING);
                                                else:
                                    	            
                                        	            
                                        	           $Read->ExeRead('ddesign_inscricao',"WHERE email = :email","email={$Post['email']}");
                                                            if(!$Read->getResult()):
                                                                
                                                              
                            
                                                                     $Create->ExeCreate('ddesign_inscricao', $Post);	
                                                                     if($Create->getResult()):
                                                        			 require '../_cdn/ass.email.php';
                                                        			 //SEND TO ADMIN
                                                                    $ToAdmin = "
                                                                           <p style='font-size: 1.2em;'>Nome:{$Post['nome']}</p>
                                                                           <p style='font-size: 1.2em;'>Sobrenome:{$Post['sobrenome']}</p>
                                                                           <p style='font-size: 1.2em;'>Telefone:{$Post['telefone']}</p>
                                                                           <p style='font-size: 1.2em;'>E-mail:{$Post['email']}</p>
                                                                           <p style='font-size: 1.2em;'>Empresa:{$Post['empresa']}</p>
                                                                           <p style='font-size: 1.2em;'>Mensagem:<br/> {$Post['mensagem']}</p>
                                                                            <p>Este e-mail é para informar que recebemos uma nova inscrição.Inscrita sobre o número de registro:</p>
                                                                            <p style='padding:15px;max-width:150px; fonte-size: 3.5em; background:#000;color:#fff;'> " . str_pad($Create->getResult(), 7, 0, STR_PAD_LEFT) ."</p>
                                                                            <p><em>Atenciosamente,</em></p>
                                                                    ";
                                                                    $Email = new Email();
                                                                     $MailMensage = str_replace("#mail_body#", $ToAdmin, $MailContent);
                                                                     $Email->EnviarMontando("[" . SITE_NAME ."] Recebemos um nova inscrição: ", $MailMensage, SITE_NAME, MAIL_SENDER, SITE_ADDR_NAME, SITE_ADDR_EMAIL);
                                                                     //SEND TO CLIENTE
                                                                    $ToCliente = "
                                                                            <p style='font-size: 1.2em;'>Prezado(a) {$Post['nome']},</p>
                                                                            <p><b>Obrigado por se cadastrar na Pesquisa Nacional da " . SITE_NAME .".</b></p>
                                                                            <p>Este e-mail é para informar que recebemos seu cadastro</p>
                                                                            <p><em>Atenciosamente,</em></p>
                                                                        ";
                                                                        $MailMensage = str_replace("#mail_body#", $ToCliente, $MailContent);
                                                                        $Email->EnviarMontando("Recebemos sua mensagem", $MailMensage, SITE_ADDR_NAME, MAIL_SENDER, $Post['nome'], $Post['email']);
                                                                          $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>Inscrição realizada com sucesso.</b>.</span>");
                                                                         
                                                                         $upinsc = [
                                                                             'sendmail' => 1,
                                                                             'status' => 1
                                                                             ];
                                                                         $Update->ExeUpdate('ddesign_inscricao',$upinsc, "WHERE id = :id","id=". $Create->getResult());
                                                                        if($Update->getResult()):
                                                                          $jSON['inscricao'] = true;
                                                                        endif;
                                    		                          endif;
                                    		                       
                                    		                        
                                    		                    
                                	                        else:
                            	                             $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O email {$Post['email']} já existe</b>.</span>", E_USER_NOTICE);
                                                             
                                		                        
                                                            endif;
                                                    
                                                   
                                                   
                                                
                                                    
                                        endif;
                                              
                                                
                                                
                                    endif;
                                     
                                 endif;
                             else:
                	                //Se o email não for valido
                	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe um Email Válido.</b>.</span>", E_USER_WARNING);
                                endif;
                                
                        
                                
                            else:
        	                //Se Não existir email
        	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe um Email</b>.</span>", E_USER_WARNING);
                            endif;
                       
        
                        else:
        	                //Se Não existir sobrenome
        	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe seu Sobrenome</b>.</span>", E_USER_WARNING);
                        endif;
	            
	            
	        else:
	         //Se Não existir nome
	         $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe seu Nome</b>.</span>", E_USER_WARNING);
	        endif;
               
		break;
		
		
		
	    case'new_contato':
	        var_dump($Post);
	        die;
	        //1 ° - PRIMEIRA ETAPA
	        //se existir nome
	        if(!empty($Post['nome'])):
	            
	            $Post['date'] = (!empty($Post['date']) ? $Post['date'] : date('Y-m-d H:i:s'));
	            //Se existir sobrenome
	            if(!empty($Post['sobrenome'])):
                   
                  
    	            if (!empty($Post['email'])):     
        	            if(Check::Email($Post['email']) && filter_var($Post['email'], FILTER_VALIDATE_EMAIL)):
                            
                                $Read->ExeRead('ddesign_pesquisa',"WHERE email = :email","email={$Post['email']}");
                                 if($Read->getResult()):
                                      $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O email {$Post['email']} já existe</b>.</span>", E_USER_NOTICE);
                                 else:
                     

                        	        // 2 ETAPA DE VALIDAÇÃO
                        	        //Se existir cpf
                        	        $jSON['valida'] = true;
                        	        if (!empty($Post['cpf'])):     
                                        
                                        //Se existir cpf e ele for valido
                                        if(Check::CPF($Post['cpf'])):
                                        $Read->ExeRead('ddesign_pesquisa',"WHERE cpf = :cpf","cpf={$Post['cpf']}");
                                            if(!$Read->getResult()):  
                                                //Se existir nome da empresa
                                                if (!empty($Post['empresa'])):     
                                    	            
                                    	             //Se existir cargo
                                                    if (!empty($Post['cargo'])):     
                                        	            
                                        	           $Read->ExeRead('ddesign_pesquisa',"WHERE email = :email","email={$Post['email']}");
                                                            if(!$Read->getResult()):
                                                                
                                                              $Read->ExeRead('ddesign_pesquisa',"WHERE cpf = :cpf","cpf={$Post['cpf']}");
                                                                if(!$Read->getResult()):
                            
                                                                     $Create->ExeCreate('ddesign_pesquisa', $Post);	
                                                                     if($Create->getResult()):
                                                        			 require '../_cdn/ass.email.php';
                                                        			 //SEND TO ADMIN
                                                                    $ToAdmin = "
                                                                           <p style='font-size: 1.2em;'>Nome:{$Post['nome']}</p>
                                                                           <p style='font-size: 1.2em;'>Sobrenome:{$Post['sobrenome']}</p>
                                                                           <p style='font-size: 1.2em;'>CPF:{$Post['cpf']}</p>
                                                                           <p style='font-size: 1.2em;'>E-mail:{$Post['email']}</p>
                                                                           <p style='font-size: 1.2em;'>Cargo:{$Post['cargo']}</p>
                                                                           <p style='font-size: 1.2em;'>Empresa:{$Post['empresa']}</p>
                                                                            <p>Este e-mail é para informar que recebemos uma nova inscrição na Pesquisa Top do Transporte.Inscrita sobre o número de registro:</p>
                                                                            <p style='padding:15px;max-width:150px; fonte-size: 3.5em; background:#000;color:#fff;'> " . str_pad($Create->getResult(), 7, 0, STR_PAD_LEFT) ."</p>
                                                                            <p><em>Atenciosamente,</em></p>
                                                                    ";
                                                                    $Email = new Email();
                                                                     $MailMensage = str_replace("#mail_body#", $ToAdmin, $MailContent);
                                                                     $Email->EnviarMontando("[" . SITE_NAME ."] Recebemos um nova inscrição: ", $MailMensage, SITE_NAME, MAIL_SENDER, SITE_ADDR_NAME, SITE_ADDR_EMAIL);
                                                                     //SEND TO CLIENTE
                                                                    $ToCliente = "
                                                                            <p style='font-size: 1.2em;'>Prezado(a) {$Post['nome']},</p>
                                                                            <p><b>Obrigado por se cadastrar na Pesquisa Nacional da " . SITE_NAME .".</b></p>
                                                                            <p>Este e-mail é para informar que recebemos seu cadastro</p>
                                                                            <p><em>Atenciosamente,</em></p>
                                                                        ";
                                                                        $MailMensage = str_replace("#mail_body#", $ToCliente, $MailContent);
                                                                        $Email->EnviarMontando("Recebemos sua mensagem", $MailMensage, SITE_ADDR_NAME, MAIL_SENDER, $Post['nome'], $Post['email']);
                                                                        $upinsc = [
                                                                             'sendmail' => 1,
                                                                             'status' => 1
                                                                             ];
                                                                         $Update->ExeUpdate('ddesign_pesquisa',$upinsc, "WHERE id = :id","id=". $Create->getResult());
                                                            
                                    		                          endif;
                                    		                       
                                    		                        
                                    		                    else:
                            		                             $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O CPF {$Post['cpf']} já existe</b>.</span>", E_USER_NOTICE);
                                                                endif;
                                	                        else:
                            	                             $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O email {$Post['email']} já existe</b>.</span>", E_USER_NOTICE);
                                                             
                                		                        
                                                            endif;
                                                    
                                                    else:
                                    	                //Se o email não for valido
                                    	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe o seu Cargo.</b>.</span>", E_USER_WARNING);
                                                    endif;
                                                
                                                    
                                                
                                                else:
                                	                //Se o email não for valido
                                	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe o nome da sua Empresa.</b>.</span>", E_USER_WARNING);
                                                endif;
                                                
                                                
                                             else:
        		                               $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O CPF {$Post['cpf']} já existe</b>.</span>", E_USER_NOTICE);
                                            endif;
                                        else:
                        	                //Se o email não for valido
                        	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe um CPF Válido.</b>.</span>", E_USER_WARNING);
                                        endif;
                                                    
                                    else:
                                    //Se Não existir email
                                    $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, é necessário informar o seu CPF</b>.</span>", E_USER_WARNING);
                                    endif;
                             endif;
                             else:
                	                //Se o email não for valido
                	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe um Email Válido.</b>.</span>", E_USER_WARNING);
                                endif;
                                
                        
                                
                            else:
        	                //Se Não existir email
        	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe um Email</b>.</span>", E_USER_WARNING);
                            endif;
                       
        
                        else:
        	                //Se Não existir sobrenome
        	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe seu Sobrenome</b>.</span>", E_USER_WARNING);
                        endif;
	            
	            
	        else:
	         //Se Não existir nome
	         $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe seu Nome</b>.</span>", E_USER_WARNING);
	        endif;
               
		break;
	
	
	        // CONTATO PATROCINADOR
	        case'new_patrocinador':
	         //1 ° - PRIMEIRA ETAPA
	        //se existir nome
	        if(!empty($Post['nome'])):
	            
	            $Post['date'] = (!empty($Post['date']) ? $Post['date'] : date('Y-m-d H:i:s'));
	            //Se existir sobrenome
	            if(!empty($Post['sobrenome'])):
                   
                  
    	            if (!empty($Post['email'])):     
        	            if(Check::Email($Post['email']) && filter_var($Post['email'], FILTER_VALIDATE_EMAIL)):
                            
                                $Read->ExeRead('ddesign_patrocinador',"WHERE email = :email","email={$Post['email']}");
                                 if($Read->getResult()):
                                      $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O email {$Post['email']} já existe</b>.</span>", E_USER_NOTICE);
                                 else:
                     

                        	        // 2 ETAPA DE VALIDAÇÃO
                        	        //Se existir telephone
                        	        
                        	        if (empty($Post['telefone'])):     
                                    //Se Não existir Telefone
                                    $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, é necessário informar um número de contato</b>.</span>", E_USER_WARNING);
                                    else:
                                       
                                                //Se existir nome da empresa
                                                if (empty($Post['empresa'])):     
                                    	             //Se o email não for valido
                                	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe o nome da sua Empresa.</b>.</span>", E_USER_WARNING);
                                                else:
                                    	            
                                        	            
                                        	           $Read->ExeRead('ddesign_patrocinador',"WHERE email = :email","email={$Post['email']}");
                                                            if(!$Read->getResult()):
                                                                
                                                              
                            
                                                                     $Create->ExeCreate('ddesign_patrocinador', $Post);	
                                                                     if($Create->getResult()):
                                                        			 require '../_cdn/ass.email.php';
                                                        			 //SEND TO ADMIN
                                                                    $ToAdmin = "
                                                                           <p style='font-size: 1.2em;'>Nome:{$Post['nome']}</p>
                                                                           <p style='font-size: 1.2em;'>Sobrenome:{$Post['sobrenome']}</p>
                                                                           <p style='font-size: 1.2em;'>Telefone:{$Post['telefone']}</p>
                                                                           <p style='font-size: 1.2em;'>E-mail:{$Post['email']}</p>
                                                                           <p style='font-size: 1.2em;'>Empresa:{$Post['empresa']}</p>
                                                                           <p style='font-size: 1.2em;'>Mensagem:<br/> {$Post['mensagem']}</p>
                                                                            <p>Este e-mail é para informar que recebemos uma nova solicitação de Patrocinio.Solicitação inscrita sobre o número de registro:</p>
                                                                            <p style='padding:15px;max-width:150px; fonte-size: 3.5em; background:#000;color:#fff;'> " . str_pad($Create->getResult(), 7, 0, STR_PAD_LEFT) ."</p>
                                                                            <p><em>Atenciosamente,</em></p>
                                                                    ";
                                                                    $Email = new Email();
                                                                     $MailMensage = str_replace("#mail_body#", $ToAdmin, $MailContent);
                                                                     $Email->EnviarMontando("[" . SITE_NAME ."] Recebemos um nova solicitação de Patrocinio: ", $MailMensage, SITE_NAME, MAIL_SENDER, SITE_ADDR_NAME, SITE_ADDR_EMAIL);
                                                                     //SEND TO CLIENTE
                                                                    $ToCliente = "
                                                                            <p style='font-size: 1.2em;'>Prezado(a) {$Post['nome']},</p>
                                                                            <p><b>Obrigado por se cadastrar na Pesquisa Nacional da " . SITE_NAME .".</b></p>
                                                                            <p>Este e-mail é para informar que recebemos seu cadastro</p>
                                                                            <p><em>Atenciosamente,</em></p>
                                                                        ";
                                                                        $MailMensage = str_replace("#mail_body#", $ToCliente, $MailContent);
                                                                        $Email->EnviarMontando("Recebemos sua mensagem", $MailMensage, SITE_ADDR_NAME, MAIL_SENDER, $Post['nome'], $Post['email']);
                                                                          $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>Inscrição realizada com sucesso.</b>.</span>");
                                                                         
                                                                         $upinsc = [
                                                                             'sendmail' => 1,
                                                                             'status' => 1
                                                                             ];
                                                                         $Update->ExeUpdate('ddesign_patrocinador',$upinsc, "WHERE id = :id","id=". $Create->getResult());
                                                                        if($Update->getResult()):
                                                                          $jSON['inscricao'] = true;
                                                                        endif;
                                    		                          endif;
                                    		                       
                                    		                        
                                    		                    
                                	                        else:
                            	                             $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>O email {$Post['email']} já existe</b>.</span>", E_USER_NOTICE);
                                                             
                                		                        
                                                            endif;
                                                    
                                                   
                                                   
                                                
                                                    
                                        endif;
                                              
                                                
                                                
                                    endif;
                                     
                                 endif;
                             else:
                	                //Se o email não for valido
                	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe um Email Válido.</b>.</span>", E_USER_WARNING);
                                endif;
                                
                        
                                
                            else:
        	                //Se Não existir email
        	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe um Email</b>.</span>", E_USER_WARNING);
                            endif;
                       
        
                        else:
        	                //Se Não existir sobrenome
        	                $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe seu Sobrenome</b>.</span>", E_USER_WARNING);
                        endif;
	            
	            
	        else:
	         //Se Não existir nome
	         $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b> Por favor, informe seu Nome</b>.</span>", E_USER_WARNING);
	        endif;
	         break;
	     //LOGIN
    case 'wc_login':
        
        if (in_array('', $Post)):
            $jSON['trigger'] = AjaxErro("Favor informe seu E-mail e Senha para logar!", E_USER_WARNING);
        elseif (!Check::Email($Post['user_email']) || !filter_var($Post['user_email'], FILTER_VALIDATE_EMAIL)):
            $jSON['trigger'] = AjaxErro("O E-mail informado não tem um formato válido!", E_USER_WARNING);
        elseif (strlen($Post['user_password']) < 5):
            $jSON['trigger'] = AjaxErro("Sua senha deve conter no mínimo 5 caracteres!", E_USER_WARNING);
        else:
            $Password = hash("sha512", $Post['user_password']);
            $Read->ExeRead(DB_USERS, "WHERE user_email = :email AND user_password = :pass", "email={$Post['user_email']}&pass={$Password}");
            if (!$Read->getResult()):
                $jSON['trigger'] = AjaxErro("Os dados informados não conferem. Informe seu e-mail e senha!", E_USER_WARNING);
            else:
                $_SESSION['userLogin'] = $Read->getResult()[0];
                 $pId = $Post['pdt_id'];
                 unset($Post['pdt_id']);
                $Read->ExeRead(DB_PDT," WHERE pdt_id = :id","id={$pId}");
                if($Read->getResult()):
                    extract($Read->getResult()[0]);
                 endif;
                 if($pdt_urldown):
                       $Read->ExeRead("mdp_user_downloads"," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                 if(!$Read->getResult()):
                 $newDown = [
                 'user_id' => $_SESSION['userLogin']['user_id'],
                 'pdt_id'=> $pdt_id, 
                 'down_date' => date('Y-m-d H:i:s'),
                 'down_count' => 1,'pdt_title' => $pdt_title,
                 'pdt_urldown' => $pdt_urldown
                 ];
                $Create->ExeCreate('mdp_user_downloads',$newDown);
                
                else:
                    $mdpdown = $Read->getResult()[0];
                    $countdown =  $mdpdown['down_count']+1;
                $UpDown = [
                 'down_date' => date('Y-m-d H:i:s'),
                 'down_count' =>  $countdown
                 ];
                $Update->ExeUpdate('mdp_user_downloads',$UpDown," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                endif;
                 $Email = new Email();
                    require '../_cdn/ass.email.php';
                     $ToCliente = "<div style='text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p><p style='font-size: 1.2em;'>Caro(a) <b>{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>,</p><p style='font-size: 1.2em;'>Você solicitou um download (<b>". strtolower($pdt_title)."</b>) em  nosso site para este endereço de email:<b>{$_SESSION['userLogin']['user_email']}</b>.Caso ainda não tenha efetuado o downloado, clique em Baixar.<br/> <p>Para visualizar todos os seus projetos comprados ou ganhados, clicar em minhas compras:</p><p><a href='".  BASE ."/conta' style='font-size: 1.2em;text-decoration:none; background:#eee;padding:5px' class='btn btn_blue'>Minhas Compras</a></p>
                     <p><a style='font-size: 1.5em;margin-top:20px;text-decoration:none; background:#00b594;color:#fff;padding:5px'href='". $pdt_urldown ."'>BAIXAR</a></p>
                      <p style='padding:40px' ><hr><h3>{$pdt_title}</h3></p>
                     <p style='width:100%;height:100%; ><img  src='". BASE ."/uploads/{$pdt_cover}'></p>
                     
                            <p><em>Atenciosamente,</em></p>
                        ";
                        $MailMensage = str_replace("#mail_body#", $ToCliente, $MailContent);
                        $Email->EnviarMontando("MDP LTDA - {$pdt_title} - Link de Download ", $MailMensage, SITE_NAME, MAIL_SENDER, $_SESSION['userLogin']['user_name'], $_SESSION['userLogin']['user_email']);
                            if($Email->getResult()):    
                $UpDown = [
                 'down_sendmail' => 1,
                 ];
                $Update->ExeUpdate('mdp_user_downloads',$UpDown," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                endif;

                  $jSON['content'] = "<div style='box-shadow:1px 2px 2px 1px gray;background:#fff;text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p><div style='text-align:center;' class='content'><span style='text-align:center!important;background:#00b594;color:#fff;padding:10px;' class='ds_block'><b>LOGIN EFETUADO COM SUCESSO!</b><br/> Tudo certo <b> {$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>, Você já está logado!</span><br/><h1>Caro(a) <b>{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>,</h1><p style='font-size: 1.2em;'>Você receberá um e-mail no endereço de email:<b>{$_SESSION['userLogin']['user_email']}</b> contendo o link de download.Caso queira baixa-lo imediatamente, clique em Baixar.<br/><a style='font-size: 1.5em;margin-top:20px;width:100%;'class='btn btn_big btn_green'>BAIXAR</a></p></div>";
  $jSON['clear'] = true;
                $LoginUpdate = ['user_login' => time(), "user_lastaccess" => date("Y-m-d H:i:s")];
                $Update->ExeUpdate(DB_USERS, $LoginUpdate, "WHERE user_id = :id", "id={$_SESSION['userLogin']['user_id']}");
            endif;  
            endif;
        endif;
    
        break;

    //CREATE
    case 'wc_create':
         $pId = $Post['pdt_id'];
                 unset($Post['pdt_id']);
        if (in_array('', $Post)):
            $jSON['trigger'] = AjaxErro("Favor preencha todos os campos para criar sua nova conta!", E_USER_WARNING);
        elseif (!Check::Email($Post['user_email']) || !filter_var($Post['user_email'], FILTER_VALIDATE_EMAIL)):
            $jSON['trigger'] = AjaxErro("Oppsss. O e-mail informado não parece ter um formato válido!", E_USER_WARNING);
        elseif (strlen($Post['user_password']) < 5):
            $jSON['trigger'] = AjaxErro("Oppsss. Sua senha deve ter no mínimo 5 caracteres!", E_USER_WARNING);
        else:
            $Read->FullRead("SELECT user_email FROM " . DB_USERS . " WHERE user_email = :email", "email={$Post['user_email']}");
            if ($Read->getResult()):
                $jSON['trigger'] = AjaxErro("Desculpe, mas o e-mail <b>{$Post['user_email']}</b> já está cadastrado!", E_USER_ERROR);
            else:
                $Post['user_password'] = hash("sha512", $Post['user_password']);
                $Post['user_registration'] = date("Y-m-d H:i:s");
                $Post['user_lastupdate'] = date("Y-m-d H:i:s");
                $Post['user_lastaccess'] = date("Y-m-d H:i:s");
                $Post['user_channel'] = "Cadastro";
                $Post['user_level'] = 1;

                $Create->ExeCreate(DB_USERS, $Post);
                $Post['user_id'] = $Create->getResult();
                $_SESSION['userLogin'] = $Post;
                
                $Read->ExeRead(DB_PDT," WHERE pdt_id = :id","id={$pId}");
                if($Read->getResult()):
                    extract($Read->getResult()[0]);
                 endif;
                 if($pdt_urldown):
                $Read->ExeRead("mdp_user_downloads"," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                 if(!$Read->getResult()):
                 $newDown = [
                 'user_id' => $_SESSION['userLogin']['user_id'],
                 'pdt_id'=> $pdt_id, 
                 'down_date' => date('Y-m-d H:i:s'),
                 'down_count' => 1,'pdt_title' => $pdt_title,
                 'pdt_urldown' => $pdt_urldown
                 ];
                $Create->ExeCreate('mdp_user_downloads',$newDown);
                
                else:
                    $mdpdown = $Read->getResult()[0];
                    $countdown =  $mdpdown['down_count']+1;
                $UpDown = [
                 'down_date' => date('Y-m-d H:i:s'),
                 'down_count' =>  $countdown
                 ];
                $Update->ExeUpdate('mdp_user_downloads',$UpDown," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                endif;
                 $Email = new Email();
                    require '../_cdn/ass.email.php';
                     $ToCliente = "<div style='text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p><p style='font-size: 1.2em;'>Caro(a) <b>{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>,</p><p style='font-size: 1.2em;'>Você solicitou um download (<b>". strtolower($pdt_title)."</b>) em  nosso site para este endereço de email:<b>{$_SESSION['userLogin']['user_email']}</b>.Caso ainda não tenha efetuado o downloado, clique em Baixar.<br/> <p>Para visualizar todos os seus projetos comprados ou ganhados, clicar em minhas compras:</p><p><a href='".  BASE ."/conta' style='font-size: 1.2em;text-decoration:none; background:#eee;padding:5px' class='btn btn_blue'>Minhas Compras</a></p>
                     <p><a style='font-size: 1.5em;margin-top:20px;text-decoration:none; background:#00b594;color:#fff;padding:5px'href='". $pdt_urldown ."'>BAIXAR</a></p>
                      <p style='padding:40px' ><hr><h3>{$pdt_title}</h3></p>
                     <p style='width:100%;height:100%; ><img  src='". BASE ."/uploads/{$pdt_cover}'></p>
                     
                            <p><em>Atenciosamente,</em></p>
                        ";
                        $MailMensage = str_replace("#mail_body#", $ToCliente, $MailContent);
                        $Email->EnviarMontando("MDP LTDA - {$pdt_title} - Link de Download ", $MailMensage, SITE_NAME, MAIL_SENDER, $_SESSION['userLogin']['user_name'], $_SESSION['userLogin']['user_email']);
                            if($Email->getResult()):    
                $UpDown = [
                 'down_sendmail' => 1,
                 ];
                $Update->ExeUpdate('mdp_user_downloads',$UpDown," WHERE pdt_id = :id AND user_id = :u","id={$pId}&u={$_SESSION['userLogin']['user_id']}");
                endif;

                  $jSON['content'] = "<div style='box-shadow:1px 2px 2px 1px gray;background:#fff;text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p><div style='text-align:center;' class='content'><span style='text-align:center!important;background:#00b594;color:#fff;padding:10px;' class='ds_block'><b>CADASTRO EFETUADO COM SUCESSO!</b><br/>Seja muito bem vindo ao " . SITE_NAME . " {$Post['user_name']}!</span><br/><h1>Caro(a) <b>{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>,</h1><p style='font-size: 1.2em;'>Você receberá um e-mail no endereço de email:<b>{$_SESSION['userLogin']['user_email']}</b> contendo o link de download.Caso queira baixa-lo imediatamente, clique em Baixar.<br/><a style='font-size: 1.5em;margin-top:20px;width:100%;'class='btn btn_big btn_green'>BAIXAR</a></p></div>";
  $jSON['clear'] = true;
                $LoginUpdate = ['user_login' => time(), "user_lastaccess" => date("Y-m-d H:i:s")];
                $Update->ExeUpdate(DB_USERS, $LoginUpdate, "WHERE user_id = :id", "id={$_SESSION['userLogin']['user_id']}");
            endif;  
               
            endif;
        endif;
        break;    
	    case'filter_rank':
	       
	  $Post['dataini'] = (!empty($Post['dataini']) ? $Post['dataini'] : 2009);
	  $Post['dataend'] = (!empty($Post['dataend']) ? $Post['dataend'] : 2019);
	    $jSON['dataini'] =      (!empty($Post['dataend']) ? $Post['dataend'] : 2009);
        $jSON['dataend'] =      (!empty($Post['dataend']) ? $Post['dataend'] : 2019);
     $jSON['categoria'] =       (!empty($Post['categoria']) ? $Post['categoria'] : null) ;
        $jSON['empresas'] =  SITE_NAME;
        $jSON['empresa'] =  Check::Name(SITE_NAME);
    $i = 1;
  $jSON['content'] = "";
  
    $Read = new Read();
    
         
if(!empty($Post['categoria'])):
               
    for($a = $Post['dataend'];  $a >= $Post['dataini']; $a--):
        
          
             
            
             $Read->ExeRead("mdp_ranking"," WHERE rank_categoria = '{$Post['categoria']}' AND rank_ano = '{$a}' ORDER BY rank_ano DESC,rank_position ASC");
             $RCat = "para a categoria {$Post['categoria']} ";
            if($Read->getResult()):
                     $jSON['content'] .= "
        <tr style='margin-top:50px!important'>
        <td class='rank tdb'>Ranking</td>
        <td class='cat tdb'>{$Post['categoria']}</td>
        <td class='voto tdb'>Votos</td>
        <td class='nota tdb'>Nota</td>
         <td class='ano tdb'>Ano</td>
    </tr>";
                foreach($Read->getResult() as $rc):
                    if($rc['rank_categoria']):
                          if($rc['rank_position'] > 0):
            extract($rc);
           
        if($i%2==0):
            $cor = 'background:#fff';
            else: 
            $cor = 'background:#e3e3e3';
        endif;
        $jSON['trigger'] = AjaxErro("<span style='text-align:center!important;' class='ds_block'><b>Rank filtrado {$RCat} entre o período de {$Post['dataini']} até {$Post['dataend']}</b>.</span>");
	      
    $jSON['content'] .= "<div class='mdp_content'>"
        ."<tr  style='{$cor}'>"
        ."<td class='rank'>{$rank_position}</td>"
        ."<td class='cat'>{$rank_empresa}</td>"
        ."<td class='voto'>{$rank_voto}</td>"
        ."<td class='nota'>{$rank_nota}</td>"
        ."<td class='ano'>{$rank_ano}</td>"
         ." </tr>"
     ."</div>";
    $i++;
    endif;
    endif;
    endforeach;
     endif;
             endfor;
    else:
            
            $i = 0;
         
            $Read->FullRead("SELECT DISTINCT(rank_categoria),rank_ano FROM mdp_ranking WHERE rank_ano >= '{$Post['dataini']}' AND rank_ano <= '{$Post['dataend']}' ORDER BY rank_ano DESC,rank_categoria ASC");
            if($Read->getResult()):
            foreach($Read->getResult() as $r):
            if($r['rank_categoria']):
        $jSON['content'] .="<tr style='margin-top:50px!important'>
        <td class='rank tdb'>Ranking</td>
        <td class='cat tdb'>{$r['rank_categoria']}</td>
        <td class='voto tdb'>Votos</td>
        <td class='nota tdb'>Nota</td>
         <td class='ano tdb'>Ano</td>
    </tr>";
             $Read->ExeRead("mdp_ranking","WHERE rank_categoria = '{$r['rank_categoria']}' AND rank_ano = '{$r['rank_ano']}' ORDER BY rank_position ASC,rank_ano DESC");
                 if($Read->getResult()):
                foreach($Read->getResult() as $rc):
                    if($rc['rank_categoria']):
                          if($rc['rank_position'] > 0):
            extract($rc);
           
        if($i%2==0):
            $cor = 'background:#fff';
            else: 
            $cor = 'background:#e3e3e3';
        endif;
            
 $jSON['content'] .= "<div class='mdp_content'>"
        ."<tr  style='{$cor}'>"
        ."<td class='rank'>{$rank_position}</td>"
        ."<td class='cat'>{$rank_empresa}</td>"
        ."<td class='voto'>{$rank_voto}</td>"
        ."<td class='nota'>{$rank_nota}</td>"
        ."<td class='ano'>{$rank_ano}</td>"
         ." </tr>"
     ."</div>";
    $i++;
    endif;
    endif;
    endforeach;
     endif;
      endif;
         endforeach;
     endif;
            endif;
                
 
     

 break;
    endswitch;
endif;

echo json_encode($jSON);
