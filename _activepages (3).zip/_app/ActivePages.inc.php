<?php

/*
 * LANDING PAGES DBSA
 */
define('DB_LP_PAGES', "ws_lp_pages");
define('DB_LP_VIDEOS', "ws_lp_videos");
define('DB_LP_INPUTS', "ws_lp_inputs");
define('DB_LP_DEPOIMENTOS', "ws_lp_depoimentos");
define('DB_LP_SECTIONS', "ws_lp_sections");
define('DB_LP_GALLERY', "ws_lp_gallery");
define('DB_LP_GALLERY_CAT', "ws_lp_gallery_cat");
define('DB_GATES', "ws_gates");
define('DB_GATES_VIDEOS', "ws_gates_videos");
define('DB_LP_POSTS', "ws_lp_posts");
define('DB_LP_PERGUNTAS', "ws_lp_pergunta");
define('DB_LP_SERVICE', "ws_lp_service");
define('DB_LP_PALESTRANTES', "ws_lp_palestrantes");
define('DB_LP_AUTOR', "ws_lp_autor");
define('DB_LP_SOBRE', "ws_lp_sobre");
define('DB_LP_MAP', "ws_lp_map");

if (!$WorkControlDefineConf):
    define('LEVEL_WC_ACTIVEPAGES', 10); //Level Acesso Menu ActivePages
    define('APP_ACTIVEPAGES', 1); //APP Active Pages
endif;

function getWcSessaoType($Status = null) {
    $HotmartStatus = [
        1 => ['title' => 'Instagram',
            'img' => 'Instagram.jpg'],
        2 => ['title' => 'Galeria Fotos',
            'img' => 'GaleriaFotos.jpg'],
        3 => ['title' => 'Depoimento Vídeo',
            'img' => 'DepoimentoVideo.jpg'],
        4 => ['title' => 'Depoimento Texto',
            'img' => 'DepoimentoTexto.jpg'],
        5 => ['title' => 'Vídeos PlayList',
            'img' => 'PlayListVideo.jpg'],
        6 => ['title' => 'Posts',
            'img' => 'Posts.jpg'],
        7 => ['title' => 'Promoção',
            'img' => 'Promocao.jpg'],
        8 => ['title' => 'Perguntas Frequentes',
            'img' => 'Perguntas_Frequentes.jpg'],
        9 => ['title' => 'Serviços',
            'img' => 'Servicos.jpg'],
        10 => ['title' => 'Sobre',
            'img' => 'Sobre.jpg'],
        11 => ['title' => 'Autor',
            'img' => 'Autor.jpg'],
        12 => ['title' => 'Palestrantes',
            'img' => 'Palestrantes.jpg'],
        13 => ['title' => 'Google Maps',
            'img' => 'GoogleMaps.jpg'],
        14 => ['title' => 'Google Adsense',
            'img' => 'GoogleAds.jpg'],
        15 => ['title' => 'Cronômetro',
            'img' => 'Cronometro.jpg'],
//        16 => ['title' => 'Pacotes',
//            'img' => 'Pacote.jpg'],
    ];
    if (!empty($Status)):
        return $HotmartStatus[$Status];
    else:
        return $HotmartStatus;
    endif;
}

function getWcHomeType($Status = null) {
    $HotmartStatus = [
        'home_email' => 'Home E-mail',
        'home_livro' => 'Home Livro',
        'home_video' => 'Home Vídeo'
    ];
    if (!empty($Status)):
        return $HotmartStatus[$Status];
    else:
        return $HotmartStatus;
    endif;
}

function getWcConfirmaType($Status = null) {
    $HotmartStatus = [
        'confirma_text' => 'Confirma Texto',
        'confirma_video' => 'Confirma Vídeo'
    ];
    if (!empty($Status)):
        return $HotmartStatus[$Status];
    else:
        return $HotmartStatus;
    endif;
}

function getWcObrigadoType($Status = null) {
    $HotmartStatus = [
        'obrigado_text' => 'Obrigado E-mail',
        'obrigado_livro' => 'Obrigado Livro',
        'obrigado_video' => 'Obrigado Vídeo'
    ];
    if (!empty($Status)):
        return $HotmartStatus[$Status];
    else:
        return $HotmartStatus;
    endif;
}

function getWcButtonStyle($Status = null) {
    $HotmartStatus = [
        'blue' => 'Azul',
        'green' => 'Verde',
        'yellow' => 'Amarelo',
        'red' => 'Vermelho',
        'purple' => 'Roxo',
        'pink' => 'Rosa'
    ];
    if (!empty($Status)):
        return $HotmartStatus[$Status];
    else:
        return $HotmartStatus;
    endif;
}

function getWcButtonType($Status = null) {
    $HotmartStatus = [
        1 => 'Botão Captura',
        2 => 'Botão Venda',
        3 => 'Botão Download'
    ];
    if (!empty($Status)):
        return $HotmartStatus[$Status];
    else:
        return $HotmartStatus;
    endif;
}
