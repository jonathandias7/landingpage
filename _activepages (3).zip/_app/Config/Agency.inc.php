<?php

if (!$WorkControlDefineConf):
    /*
      AGENCY DATA
      Dados da sua agência web
     */
      define('AGENCY_CONTACT', 'Pietro Napoleão'); //Nome do contato
    define('AGENCY_EMAIL', 'pietro@mdape.net'); //E-mail de contato
    define('AGENCY_PHONE', '(32) 99922-7859'); //Telefone de contato
    define('AGENCY_URL', 'https://www.mdape.net'); //URL completa do seu site/portfolio
    define('AGENCY_NAME', 'MDP SOFTWARES LTDA'); //Nome da sua agência web
    define('AGENCY_ADDR', 'Ferreira Neto, 67'); //Endereço da sua agência web (RUA, NÚMERO)
    define('AGENCY_CITY', 'Recreio');  //Endereço da sua agência web (CIDADE)
    define('AGENCY_UF', 'MG');  //Endereço da sua agência web (UF DO ESTADO)
    define('AGENCY_ZIP', '36740-000');  //Endereço da sua agência web (CEP)
    define('AGENCY_COUNTRY', 'Brasil');  //Endereço da sua agência web (PAÍS)
endif;

