<?php

trait MPArrayTrait
{
    use WCTrait;
    
    /**
     * Collection for create a new customer
     * 
     * @param array | object $data
     * @return array
     */
    public function customerObject()
    {
        return [
            "first_name" => $this->getUserAndAddress()['user_name'], 
            "last_name" => $this->getUserAndAddress()['user_lastname'],
            "email" => $this->getUserAndAddress()['user_email'],
            "phone" => $this->setPhoneNumber(),
            "identification" => $this->setIdentification(),
            "address" => $this->setMinAddress(),
        ];
    }
    
    /**
     * Collection for payment via credit card
     * 
     * @param array $data
     * @return array
     */
    public function creditCardObject($data = [])
    {
        return [
            "transaction_amount" => $data['transaction_amount'],
            "token" => $data['card_token_id'],
            "description" => $data['description'],
            "installments" => $data['installments'],
            "payment_method_id" => $data['payment_method_id'],
            "notification_url" => MP_TRANSPARENT_NOTIFICATIONS,
            "external_reference" => $data['external_reference'],
            "payer" => [
                "type" => (!empty($data['payer_id']) ? "customer" : "guest"),
                "id" => $data['payer_id'] ?? null,
                "email" => $this->getUserAndAddress()['user_email'],
                "first_name" => $this->getUserAndAddress()['user_name'],
                "last_name" => $this->getUserAndAddress()['user_lastname'],
                "identification" => $this->setIdentification(),
            ], 
            "additional_info" => [
                "ip_address" => $_SERVER['REMOTE_ADDR'],
                "payer" => $this->setPayer(),
                "items" => $data['items'],
            ]
        ];
    }
    
    /**
     * Collection for payment via billet
     * 
     * @param array | object $data
     * @return array | object
     */
    public function billetObject($data = [])
    {  
        return [
            "transaction_amount" => $data['transaction_amount'],
            "coupon_amount" => $data['coupon_amount'] ?? null,
            "description" => $data['description'],
            "payment_method_id" => $data['payment_method_id'],
            "statement_descriptor" => $data['statement_descriptor'] ?? SITE_NAME,
            "payer" => [
                "email" => $this->getUserAndAddress()['user_email'],
                "first_name" => $this->getUserAndAddress()['user_name'],
                "last_name" => $this->getUserAndAddress()['user_lastname'],
                "identification" => $this->setIdentification(),
                "address" => $this->setAddress(),
            ],
            "external_reference" => $data['external_reference'] ?? null,
            "notification_url" => MP_TRANSPARENT_NOTIFICATIONS,
            "additional_info" => [
                "ip_address" => $_SERVER['REMOTE_ADDR'],
                "payer" => $this->setPayer(),
                "items" => $data['items'],
            ]
        ];
    }
    
    private function setAddress()
    {
        return [
            "zip_code" => $this->getUserAndAddress()['addr_zipcode'],
            "street_name" => $this->getUserAndAddress()['addr_street'],
            "street_number" => (int)$this->getUserAndAddress()['addr_number'],
            "neighborhood" => $this->getUserAndAddress()['addr_district'],
            "city" => $this->getUserAndAddress()['addr_city'],
            "federal_unit" => $this->getUserAndAddress()['addr_state'],
        ];
    }
    
    private function setIdentification()
    {
        return [
            "type" => "CPF",
            "number" => $this->getUserAndAddress()['user_document']
        ];
    }
    
    private function setPhoneNumber()
    {
        return [
            "area_code" => substr($this->getUserAndAddress()['user_cell'], 1, 2),
            "number" => substr(str_replace('-', '', $this->getUserAndAddress()['user_cell']), 5)
        ];
    }
    
    private function setPayer()
    {
        return [
            "first_name" => $this->getUserAndAddress()['user_name'],
            "last_name" => $this->getUserAndAddress()['user_lastname'],
            "phone" => $this->setPhoneNumber(),
            "address" => $this->setMinAddress(),  
        ];
    }
    
    private function setMinAddress()
    {
        return [
            "zip_code" => $this->getUserAndAddress()['addr_zipcode'],
            "street_name" => $this->getUserAndAddress()['addr_street'],
            "street_number" => (int)$this->getUserAndAddress()['addr_number'],
        ];
    }
}