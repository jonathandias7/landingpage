<?php
 
/**
 * Class to integrate with API on Mercado Pago
 * 
 * @author Samuel dos Santos 
 */
class MPCrud extends MP
{
    use MPResourcesTrait;
    use MPArrayTrait;
    
    /**
     *
     * @var class MP 
     */
    private $mp_instance;
    
    /**
     *
     * @var string Your MP Token 
     */
    private $token;
    
    /**
     * Enter your token for transparent checkout mode 
     * Can be SANDBOX or PRODUCTION
     * 
     * You can get this informations in your account through this url https://www.mercadopago.com/mlb/account/credentials
     * Just access your account and paster the url above in your browser preferred
     */
     
    public function __construct()
    {
        
       
        $this->token = ((int)MP_TRANSPARENT_MODE === 1 ? MP_TRANSPARENT_TOKEN_PROD : MP_TRANSPARENT_TOKEN_SANDBOX);
        $this->mp_instance = new MP($this->token);
       
    }
    
    /**
     * Create a new customer
     * If it already exist, updates then return it
     * 
     * @param array $filters
     * @param array $data
     * @return array | object
     */
    public function customerCreate($filters = [], $data = [])
    {
        $find = $this->resourceGet("/v1/customers/search", $filters);
        $response = $find['response']['results'][0] ?? null;
        
        if(empty($response)):
            try {
                return $this->resourcePost("/v1/customers", $data);   
            } catch (MercadoPagoException $e) {
                return ['error' => $e->getMessage()];
            }
        else:
            try {
                unset($data['email']);
                return $this->customerUpdate($response['id'], $data);  
            } catch (MercadoPagoException $e) {
                return ['error' => $e->getMessage()];
            }
        endif;
    }
    
    /**
     * Get all customers or a specific searched by $filter
     * 
     * @param array | object $filters
     * @return array | object | string
     */
    public function customerGet($filters = [])
    {
        try {
            if(!empty($filters)):
                return $this->resourceGet("/v1/customers/search", $filters);
            else:
                return $this->resourceGet("/v1/customers");
            endif;
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Delete a customer
     * 
     * @param int $id
     * @param array | object $data
     * @return array | object
     */
    public function customerDelete($id, $data = [])
    {
        try {
            return $this->resourceDelete("/v1/customers/{$id}", $data);
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Update a customer
     * 
     * @param int $id
     * @param array | object $data
     * @return array | object
     */
    public function customerUpdate($id, $data = [])
    {
        try {
            return $this->resourceUpdate("/v1/customers/{$id}", $data);
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Associate a credit card to a customer
     * 
     * @param string $uri
     * @param int $customer_id
     * @param string $cc_token
     * @return array | object
     */
    public function creditCardCreate($customer_id, $cc_token)
    {
        try {  
            return $this->resourcePost("/v1/customers/{$customer_id}/cards", ["token" => $cc_token]);
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Get all credit card to one customer or
     * got all data for specific credit card searched by filters
     * 
     * @param type $customer_id
     * @return array | object
     */
    public function creditCardGet($customer_id)
    {
        try {
            return $this->resourceGet("/v1/customers/{$customer_id}/cards");
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Delete one credit card into an customer account
     * 
     * @param int $customer_id
     * @param int $cc_id
     * @return array | object
     */
    public function creditCardDelete($customer_id, $cc_id) 
    {
        try {
            return $this->resourceDelete("/v1/customers/{$customer_id}/cards/{$cc_id}");
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Gera um pagamento ou cobrança nos servidores
     * do Mercado Pago. Quanto mais informações forem 
     * enviadas, melhor para sua experiência e do seu
     * cliente. Confira todos os campo possíveis para 
     * envio em https://www.mercadopago.com.br/developers/pt/api-docs/custom-checkout/create-payments/
     * 
     * @param object $data
     * @return array | string
     */
    public function fullPay($data = [])
    { 
        try {
            return $this->resourcePost("/v1/payments", $this->fullPaymentObject($data));
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Try to create an payment via billet
     * on Mercado Pago server in your account defined 
     * by your token MP_TOKEN_PROD in _app/Config/Config.inc.php
     * Remember to define a value 1 or 0 to MP_MODE and reset this 
     * in admin to the app know in what mode you are working
     * 
     * @param array | object $data
     * @return array | object | string
     */
    public function billetPay($data = [])
    {
        try {
            return $this->resourcePost("/v1/payments", $this->billetObject($data));
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Try to create an payment via credit card
     * on Mercado Pago server in your account defined 
     * by your token MP_TOKEN_PROD in _app/Config/Config.inc.php
     * Remember to define a value 1 or 0 to MP_MODE and reset this 
     * in admin to the app know in what mode you are working
     * 
     * @param array | object $data
     * @return array | object | string
     */
    public function creditCardPay($data = [])
    {
        try {
            return $this->resourcePost("/v1/payments", $this->creditCardObject($data));
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Try to get all payment on your account in Mercado Pago
     * server by your token MP_TOKEN_PROD in _app/Config/Config.inc.php
     * Remember to define a value 1 or 0 to MP_MODE and reset this 
     * in admin to the app know in what mode you are working
     * 
     * @param string $uri
     * @param array $filters
     * @return array | object | string
     */
    public function paymentGet($uri, $filters = [])
    {
        try {
            return $this->resourceGet($uri, $filters);
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Try to update an exist paymeny on Mercado Pago server in your 
     * account defined by your token MP_TOKEN_PROD in _app/Config/Config.inc.php
     * Remember to define a value 1 or 0 to MP_MODE and reset this in admin to 
     * the app know in what mode you are working
     * 
     * @param type $id
     * @param type $data
     * @return array | object | string
     */
    public function paymentUpdate($id, $data = [])
    {
        try {
            return $this->resourceUpdate("/v1/payments/{$id}", $data);
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Try to delete an exist resource in the Mercado Pago
     * into your account defined by your token MP_TOKEN_PROD in _app/Config/Config.inc.php
     * Remember to define a value 1 or 0 to MP_MODE and reset this in admin to 
     * the app know in what mode you are working
     * 
     * @param string $uri
     * @param array | object $params
     * @param array | object $headers
     * @return array | object | string
     */
    public function paymentDelete($uri, $params = null, $headers = null)
    {
        try {
            return $this->resourceDelete($uri, $params, $headers);
        } catch (MercadoPagoException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    public function postSubscriptionPlan()
    {
        $ch = curl_init();
        
        $data = '{
            "description": "Mensalidade Programação Criativa",
            "auto_recurring": {
                "frequency": 1,                        
                "frequency_type": "days",                       
                "transaction_amount": .90
            }
        }';
        
        curl_setopt($ch, CURLOPT_URL, "https://api.mercadopago.com/v1/plans?access_token={$this->token}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_POST, 1);

        $headers = array();
        $headers[] = "Accept: application/json";
        $headers[] = "Content-Type: application/x-www-form-urlencoded";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close ($ch);
        
        return $result;
    }
    
    public function postEnrollCustomerInPlan($plan_id, $customer_id)
    {
        $ch = curl_init();
        $data = '{
            "plan_id": "' . $plan_id . '",
            "payer": {
                "id": "' . $customer_id . '"
            }    
        }';
        
        curl_setopt($ch, CURLOPT_URL, "https://api.mercadopago.com/v1/subscriptions?access_token={$this->token}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_POST, 1);

        $headers = array();
        $headers[] = "Accept: application/json";
        $headers[] = "Content-Type: application/x-www-form-urlencoded";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close ($ch);
        
        return $result;
    }
    
    public function getSubscription($subscription_id)
    {
        return $this->resourceGet("/v1/subscriptions/{$subscription_id}");
    }
}