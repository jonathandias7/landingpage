<?php

trait WCTrait
{
    private $read;
    private $create;
    private $update;
    private $delete;
    
    public function getCourse($course_id)
    {
        $this->read = new Read;
        $this->read->ExeRead(DB_EAD_COURSES, 'WHERE course_id = :course_id', "course_id={$course_id}");
        return $this->read->getResult()[0];
    }
    
    public function getProduct($product_id)
    {
        $this->read = new Read;
        $this->read->ExeRead(DB_PDT, 'WHERE pdt_id = :pdt_id', "pdt_id={$product_id}");
        return $this->read->getResult()[0];
    }
    
    public function getOrder($order_id)
    {
        $this->read = new Read;
        $this->read->ExeRead(DB_ORDERS, 'WHERE order_id = :order_id', "order_id={$order_id}");
        return $this->read->getResult()[0];
    }

    public function updateOrder($order_id, $data = [])
    {
        $this->update = new Update;
        $this->update->ExeUpdate(DB_ORDERS, $data, 'WHERE order_id = :oid', "oid={$order_id}");
        return $this->update->getResult()[0];
    }
    
    public function createOrderEAD($data = [])
    {
        $this->create = new Create;
        $this->create->ExeCreate(DB_EAD_ORDERS, $data);
        return $this->create->getResult();
    }
    
    public function createOrderProduct($data = [])
    {
        $this->create = new Create;
        $this->create->ExeCreate(DB_ORDERS, $data);
        return $this->create->getResult();
    }
    
    public function createOrderProductItems($data = [])
    {
        $this->create = new Create;
        $this->create->ExeCreate(DB_ORDERS_ITEMS, $data);
        return $this->create->getResult();
    }
    
    public function getUserAndAddress()
    {
        $this->read = new Read;
        $this->read->ExeRead(DB_USERS, 'LEFT JOIN ' . DB_USERS_ADDR . ' ON ' . DB_USERS . '.user_id = ' . DB_USERS_ADDR . '.user_id' . ' WHERE ' . DB_USERS . '.user_id = :usrid', "usrid={$_SESSION['userLogin']['user_id']}");  
        return $this->read->getResult()[0];
    }
}