 //FECHA MODAL
    $('.wc_box_modal_close').click(function () {
        $('.wc_boxs').fadeOut(400, function () {
            $(this).find('.wc_box_modal').fadeOut(200, function () {
                $(".trigger_ajax").remove();
            });
        });
    });

    //ABRE CADASTRO
    $('.cta_evento').click(function () {
        $('.wc_boxs').fadeIn().css('display', 'flex').find('.mdp_newsletter').fadeIn();
    });
    
    $(window).load(function(){
        $('.wc_form').trigger('click');
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();
		

      $.ajax({
            url: BASE +"/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                      setTimeout(function () {
                           $('.jwc_return').fadeOut();
                           if (data.inscricao) {
                       
                           window.location.reload(true);
                    
                          }
                    }, 3500);
                }
				
			
                  
                 if (data.valida) {
                 
                 $('#um').css({'display':'none'});
                 $('#dois').fadeIn();
                 
                 }
                 
                  if (data.exibe) {
                  $('#dois').css({'display':'none'});
                  $('#um').fadeIn();
                 
        
                 }
                 
                if (data.content) {
                     $('.nofilter').css({'display':'none'});
                      $('.jwc_content').html(data.content).fadeIn();
                      $('.baixar').fadeIn();
              
                }
					
			
                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
			
            }
        }); 
        return false;
  
        
    });
     $('.wc_form').submit(function () {
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();
		

      $.ajax({
            url: BASE +"/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                      setTimeout(function () {
                           $('.jwc_return').fadeOut();
                           if (data.inscricao) {
                       
                           window.location.reload(true);
                    
                          }
                    }, 3500);
                }
				
			
                  
                 if (data.valida) {
                 
                 $('#um').css({'display':'none'});
                 $('#dois').fadeIn();
                 
                 }
                 
                  if (data.exibe) {
                  $('#dois').css({'display':'none'});
                  $('#um').fadeIn();
                 
        
                 }
                 
                if (data.content) {
                     $('.nofilter').css({'display':'none'});
                      $('.jwc_content').html(data.content).fadeIn();
                       $('.baixar').fadeIn();
              
                }
					
			
                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
			
            }
        }); 
        return false;
  

});