<?php
require '_cdn/widgets/payments/index.php';
?>