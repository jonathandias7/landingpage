<?php
if ($pdt_inventory >= 1):
    ?>
    <form id="<?= $pdt_id; ?>" class="wc_cart_add" name="cart_add" method="post" enctype="multipart/form-data">
        <input name="pdt_id" type="hidden" value="<?= $pdt_id; ?>"/>
        <?php
        $Read->FullRead("SELECT stock_id, stock_code, stock_inventory FROM " . DB_PDT_STOCK . " WHERE pdt_id = :id AND stock_inventory >= 1", "id={$pdt_id}");
        if ($Read->getResult()):
            $ratioI = 0;
            foreach ($Read->getResult() as $StockVar):
                if ($StockVar['stock_code'] != 'default'):
                    $ratioI ++;
                    echo "<label id='{$StockVar['stock_inventory']}' class='wc_cart_size_select " . ($ratioI == 1 ? "wc_cart_size_select_true" : "") . "'><input " . ($ratioI == 1 ? "checked='checked'" : "") . " type='radio' name='stock_id' value='{$StockVar['stock_id']}'>{$StockVar['stock_code']}</label>";
                else:
                    echo "<input name='stock_id' type='hidden' value='{$StockVar['stock_id']}'/>";
                endif;
            endforeach;
        endif;
        ?>
        <button style='display:none' id="<?= $pdt_id; ?>" class="wc_cart_less cart_more less">-
        </button><input  style='display:none'  name="item_amount" type="text" value="1" max="<?= $pdt_inventory; ?>"/><button
            id="<?= $pdt_id; ?>" style='display:none'  class="wc_cart_plus cart_more plus">+</button>
        <button  id=''  class='btnmob btn btn_medium btn_green'><?= ECOMMERCE_BUTTON_TAG; ?></button>
    </form>
    <?php
endif;
?>