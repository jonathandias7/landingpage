<div class="wc_tab_target <?= (!PAYMENT_PAGSEGURO ? 'wc_active' : ''); ?>" id="wc_payment_paypal" style="<?= (!PAYMENT_PAGSEGURO ? '' : 'display: none'); ?>">
    <script src="https://www.paypalobjects.com/webstatic/ppplusdcc/ppplusdcc.min.js" type="text/javascript"></script>
    <script src="https://www.paypalobjects.com/api/checkout.js"></script>
    <link rel='stylesheet' href='<?= BASE; ?>/_cdn/widgets/payments/paypal/paypal.css?v=2'/>
    <?php
    require __DIR__ . '/../../ecommerce/PayPalWc/PayPal_Environment.php';

    $split_1 = PAYPAL_PAY_SPLIT_1;
    $split_2 = PAYPAL_PAY_SPLIT_2;
    $split_3 = PAYPAL_PAY_SPLIT_3;
    $split_4 = PAYPAL_PAY_SPLIT_4;
    $split_5 = PAYPAL_PAY_SPLIT_5;
    $split_6 = PAYPAL_PAY_SPLIT_6;
    $split_7 = PAYPAL_PAY_SPLIT_7;
    $split_8 = PAYPAL_PAY_SPLIT_8;
    $split_9 = PAYPAL_PAY_SPLIT_9;
    $split_10 = PAYPAL_PAY_SPLIT_10;
    $split_11 = PAYPAL_PAY_SPLIT_11;
    $split_12 = PAYPAL_PAY_SPLIT_12;
    ?>

    <div class="paypal_checkout_tabs workcontrol_pay_tabs">
        <?php if (PAYPAL_PAYMENT) {?> <p class="active" data-id="plus">Cartão de crédito</p><?php } if (PAYPALCHECKOUT_PAYMENT) {?><p class="<?php if (!PAYPAL_PAYMENT){echo "active";} ?>" data-id="express">PayPal</p><?php } ?>
    </div>

    <div class='workcontrol_order'>
        <div class='paypal_checkout'>

            <?php if (PAYPAL_PAYMENT) { ?>
            <div id="plus" class="wc_toggle_container">
                <div class="loadingPaypal" id="loadingPaypal" style="display:none;"><p>Carregando PayPal, aguarde..</p></div>
                <div class="change_split_plus" id="select_change_split" style="display: none">
                    <a target="_parent" href="<?= BASE; ?>/pedido/pagamento/<?= $URL[2]; ?>">Trocar plano de parcelamento!</a>
                </div>
                <div class="continuePPPLus" id="continuePPPLus">
                    <div class="labelline">
                        <label class="label70">
                            <span>Selecione o plano de parcelamento:</span>
                            <select id="split" name="selectParcelasPlus">
                                <?php
                                $i = 1;
                                for ($i; $i <= PAYPAL_PAY_SPLIT_NUM; $i++) {
                                    $split = ${"split_$i"};
                                    $subtotal = $order['order_price'] - $order['order_shipprice'];
                                    $dividir = $subtotal / $i;
                                    $dividirFrete = $order['order_shipprice'] / $i;
                                    if (!is_numeric($split)) {
                                        $split = 0;
                                    }
                                    $Total = $dividir + ($dividir / 100 * $split);
                                    $totalParcela = number_format($Total + $dividirFrete, 2, ',', '.');
                                    ?>
                                    <option value="<?= $i; ?>"><?= $i; ?>x de <?= (!empty($split) ? "R$ $totalParcela ($split% de acréscimo)" : "R$ $totalParcela (sem juros)") ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </label>
                    </div>
                    <div class="btn-paypal-fin">
                        <button data-id="<?= $order['order_id']; ?>" type="submit" class="btn btn_green wc_button_cart btn_paypal">Continuar</button>
                    </div>
                </div>

                <div class="box_paypal">
                    <div id="ppplus" style="width: 100%!important;">
                    </div>

                    <div class="btn-paypal-fin">
                        <button type="submit" class="btn btn_green wc_button_cart btn_continue" id="finalizarCompraPaypal" style="display:none;">Finalizar compra!</button>
                    </div>
                </div>
            </div>
            <?php } ?>

            <?php if (PAYPALCHECKOUT_PAYMENT) { ?>
            <div id="express" class="wc_toggle_container" style="<?php if (!PAYPAL_PAYMENT){echo "display:block;";}else{echo "display:none;";}?>text-align:center">
                <div class="box_paypal_express" style="margin-top:25px">
                    <img src="<?= BASE; ?>/_cdn/widgets/payments/paypal/saiba_mais_web.png" alt="PayPal" style="margin-bottom: 15px">
                    <h3 class="box_paypal_express_title">Finalizar pagamento no site do PayPal</h3>
                    <p>Finalize essa compra no Checkout Express do PayPal.</p>
                    <div class="box_paypal_express_btn">
                        <div id="paypal-button"></div>
                    </div>
                </div>
            </div>
            <?php } ?>

        </div>
    </div>

</div>
<?php if (PAYPALCHECKOUT_PAYMENT) { ?>
<script>
    paypal.Button.render({
        env: '<? if (PAYPALCHECKOUT_ENV == "live"){echo "production";}else{echo "sandbox";}; ?>', // Or 'production'
        locale: 'pt_BR',
        style: {
            label: 'pay',
            size:  'medium',
            shape: 'pill',
            color: 'blue',
            tagline: 'false',
            layout: 'horizontal',
            fundingicons: 'true'
        },
        payment: function(resolve) {

            return paypal.request.post('<?= BASE; ?>/_cdn/widgets/ecommerce/PayPalWc/Express/payment.php?orderid=<?= $order['order_id']; ?>').then(function(data) {
                resolve(data.token);

                if (data.trigger) {
                    Trigger(data.trigger);
                }

                return data.token;
            });
        },
        onAuthorize: function(data, actions) {
            return paypal.request.post('<?= BASE; ?>/_cdn/widgets/ecommerce/PayPalWc/Express/execute2.php', {
                paymentID: data.paymentID,
                payerID:   data.payerID,
                token:     data.paymentToken
            }).then(function(data) {
                if (data.trigger) {
                    Trigger(data.trigger);
                    return;
                }

                window.location = "<?= BASE; ?>/pedido/obrigado";
                console.log("Sucess: " + data);
            }).catch(function (err) {

                if (err.trigger) {
                    Trigger(err.trigger);
                }

                //window.location = "<?= BASE; ?>/index.php?url=retorno_paypal&success=false";
                //console.log(err);
            });
        }
    }, '#paypal-button');

    $('html').on('click', '.trigger_ajax, .trigger_modal', function () {
        $(this).fadeOut('slow', function () {
            $(this).remove();
        });
    });

    function Trigger(Message) {
        $('.trigger_ajax').fadeOut('fast', function () {
            $(this).remove();
        });
        $('body').before("<div class='trigger_modal error-report-p'>" + Message + "</div>");
        $('.trigger_ajax').fadeIn();
    }
</script>
<?php } ?>
