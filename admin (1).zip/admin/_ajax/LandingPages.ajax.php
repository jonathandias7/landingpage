<?php

session_start();
require '../../_app/Config.inc.php';
$NivelAcess = LEVEL_WC_ACTIVEPAGES;

if (!APP_ACTIVEPAGES || empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'LandingPages';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);

    // AUTO INSTANCE OBJECT READ
    if (empty($Read)):
        $Read = new Read;
    endif;

    // AUTO INSTANCE OBJECT CREATE
    if (empty($Create)):
        $Create = new Create;
    endif;

    // AUTO INSTANCE OBJECT UPDATE
    if (empty($Update)):
        $Update = new Update;
    endif;

    // AUTO INSTANCE OBJECT DELETE
    if (empty($Delete)):
        $Delete = new Delete;
    endif;

    //SELECIONA AÇÃO
    switch ($Case):
        case 'manager':

            $CourseId = $PostData['page_id'];
            unset($PostData['page_id']);

            $Read->ExeRead(DB_LP_PAGES, "WHERE page_id=:id", "id={$CourseId}");
            $ThisCourse = $Read->getResult()[0];
            if (isset($PostData['page_title']) && !isset($PostData['page_base'])):
                $PostData['page_base'] = 0;
            endif;

            if (isset($PostData['page_base'])):
                $Base['page_base'] = '0';
                $Update->ExeUpdate(DB_LP_PAGES, $Base, "WHERE page_base = :id", "id=1");
            endif;

            if (!isset($PostData['page_title'])):
                $PostData['page_title'] = $ThisCourse['page_title'];
            endif;


            $PostData['page_name'] = Check::Name($PostData['page_title']);
            if (isset($PostData['page_date_start'])):
                $PostData['page_date_start'] = (!empty($PostData['page_date_start']) && Check::Data($PostData['page_date_start']) ? Check::Data($PostData['page_date_start']) : null);
            endif;
            if (isset($PostData['page_date_and'])):
                $PostData['page_date_and'] = (!empty($PostData['page_date_and']) && Check::Data($PostData['page_date_and']) ? Check::Data($PostData['page_date_and']) : null);
            endif;
            if (!empty($_FILES['page_cover'])):
                $File = $_FILES['page_cover'];

                if ($ThisCourse['page_cover'] && file_exists("../../_activepages/{$ThisCourse['page_cover']}") && !is_dir("../../_activepages/{$ThisCourse['page_cover']}")):
                    unlink("../../_activepages/{$ThisCourse['page_cover']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, $PostData['page_name'] . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['page_cover'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['page_cover']);
            endif;


            if (!empty($_FILES['page_logo'])):
                $File = $_FILES['page_logo'];

                if ($ThisCourse['page_logo'] && file_exists("../../_activepages/{$ThisCourse['page_logo']}") && !is_dir("../../_activepages/{$ThisCourse['page_logo']}")):
                    unlink("../../_activepages/{$ThisCourse['page_logo']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, $PostData['page_name'] . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['page_logo'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['page_logo']);
            endif;

            if (!empty($_FILES['page_ebook_img'])):
                $File = $_FILES['page_ebook_img'];

                if ($ThisCourse['page_ebook_img'] && file_exists("../../_activepages/{$ThisCourse['page_ebook_img']}") && !is_dir("../../_activepages/{$ThisCourse['page_ebook_img']}")):
                    unlink("../../_activepages/{$ThisCourse['page_ebook_img']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, $ThisCourse['page_name'] . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['page_ebook_img'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['page_ebook_img']);
            endif;


            if (!empty($_FILES['page_ebook_autor_cover'])):
                $File = $_FILES['page_ebook_autor_cover'];

                if ($ThisCourse['page_ebook_autor_cover'] && file_exists("../../_activepages/{$ThisCourse['page_ebook_autor_cover']}") && !is_dir("../../_activepages/{$ThisCourse['page_ebook_autor_cover']}")):
                    unlink("../../_activepages/{$ThisCourse['page_ebook_autor_cover']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, $ThisCourse['page_name'] . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['page_ebook_autor_cover'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['page_ebook_autor_cover']);
            endif;

            if (isset($PostData['status'])):
                unset($PostData['status']);
                $PostData['page_status'] = (!empty($PostData['page_status']) ? '1' : '0');
            endif;
            $Update->ExeUpdate(DB_LP_PAGES, $PostData, "WHERE page_id=:id", "id={$CourseId}");
            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>TUDO CERTO: </b> A Landing Page <b>{$PostData['page_title']}</b> foi atualizado com sucesso!");

            break;
        //NOVO DEPOIMENTO
        case 'add_depoimento':
            $PostData['depoimento_page'] = $PostData["page_id"];
            $PostData['depoimento_section'] = $PostData['section_id'];
            unset($PostData["page_id"], $PostData['depoimento_id'], $PostData['section_id']);

            $Create->ExeCreate(DB_LP_DEPOIMENTOS, $PostData);

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PostData['depoimento_page']}&id={$PostData['depoimento_section']}";

            break;
        case 'delete':
            $LpId = $PostData['del_id'];
            $Read->ExeRead(DB_LP_SECTIONS, "WHERE section_page = :id", "id={$LpId}");
            foreach ($Read->getResult() as $Section):
                $SectionId = $Section['section_id'];

                switch ($Section['section_type']):
                    case 2:
                        $Read->ExeRead(DB_LP_GALLERY_CAT, "WHERE cat_section = :id", "id={$SectionId}");
                        if ($Read->getResult()):
                            foreach ($Read->getResult() as $GalCat):
                                $Read->FullRead("SELECT gallery_cover, gallery_id FROM " . DB_LP_GALLERY . " WHERE gallery_cat = :id", "id={$GalCat['cat_id']}");
                                if ($Read->getResult()):
                                    foreach ($Read->getResult() as $Gal):
                                        $ImageRemove = "../../uploads/{$Gal['gallery_cover']}";
                                        if (file_exists($ImageRemove) && !is_dir($ImageRemove)):
                                            unlink($ImageRemove);
                                        endif;
                                        $Delete->ExeDelete(DB_LP_GALLERY, "WHERE gallery_id = :id", "id={$Gal['gallery_id']}");
                                    endforeach;
                                endif;
                                $Delete->ExeDelete(DB_LP_GALLERY_CAT, "WHERE cat_id = :id", "id={$GalCat['cat_id']}");
                            endforeach;
                            $jSON['success'] = true;
                        endif;
                        break;
                    case 3:
                        $Delete->ExeDelete(DB_LP_VIDEOS, "WHERE video_section = :id", "id={$SectionId}");
                        break;
                    case 4:
                        $Delete->ExeDelete(DB_LP_DEPOIMENTOS, "WHERE depoimento_section = :id", "id={$SectionId}");
                        break;
                    case 5:
                        $Delete->ExeDelete(DB_LP_VIDEOS, "WHERE video_section = :id", "id={$SectionId}");
                        break;
                    case 6:
                        $Delete->ExeDelete(DB_LP_POSTS, "WHERE post_section = :id", "id={$SectionId}");
                        break;
                    case 8:
                        $Delete->ExeDelete(DB_LP_PERGUNTAS, "WHERE pergunta_section = :id", "id={$SectionId}");
                        break;
                    case 9:
                        $Delete->ExeDelete(DB_LP_SERVICE, "WHERE service_section = :id", "id={$SectionId}");
                        break;
                    case 10:
                        $Delete->ExeDelete(DB_LP_SOBRE, "WHERE sobre_section = :id", "id={$SectionId}");
                        break;
                    case 11:
                        $Delete->ExeDelete(DB_LP_AUTOR, "WHERE autor_section = :id", "id={$SectionId}");
                        break;
                    case 12:
                        $Delete->ExeDelete(DB_LP_PALESTRANTES, "WHERE palestrante_section = :id", "id={$SectionId}");
                        break;
                    case 13:
                        $Delete->ExeDelete(DB_LP_MAP, "WHERE map_section = :id", "id={$SectionId}");
                        break;
                endswitch;

                $Delete->ExeDelete(DB_LP_SECTIONS, "WHERE section_id = :id", "id={$SectionId}");
            endforeach;
            $Delete->ExeDelete(DB_LP_INPUTS, "WHERE input_page = :page", "page={$LpId}");
            $Delete->ExeDelete(DB_LP_PAGES, "WHERE page_id = :page", "page={$LpId}");

            $jSON['success'] = true;
            $jSON['redirect'] = "dashboard.php?wc=activepages/home";
            break;
        case 'section_delete':

            $SectionId = $PostData['del_id'];
            $Read->ExeRead(DB_LP_SECTIONS, "WHERE section_id = :id", "id={$SectionId}");

            $Section = $Read->getResult()[0];

            switch ($Section['section_type']):
                case 2:
                    $Read->ExeRead(DB_LP_GALLERY_CAT, "WHERE cat_section = :id", "id={$SectionId}");
                    if ($Read->getResult()):
                        foreach ($Read->getResult() as $GalCat):
                            $Read->FullRead("SELECT gallery_cover, gallery_id FROM " . DB_LP_GALLERY . " WHERE gallery_cat = :id", "id={$GalCat['cat_id']}");
                            if ($Read->getResult()):
                                foreach ($Read->getResult() as $Gal):
                                    $ImageRemove = "../../uploads/{$Gal['gallery_cover']}";
                                    if (file_exists($ImageRemove) && !is_dir($ImageRemove)):
                                        unlink($ImageRemove);
                                    endif;
                                    $Delete->ExeDelete(DB_LP_GALLERY, "WHERE gallery_id = :id", "id={$Gal['gallery_id']}");
                                endforeach;
                            endif;
                            $Delete->ExeDelete(DB_LP_GALLERY_CAT, "WHERE cat_id = :id", "id={$GalCat['cat_id']}");
                        endforeach;
                        $jSON['success'] = true;
                    endif;
                    break;
                case 3:
                    $Delete->ExeDelete(DB_LP_VIDEOS, "WHERE video_section = :id", "id={$SectionId}");
                    break;
                case 4:
                    $Delete->ExeDelete(DB_LP_DEPOIMENTOS, "WHERE depoimento_section = :id", "id={$SectionId}");
                    break;
                case 5:
                    $Delete->ExeDelete(DB_LP_VIDEOS, "WHERE video_section = :id", "id={$SectionId}");
                    break;
                case 6:
                    $Delete->ExeDelete(DB_LP_POSTS, "WHERE post_section = :id", "id={$SectionId}");
                    break;
                case 8:
                    $Delete->ExeDelete(DB_LP_PERGUNTAS, "WHERE pergunta_section = :id", "id={$SectionId}");
                    break;
                case 9:
                    $Delete->ExeDelete(DB_LP_SERVICE, "WHERE service_section = :id", "id={$SectionId}");
                    break;
                case 10:
                    $Delete->ExeDelete(DB_LP_SOBRE, "WHERE sobre_section = :id", "id={$SectionId}");
                    break;
                case 11:
                    $Delete->ExeDelete(DB_LP_AUTOR, "WHERE autor_section = :id", "id={$SectionId}");
                    break;
                case 12:
                    $Delete->ExeDelete(DB_LP_PALESTRANTES, "WHERE palestrante_section = :id", "id={$SectionId}");
                    break;
                case 13:
                    $Delete->ExeDelete(DB_LP_MAP, "WHERE map_section = :id", "id={$SectionId}");
                    break;
            endswitch;

            $Delete->ExeDelete(DB_LP_SECTIONS, "WHERE section_id = :id", "id={$SectionId}");


            $jSON['success'] = true;

            break;
        // EDITAR DEPOIMENTO
        case 'edit_depoimento':
            $DepoimentoId = $PostData['depoimento_id'];
            $PostData['depoimento_section'] = $PostData['section_id'];
            $PostData['depoimento_page'] = $PostData["page_id"];
            unset($PostData['depoimento_id'], $PostData["page_id"], $PostData['section_id']);
            $Update->ExeUpdate(DB_LP_DEPOIMENTOS, $PostData, "WHERE depoimento_id = :id", "id={$DepoimentoId}");

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PostData['depoimento_page']}&id={$PostData['depoimento_section']}";
            break;
        // REMOVER DEPOIMENTO
        case 'delete_depoimento':
            $DepoimentoId = $PostData['del_id'];

            $Delete->ExeDelete(DB_LP_DEPOIMENTOS, "WHERE depoimento_id = :id", "id={$DepoimentoId}");

            $jSON['success'] = true;
            break;
        // NOVO VÍDEO
        case 'add_video':
            $PostData['video_section'] = $PostData['section_id'];
            $PostData['video_page'] = $PostData["page_id"];
            unset($PostData["page_id"], $PostData['video_id'], $PostData['section_id']);

            $Create->ExeCreate(DB_LP_VIDEOS, $PostData);

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PostData['video_page']}&id={$PostData['video_section']}";

            break;
        // EDITAR VÍDEO
        case 'edit_video':
            $PostData['video_section'] = $PostData['section_id'];
            $VideoId = $PostData['video_id'];
            $PostData['video_page'] = $PostData["page_id"];
            unset($PostData['video_id'], $PostData["page_id"], $PostData['section_id']);
            $Update->ExeUpdate(DB_LP_VIDEOS, $PostData, "WHERE video_id = :id", "id={$VideoId}");

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PostData['video_page']}&id={$PostData['video_section']}";
            break;
        // REMOVER VÍDEO
        case 'delete_video':
            $VideoId = $PostData['del_id'];

            $Delete->ExeDelete(DB_LP_VIDEOS, "WHERE video_id = :id", "id={$VideoId}");

            $jSON['success'] = true;
            break;
        // ADICIONAR INPUT
        case 'add_input':
            $PostData['input_page'] = $PostData["page_id"];
            unset($PostData["page_id"], $PostData['input_id']);

            $Create->ExeCreate(DB_LP_INPUTS, $PostData);

            $jSON['redirect'] = "dashboard.php?wc=activepages/create&id={$PostData['input_page']}#captura";

            break;
        // EDITAR INPUT
        case 'edit_input':
            var_dump($PostData);
            $InputId = $PostData['input_id'];
            $PostData['input_page'] = $PostData["page_id"];
            unset($PostData['input_id'], $PostData["page_id"]);

            if (!isset($PostData['input_required'])):
                $PostData['input_required'] = 0;
            endif;

            $Update->ExeUpdate(DB_LP_INPUTS, $PostData, "WHERE input_id = :id", "id={$InputId}");
            $jSON['success'] = true;

            break;
        // REMOVER INPUT
        case 'delete_input':
            $InputId = $PostData['del_id'];

            $Delete->ExeDelete(DB_LP_INPUTS, "WHERE input_id = :id", "id={$InputId}");

            $jSON['success'] = true;
            break;
        case 'sessao_maneger':
            $SessaoId = $PostData['section_id'];
            $Read->ExeRead(DB_LP_SECTIONS, "WHERE section_id = :id", "id={$SessaoId}");

            if (isset($PostData['section_background_color'])):
                $PostData['section_status'] = isset($PostData['section_status']) ? '1' : '0';
            endif;

            if (isset($PostData['section_date'])):
                $PostData['section_date'] = (!empty($PostData['section_date']) && Check::Data($PostData['section_date']) ? Check::Data($PostData['section_date']) : null);
            endif;

            if (isset($PostData['section_title'])):
                $PostData['section_home'] = isset($PostData['section_home']) ? '1' : '0';
                $PostData['section_confirma'] = isset($PostData['section_confirma']) ? '1' : '0';
                $PostData['section_obrigado'] = isset($PostData['section_obrigado']) ? '1' : '0';
            endif;

            if (!empty($_FILES['section_background_img'])):
                $File = $_FILES['section_background_img'];

                if ($ThisCourse['section_background_img'] && file_exists("../../_activepages/{$ThisCourse['section_background_img']}") && !is_dir("../../_activepages/{$ThisCourse['section_background_img']}")):
                    unlink("../../_activepages/{$ThisCourse['section_background_img']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, Check::Name($Read->getResult()[0]['section_title']) . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['section_background_img'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['section_background_img']);
            endif;

            $Update->ExeUpdate(DB_LP_SECTIONS, $PostData, "WHERE section_id = :id", "id={$SessaoId}");
            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>TUDO CERTO: </b> A Sessão</b> foi atualizado com sucesso!");


            break;
        case 'add_galeria':

            if (isset($PostData['cat_status'])):
                $PostData['cat_status'] = 1;
            else:
                $PostData['cat_status'] = 0;
            endif;
            $PageId = $PostData['page_id'];
            unset($PostData['page_id']);

            $Create->ExeCreate(DB_LP_GALLERY_CAT, $PostData);
            $CatId = $Create->getResult();

            if (!empty($_FILES['image'])):
                $File = $_FILES['image'];
                $gbFile = array();
                $gbCount = count($File['type']);
                $gbKeys = array_keys($File);
                $gbLoop = 0;

                for ($gb = 0; $gb < $gbCount; $gb++):
                    foreach ($gbKeys as $Keys):
                        $gbFiles[$gb][$Keys] = $File[$Keys][$gb];
                    endforeach;
                endfor;

                $jSON['gallery'] = null;
                foreach ($gbFiles as $UploadFile):
                    $gbLoop ++;
                    $Upload = new Upload('../../_activepages/');
                    $Upload->Image($UploadFile, Check::Name($PostData['cat_title']) . "-{$gbLoop}-" . time() . base64_encode(time()), 1000);
                    if ($Upload->getResult()):
                        $gbCreate = ['gallery_cat' => $CatId, "gallery_cover" => $Upload->getResult()];
                        $Create->ExeCreate(DB_LP_GALLERY, $gbCreate);
                    endif;
                endforeach;
            endif;

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['cat_section']}";
            break;
        case 'edit_galeria':

            $PageId = $PostData['page_id'];
            unset($PostData['page_id']);


            $CatId = $PostData['cat_id'];

            $Read->ExeRead(DB_LP_GALLERY_CAT, "WHERE cat_id = :id", "id={$CatId}");
            $PostData['cat_title'] = $Read->getResult()[0]['cat_title'];

            if (!empty($_FILES['image'])):
                $File = $_FILES['image'];
                $gbFile = array();
                $gbCount = count($File['type']);
                $gbKeys = array_keys($File);
                $gbLoop = 0;

                for ($gb = 0; $gb < $gbCount; $gb++):
                    foreach ($gbKeys as $Keys):
                        $gbFiles[$gb][$Keys] = $File[$Keys][$gb];
                    endforeach;
                endfor;

                $jSON['gallery'] = null;
                foreach ($gbFiles as $UploadFile):
                    $gbLoop ++;
                    $Upload = new Upload('../../_activepages/');
                    $Upload->Image($UploadFile, Check::Name($PostData['cat_title']) . "-{$gbLoop}-" . time() . base64_encode(time()), 1000);
                    if ($Upload->getResult()):
                        $gbCreate = ['gallery_cat' => $CatId, "gallery_cover" => $Upload->getResult()];
                        $Create->ExeCreate(DB_LP_GALLERY, $gbCreate);
                    endif;
                endforeach;
            endif;

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['cat_section']}";
            break;

        case 'gbremove':
            $Read->FullRead("SELECT gallery_cover FROM " . DB_LP_GALLERY . " WHERE gallery_id = :id", "id={$PostData['img']}");
            if ($Read->getResult()):
                $ImageRemove = "../../uploads/{$Read->getResult()[0]['gallery_cover']}";
                if (file_exists($ImageRemove) && !is_dir($ImageRemove)):
                    unlink($ImageRemove);
                endif;
                $Delete->ExeDelete(DB_LP_GALLERY, "WHERE gallery_id = :id", "id={$PostData['img']}");
                $jSON['success'] = true;
            endif;
            break;
        case 'galeria_legenda':
            $GaleriaId = $PostData['gallery_id'];

            $Update->ExeUpdate(DB_LP_GALLERY, $PostData, "WHERE gallery_id = :id", "id={$GaleriaId}");
            break;
        case 'delete_cat':
            $CatId = $PostData['del_id'];

            $Read->ExeRead(DB_LP_GALLERY, "WHERE gallery_cat = :id", "id={$CatId}");
            if ($Read->getResult()):
                foreach ($Read->getResult() as $Gallery):
                    $ImageRemove = "../../uploads/{$Gallery['gallery_cover']}";
                    if (file_exists($ImageRemove) && !is_dir($ImageRemove)):
                        unlink($ImageRemove);
                    endif;
                    $Delete->ExeDelete(DB_LP_GALLERY, "WHERE gallery_id = :id", "id={$Gallery['gallery_id']}");
                endforeach;
            endif;

            $Delete->ExeDelete(DB_LP_GALLERY_CAT, "WHERE cat_id = :id", "id={$CatId}");

            $jSON['success'] = true;

            break;
        case 'add_post':

            $PageId = $PostData['page_id'];
            unset($PostData['page_id']);

            $Create->ExeCreate(DB_LP_POSTS, $PostData);

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['post_section']}";
            break;
        case 'delete_post':
            $PostId = $PostData['del_id'];
            $Delete->ExeDelete(DB_LP_POSTS, "WHERE id = :id", "id={$PostId}");

            $jSON['success'] = true;
            break;
        case 'find_pdt':
            $PdtId = $PostData['key'];

            $Read->ExeRead(DB_PDT, "WHERE pdt_id = :id", "id={$PdtId}");
            $jSON['pdt_offer_price'] = number_format($Read->getResult()[0]['pdt_offer_price'], '2', ',', '.');
            $jSON['pdt_offer_start'] = $Read->getResult()[0]['pdt_offer_start'] ? date("d/m/Y h:i", strtotime($Read->getResult()[0]['pdt_offer_start'])) : '';
            $jSON['pdt_offer_end'] = $Read->getResult()[0]['pdt_offer_end'] ? date("d/m/Y h:i", strtotime($Read->getResult()[0]['pdt_offer_end'])) : '';
            break;
        case 'add_oferta':
            $PageId = $PostData['page_id'];
            $SectionId = $PostData['section_id'];
            $Section['section_promo_type'] = $PostData['section_promo_type'];
            unset($PostData['page_id'], $PostData['section_id']);

            if ($Section['section_promo_type'] == 1):
                if (!empty($PostData['pdt_offer_start']) && (!Check::Data($PostData['pdt_offer_start']) || !Check::Data($PostData['pdt_offer_end']))):
                    $jSON['trigger'] = AjaxErro("<b class='icon-warning'>Erro ao atualizar:</b> Desculpe {$_SESSION['userLogin']['user_name']}, mas a(s) data(s) de oferta foi informada com erro de calendário. Veja isso!", E_USER_WARNING);
                else:
                    $Section['section_pdt'] = $PostData['section_pdt'];
                    $Update->ExeUpdate(DB_LP_SECTIONS, $Section, "WHERE section_id = :id", "id={$SectionId}");

                    $Pdt['pdt_offer_price'] = ($PostData['pdt_offer_price'] ? str_replace(',', '.', str_replace('.', '', $PostData['pdt_offer_price'])) : null);
                    $Pdt['pdt_offer_start'] = (!empty($PostData['pdt_offer_start']) && Check::Data($PostData['pdt_offer_start']) ? Check::Data($PostData['pdt_offer_start']) : null);
                    $Pdt['pdt_offer_end'] = (!empty($PostData['pdt_offer_end']) && Check::Data($PostData['pdt_offer_end']) ? Check::Data($PostData['pdt_offer_end']) : null);


                    $Update->ExeUpdate(DB_PDT, $Pdt, "WHERE pdt_id = :id", "id={$Section['section_pdt']}");

                    $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>TUDO CERTO: </b> A OFERTA</b> foi atualizada com sucesso!");
                endif;
            elseif ($Section['section_promo_type'] == 2 || $Section['section_promo_type'] == 3):
                if (!empty($PostData['section_promo_start']) && (!Check::Data($PostData['section_promo_start']) || !Check::Data($PostData['section_promo_end']))):
                    $jSON['trigger'] = AjaxErro("<b class='icon-warning'>Erro ao atualizar:</b> Desculpe {$_SESSION['userLogin']['user_name']}, mas a(s) data(s) de oferta foi informada com erro de calendário. Veja isso!", E_USER_WARNING);
                else:
                    if ($Section['section_promo_type'] == 2):
                        $Section['section_curso'] = $PostData['section_curso'];
                    endif;
                    if ($Section['section_promo_type'] == 3):
                        $Section['section_price'] = ($PostData['section_price'] ? str_replace(',', '.', str_replace('.', '', $PostData['section_price'])) : null);
                    endif;
                    $Section['section_promo_parcelas'] = $PostData['section_promo_parcelas'];
                    $Section['section_promo_price'] = ($PostData['section_promo_price'] ? str_replace(',', '.', str_replace('.', '', $PostData['section_promo_price'])) : null);
                    $Section['section_promo_start'] = (!empty($PostData['section_promo_start']) && Check::Data($PostData['section_promo_start']) ? Check::Data($PostData['section_promo_start']) : null);
                    $Section['section_promo_end'] = (!empty($PostData['section_promo_end']) && Check::Data($PostData['section_promo_end']) ? Check::Data($PostData['section_promo_end']) : null);

                    $Update->ExeUpdate(DB_LP_SECTIONS, $Section, "WHERE section_id = :id", "id={$SectionId}");
                    $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>TUDO CERTO: </b> A OFERTA</b> foi atualizada com sucesso!");
                endif;
            endif;
            break;
        case 'add_pergunta':
            $PageId = $PostData['page_id'];
            unset($PostData['page_id'], $PostData['pergunta_id']);

            $Create->ExeCreate(DB_LP_PERGUNTAS, $PostData);

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['pergunta_section']}";
            break;
        case 'edit_pergunta':
            $PageId = $PostData['page_id'];
            $Pergunta = $PostData['pergunta_id'];
            unset($PostData['page_id'], $PostData['pergunta_id']);

            $Update->ExeUpdate(DB_LP_PERGUNTAS, $PostData, "WHERE pergunta_id = :id", "id={$Pergunta}");

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['pergunta_section']}";
            break;
        case 'delete_pergunta':
            $PerguntaId = $PostData['del_id'];
            $Delete->ExeDelete(DB_LP_PERGUNTAS, "WHERE pergunta_id = :id", "id={$PerguntaId}");

            $jSON['success'] = true;
            break;
        case 'add_service':
            $PageId = $PostData['page_id'];
            unset($PostData['page_id'], $PostData['service_id']);

            $Create->ExeCreate(DB_LP_SERVICE, $PostData);

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['service_section']}";
            break;
        case 'edit_service':
            $PageId = $PostData['page_id'];
            $Service = $PostData['service_id'];
            unset($PostData['page_id'], $PostData['service_id']);

            $Update->ExeUpdate(DB_LP_SERVICE, $PostData, "WHERE service_id = :id", "id={$Service}");

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['service_section']}";
            break;
        case 'delete_service':
            $ServiceId = $PostData['del_id'];
            $Delete->ExeDelete(DB_LP_SERVICE, "WHERE service_id = :id", "id={$ServiceId}");

            $jSON['success'] = true;
            break;
        case 'add_palestrante':
            $PageId = $PostData['page_id'];
            unset($PostData['page_id'], $PostData['service_id']);


            if (!empty($_FILES['palestrante_cover'])):
                $File = $_FILES['palestrante_cover'];


                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, $PostData['palestrante_title'] . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['palestrante_cover'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['palestrante_cover']);
            endif;



            $Create->ExeCreate(DB_LP_PALESTRANTES, $PostData);

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['palestrante_section']}";
            break;
        case 'edit_palestrante':
            $PageId = $PostData['page_id'];
            $Palestrante = $PostData['palestrante_id'];
            unset($PostData['page_id'], $PostData['palestrante_id']);

            if (!empty($_FILES['palestrante_cover'])):
                $File = $_FILES['palestrante_cover'];
                $Read->ExeRead(DB_LP_PALESTRANTES, "WHERE palestrante_id = :id", "id={$Palestrante}");
                $ThisPalestrante = $Read->getResult()[0];

                if (isset($ThisPalestrante) && $ThisPalestrante['palestrante_cover'] && file_exists("../../_activepages/{$ThisPalestrante['palestrante_cover']}") && !is_dir("../../_activepages/{$ThisPalestrante['palestrante_cover']}")):
                    unlink("../../_activepages/{$ThisPalestrante['palestrante_cover']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, $PostData['palestrante_title'] . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['palestrante_cover'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['palestrante_cover']);
            endif;

            $Update->ExeUpdate(DB_LP_PALESTRANTES, $PostData, "WHERE palestrante_id = :id", "id={$Palestrante}");

            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['palestrante_section']}";
            break;
        case 'delete_palestrante':
            $ServiceId = $PostData['del_id'];
            $Delete->ExeDelete(DB_LP_PALESTRANTES, "WHERE palestrante_id = :id", "id={$ServiceId}");

            $jSON['success'] = true;
            break;
        case 'add_autor':
            $PageId = $PostData['page_id'];
            $AutorId = $PostData['autor_id'];
            unset($PostData['page_id'], $PostData['autor_id']);


            if (!empty($_FILES['autor_cover'])):
                $File = $_FILES['autor_cover'];
                $Read->ExeRead(DB_LP_AUTOR, "WHERE autor_id = :id", "id={$AutorId}");
                if ($Read->getResult()):
                    $ThisPalestrante = $Read->getResult()[0];
                endif;
                if (isset($ThisPalestrante) && $ThisPalestrante['autor_cover'] && file_exists("../../_activepages/{$ThisPalestrante['autor_cover']}") && !is_dir("../../_activepages/{$ThisPalestrante['autor_cover']}")):
                    unlink("../../_activepages/{$ThisPalestrante['autor_cover']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, $PostData['autor_title'] . '-' . time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['autor_cover'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['autor_cover']);
            endif;


            if ($AutorId):
                $Update->ExeUpdate(DB_LP_AUTOR, $PostData, "WHERE autor_id = :id", "id={$AutorId}");
            else:
                $Create->ExeCreate(DB_LP_AUTOR, $PostData);
            endif;

            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> Autor salvo com sucesso", E_USER_DEPRECATED);


//            $jSON['redirect'] = "dashboard.php?wc=activepages/sessao&active={$PageId}&id={$PostData['autor_section']}";
            break;
        case 'add_sobre':
            $PageId = $PostData['page_id'];
            $AutorId = $PostData['sobre_id'];
            unset($PostData['page_id'], $PostData['sobre_id']);


            if (!empty($_FILES['sobre_cover'])):
                $File = $_FILES['sobre_cover'];
                $Read->ExeRead(DB_LP_SOBRE, "WHERE sobre_id = :id", "id={$AutorId}");
                if ($Read->getResult()):
                    $ThisPalestrante = $Read->getResult()[0];
                endif;
                if (isset($ThisPalestrante) && $ThisPalestrante['sobre_cover'] && file_exists("../../_activepages/{$ThisPalestrante['sobre_cover']}") && !is_dir("../../_activepages/{$ThisPalestrante['sobre_cover']}")):
                    unlink("../../_activepages/{$ThisPalestrante['sobre_cover']}");
                endif;

                $Upload = new Upload('../../_activepages/');
                $Upload->Image($File, time(), IMAGE_W, 'images');
                if ($Upload->getResult()):
                    $PostData['sobre_cover'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['sobre_cover']);
            endif;


            if ($AutorId):
                $Update->ExeUpdate(DB_LP_SOBRE, $PostData, "WHERE sobre_id = :id", "id={$AutorId}");
            else:
                $Create->ExeCreate(DB_LP_SOBRE, $PostData);
            endif;

            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> Sobre salvo com sucesso", E_USER_DEPRECATED);


            break;
        case 'section_order':
            if (is_array($PostData['Data'])):
                foreach ($PostData['Data'] as $RE):
                    $UpdateMod = ['section_order' => $RE[1]];
                    $Update->ExeUpdate(DB_LP_SECTIONS, $UpdateMod, "WHERE section_id=:mod", "mod={$RE[0]}");
                endforeach;

                $jSON['sucess'] = true;
            endif;
            break;
        case 'add_map':
            $PageId = $PostData['page_id'];
            $AutorId = $PostData['map_id'];
            unset($PostData['page_id'], $PostData['map_id']);

            if ($AutorId):
                $Update->ExeUpdate(DB_LP_MAP, $PostData, "WHERE map_id = :id", "id={$AutorId}");
            else:
                $Create->ExeCreate(DB_LP_MAP, $PostData);
            endif;

            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> Mapa salvo com sucesso", E_USER_DEPRECATED);


            break;
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;

