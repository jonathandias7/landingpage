<?php

session_start();
require '../../_app/Config.inc.php';
$NivelAcess = 6;

if (empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'MDPCustom';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);

    // AUTO INSTANCE OBJECT READ
    if (empty($Read)):
        $Read = new Read;
    endif;

    // AUTO INSTANCE OBJECT CREATE
    if (empty($Create)):
        $Create = new Create;
    endif;

    // AUTO INSTANCE OBJECT UPDATE
    if (empty($Update)):
        $Update = new Update;
    endif;

    // AUTO INSTANCE OBJECT DELETE
    if (empty($Delete)):
        $Delete = new Delete;
    endif;
     switch ($Case):
           case 'sendimage_logo':
               
                
             $NewImage = $_FILES['image'];
                
              
                $Upload = new Upload('../../themes/'. THEME .'/images/');
                $Upload->Image($_FILES['image'],'logo');
                   if($Upload->getResult()):
                       
                       //RESULT THEME
                       if(file_exists('../../themes/'. THEME .'/images/logo.png')):
                           unlink('../../themes/'. THEME .'/images/logo.png');
                         endif;
                        copy('../../themes/'. THEME .'/images/' .$Upload->getResult(), '../../themes/'. THEME .'/images/logo.png');
                     
                     
                     //RESULT SEO WC
                     
                      //pasta images 
                     if(file_exists('../../themes/'. THEME .'/images/logo.png')):
                           unlink('../../themes/'. THEME .'/images/logo.png');
                     endif;
                   
                     copy('../../themes/'. THEME .'/images/' .$Upload->getResult(), '../../themes/'. THEME .'/images/logo.png');
                         
                        $jSON['redirect'] = "dashboard.php?wc=mdpcustom/create&id=1";
                        $jSON['success'] = true;
                    
                  
                   endif;
                
               
             
             
         
             break;   
              case 'sendimage_fundo':
               
                
             $NewImage = $_FILES['image'];
                
              
                $Upload = new Upload('../../themes/'. THEME .'/img/');
                $Upload->Image($_FILES['image'],'default');
                   if($Upload->getResult()):
                       
                       //RESULT THEME
                       if(file_exists('../../themes/'. THEME .'/img/default.jpg')):
                           unlink('../../themes/'. THEME .'/img/default.jpg');
                         endif;
                        copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/img/default.jpg');
                     
                     
                     //RESULT SEO WC
                     
                      //pasta images 
                     if(file_exists('../../themes/'. THEME .'/images/default.jpg')):
                           unlink('../../themes/'. THEME .'/images/default.jpg');
                     endif;
                   
                     copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/images/default.jpg');
                         
            
                        $jSON['redirect'] = "dashboard.php?wc=mdpcustom/create&id=1";
                        $jSON['success'] = true;
                    
                  
                   endif;
                
               
             
             
         
             break; 
             
             case 'sendimage_fundo1':
               
                
             $NewImage = $_FILES['image'];
                
              
                $Upload = new Upload('../../themes/'. THEME .'/img/');
                $Upload->Image($_FILES['image'],'default1');
                   if($Upload->getResult()):
                       
                       //RESULT THEME
                       if(file_exists('../../themes/'. THEME .'/img/default.jpg')):
                           unlink('../../themes/'. THEME .'/img/default1.jpg');
                         endif;
                        copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/img/default1.jpg');
                     
                     
                     //RESULT SEO WC
                     
                      //pasta images 
                     if(file_exists('../../themes/'. THEME .'/images/default1.jpg')):
                           unlink('../../themes/'. THEME .'/images/default1.jpg');
                     endif;
                   
                     copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/images/default1.jpg');
                         
            
                        $jSON['redirect'] = "dashboard.php?wc=mdpcustom/create&id=1";
                        $jSON['success'] = true;
                    
                  
                   endif;
                
               
             
             
         
             break; 
             
             case 'sendimage_fundo2':
               
                
             $NewImage = $_FILES['image'];
                
              
                $Upload = new Upload('../../themes/'. THEME .'/img/');
                $Upload->Image($_FILES['image'],'default2');
                   if($Upload->getResult()):
                       
                       //RESULT THEME
                       if(file_exists('../../themes/'. THEME .'/img/default2.jpg')):
                           unlink('../../themes/'. THEME .'/img/default2.jpg');
                         endif;
                        copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/img/default2.jpg');
                     
                     
                     //RESULT SEO WC
                     
                      //pasta images 
                     if(file_exists('../../themes/'. THEME .'/images/default2.jpg')):
                           unlink('../../themes/'. THEME .'/images/default2.jpg');
                     endif;
                   
                     copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/images/default2.jpg');
                         
            
                        $jSON['redirect'] = "dashboard.php?wc=mdpcustom/create&id=1";
                        $jSON['success'] = true;
                    
                  
                   endif;
                
               
             
             
         
             break; 
              case 'sendimage_icon':
               
                
             $NewImage = $_FILES['image'];
                
              
                $Upload = new Upload('../../themes/'. THEME .'/img/');
                $Upload->Image($_FILES['image'],'favicon');
                   if($Upload->getResult()):
                       
                       //RESULT THEME
                       //pasta img
                       if(file_exists('../../themes/'. THEME .'/img/favicon.png')):
                           unlink('../../themes/'. THEME .'/img/favicon.png');
                        endif;
                        
                        copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/img/favicon.png');
                     
                     
                    
                     
                     //RESULT SEO WC
                     
                      //pasta images 
                     if(file_exists('../../themes/'. THEME .'/images/favicon.png')):
                           unlink('../../themes/'. THEME .'/images/favicon.png');
                     endif;
                   
                     copy('../../themes/'. THEME .'/img/' .$Upload->getResult(), '../../themes/'. THEME .'/images/favicon.png');
                         
                         
                    
                    
                  
                   endif;
                
                 $jSON['redirect'] = "dashboard.php?wc=mdpcustom/create&id=1";
                        $jSON['success'] = true;
         
             break;   
             
        case 'custom_update':
          $mdpid = $PostData['custom_id'];
          unset($PostData['custom_id']);
    
         $Update->ExeUpdate("mdp_custom", $PostData,"WHERE custom_id = :id","id={$mdpid}") ;
        
         $jSON['trigger'] = AjaxErro('<b class="icon-checkmarked">Sucesso!</b> A Customização foi atualizada com sucesso.');
     $jSON['success'] = true;
    break;
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;
