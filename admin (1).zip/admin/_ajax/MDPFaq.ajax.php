<?php

session_start();
require '../../_app/Config.inc.php';
$NivelAcess = 6;
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
if (empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'MDPFaq';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);
	/*****************************/
	/**** AÇÕES INSTANCIADAS *****/
	/*****************************/
    $Read = new Read;
    $Create = new Create;
    $Update = new Update;
    $Delete = new Delete;

 
	
	////////////////////////////////////////////////////////////////////////
	//////////////////////////* PLANOS *///////////////////////
	////////////////////////////////////////////////////////////////////////
    
 
 
 
 
 /*****************************/
 /*** BATERIA DA APP PLANOS ***/
 /*****************************/
	switch ($Case):
	
	//////////// UPDATE/////////////////////

	case 'faq_create':
		$Update->ExeUpdate("mdp_faq", $PostData, "WHERE faq_id = :id", "id={$PostData['faq_id']}");
		$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> O FAQ <b>{$PostData['faq_title']}</b> foi atualizado com sucesso!");
		
	break;
	//////////// DELETE /////////////////////
		 case 'faq_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM mdp_faq WHERE faq_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete("mdp_faq", "WHERE faq_id = :id","id={$delAv}");
		$Delete->ExeDelete("mdp_faq_resp", "WHERE faq_id = :id","id={$delAv}");
		$jSON['success'] = true;
		
		break;
	
		case 'faq_resp_create':
		$Update->ExeUpdate("mdp_faq_resp", $PostData, "WHERE faq_resp_id = :id", "id={$PostData['faq_resp_id']}");
		$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> O FAQ <b>{$PostData['faq_resp_title']}</b> foi atualizado com sucesso!");
		
	break;
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;