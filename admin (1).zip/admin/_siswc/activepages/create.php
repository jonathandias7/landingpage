<?php
$AdminLevel = LEVEL_WC_ACTIVEPAGES;
if (!APP_ACTIVEPAGES || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

$PageId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($PageId):
    $Read->ExeRead(DB_LP_PAGES, "WHERE page_id = :id", "id={$PageId}");
    if ($Read->getResult()):
        $FormData = array_map('htmlspecialchars', $Read->getResult()[0]);
        extract($FormData);
    else:
        $_SESSION['trigger_controll'] = "<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma landing page que não existe ou que foi removido recentemente!";
        header('Location: dashboard.php?wc=activepages/home');
    endif;
else:
    $PostCreate = ['page_status' => 0, 'page_gate' => 1, 'page_gate_name' => 'confirma,obrigado', 'page_teste' => 'email,livro,video',
        'page_index' => 'home_video', 'page_confirm' => 'confirma_text', 'page_tankyou' => 'obrigado_video'];
    $Create->ExeCreate(DB_LP_PAGES, $PostCreate);

    $CreatePage = $Create->getResult();

    $InputCreate = ['input_type' => 'text', 'input_name' => 'fullname', 'input_class' => 'name', 'input_placeholder' => 'Nome:', 'input_required' => 1, 'input_page' => $CreatePage];
    $Create->ExeCreate(DB_LP_INPUTS, $InputCreate);

    $InputCreate = ['input_type' => 'email', 'input_name' => 'email', 'input_class' => 'email', 'input_placeholder' => 'Email:', 'input_required' => 1, 'input_page' => $CreatePage];
    $Create->ExeCreate(DB_LP_INPUTS, $InputCreate);
    header('Location: dashboard.php?wc=activepages/create&id=' . $CreatePage);
endif;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-new-tab"><?= $page_title ? "Editar " . $page_title : 'Nova Landign Page'; ?></h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=activepages/home">Landings Pages</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=activepages/page_gerent&id=<?= $page_id; ?>">Gerenciar <?= $page_title; ?></a>
        </p>
    </div>

    <div class="dashboard_header_search" id="<?= $PageId; ?>">
        <a title="Gerenciar Landing Page!" href="dashboard.php?wc=activepages/sessoes&id=<?= $PageId ?>" class="wc_view btn btn_green icon-page-break">Seções!</a>
        <a target="_blank" title="Ver Landing Page!" href="<?= BASE ?>/<?= $page_name; ?>" class="wc_view btn btn_blue icon-eye">Ver LP!</a>
        <span rel='dashboard_header_search' class='j_delete_action icon-warning btn btn_red' id='<?= $PageId; ?>'>Deletar LP!</span>
        <span rel='dashboard_header_search' callback='LandingPages' callback_action='delete' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='<?= $PageId; ?>'>EXCLUIR AGORA!</span>
    </div>
</header>

<div class="dashboard_content">
    <div class="box box70">
        <div class="panel wc_tab_target wc_active" id="course">
            <form class="auto_save" name="page_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>
                <input type="hidden" name="status" value="<?= 1 ?>"/>
                <label class="label">
                    <span class="legend">Título Página:</span>
                    <input style="font-size: 1.4em;" type="text" name="page_title" value="<?= $page_title; ?>" required/>
                </label>
                <label class="label">
                    <input type="checkbox" style="display: inline-block;width: auto;" name="page_base" value="1" <?= $page_base ? 'checked' : '' ?>> Usuar como página inicial do site
                </label>

                <label class="label">
                    <span class="legend">Capa: (JPG <?= IMAGE_W; ?>x<?= IMAGE_H; ?>px)</span>
                    <input type="file" class="wc_loadimage" name="page_cover"/>
                </label>
                <?php
                $PageLogo = (!empty($page_logo) && file_exists("../_activepages/{$page_logo}") && !is_dir("../_activepages/{$page_logo}") ? "_activepages/{$page_logo}" : 'admin/_img/no_image.jpg');
                ?>
                <label class="label">
                    <img class="course_thumb page_logo" alt="Logo" title="Logo" src="../tim.php?src=<?= $PageLogo; ?>&w=<?= IMAGE_W / 2 ?>&h=<?= IMAGE_H / 2; ?>" default="../tim.php?src=<?= $PageLogo; ?>&w=<?= IMAGE_W / 2; ?>&h=<?= IMAGE_H / 2; ?>"/>                    
                </label>
                <label class="label">
                    <span class="legend">Logo: (JPG <?= IMAGE_W; ?>x<?= IMAGE_H; ?>px)</span>
                    <input type="file" class="wc_loadimage" name="page_logo"/>
                </label>


                <label class="label">
                    <span class="legend">Cor Botão</span>
                    <select name="page_ac_button_color">
                        <?php foreach (getWcButtonStyle() as $Key => $Value):
                            ?>
                            <option <?= $page_ac_button_color == $Key ? 'selected' : ''; ?> value="<?= $Key ?>"><?= $Value ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>



                <div class="label_50">
                    <label class="label">
                        <span class="legend">TRAVAR PÁGINAS</span>
                        <select name="page_gate">
                            <option value="1">Sim</option>
                            <option value="0">Não</option>
                        </select>
                    </label>
                    <label class="label">
                        <span class="legend">PÁGINAS BLOQUEADAS (pagina_1, pagina_2)</span>
                        <input type="text" name="page_gate_name" value="<?= $page_gate_name; ?>" required/>
                    </label>
                </div>

                <div class="label_50">
                    <label class="label">
                        <span class="legend">PÁGINAS TESTES (pagina_1, pagina_2)</span>
                        <input type="text" name="page_teste" value="<?= $page_teste; ?>" required/>
                    </label>                    

                    <label class="label">
                        <span class="legend icon-link">Link Alternativo:</span>
                        <input type="text" name="page_name" value="<?= $page_name; ?>" placeholder="Link do Curso:"/>
                    </label>
                </div>

                <div class="label_50">
                    <label class="label">
                        <span class="legend">DATA LANÇAMENTO:</span>
                        <input type="text" class="formTime" name="page_date_start" value="<?= $page_date_start ? date('d/m/Y H:i', strtotime($page_date_start)) : ''; ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">DATA ENCERRAMENTO:</span>
                        <input type="text" class="formTime" name="page_date_and" value="<?= $page_date_and ? date('d/m/Y H:i', strtotime($page_date_and)) : ''; ?>" />
                    </label>

                </div>

                <div class="wc_actions">
                    <label class="label_check label_publish <?= ($page_status == 1 ? 'active' : ''); ?>"><input style="margin-top: -1px;" type="checkbox" value="1" name="page_status" <?= ($page_status == 1 ? 'checked' : ''); ?>> Publicar Agora!</label>
                    <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>
            </form>
        </div>

        <div class="wc_tab_target none" id="home">
            <form class="panel auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                <label class="label">
                    <span class="legend">PÁGINA INICIAL</span>
                    <select name="page_index">
                        <?php foreach (getWcHomeType() as $Key => $Value):
                            ?>
                            <option <?= $page_index == $Key ? 'selected' : ''; ?> value="<?= $Key ?>"><?= $Value ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="label">
                    <span class="legend">PÁGINA VÍDEO</span>
                    <input type="text" name="page_video_captura" value="<?= $page_video_captura; ?>" required/>
                </label>
                <?php
                $PageLivro = (!empty($page_ebook_img) && file_exists("../_activepages/{$page_ebook_img}") && !is_dir("../_activepages/{$page_ebook_img}") ? "_activepages/{$page_ebook_img}" : 'admin/_img/no_image.jpg');
                ?>
                <label class="label">
                    <img class="course_thumb page_ebook_img" alt="Livro" title="Livro" src="../tim.php?src=<?= $PageLivro; ?>&w=318&h=348" default="../tim.php?src=<?= $PageLivro; ?>&w=<?= IMAGE_W / 2; ?>&h=<?= IMAGE_H / 2; ?>"/>                    
                </label>
                <label class="label">
                    <span class="legend">PÁGINA LIVRO IMG: (JPG 318X348px)</span>
                    <input type="file" class="wc_loadimage" name="page_ebook_img"/>
                </label>

                <label class="label">
                    <span class="legend">PÁGINA BOTÃO</span>
                    <select name="page_button">
                        <option value="0">Nenhum</option>
                        <?php foreach (getWcButtonType() as $Key => $Value):
                            ?>
                            <option <?= $page_button == $Key ? 'selected' : ''; ?> value="<?= $Key ?>"><?= $Value ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="label">
                    <span class="legend">Headline:</span>
                    <input type="text" name="page_headline" value="<?= $page_headline; ?>" required/>
                </label>

                <label class="label">
                    <span class="legend">Tag Copy</span>
                    <input type="text" name="page_tag_copy" value="<?= $page_tag_copy; ?>" required/>
                </label>

                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>

            </form>
        </div>
        <div class="wc_tab_target none" id="captura">
            <div class="box_content wc_normalize_height panel_header" style="margin-top: 5px;">
                <h2>Formulário de Captura</h2>
            </div>

            <form class="panel auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                <div class="label_50">
                    <label class="label">
                        <span class="legend">BOTÃO CAPTURA</span>
                        <input type="text" name="page_ac_button" value="<?= $page_ac_button; ?>" required/>
                    </label>
                    <label class="label">
                        <span class="legend">BOTÃO REGISTRAR</span>
                        <input type="text" name="page_ac_register" value="<?= $page_ac_register; ?>" required/>
                    </label>
                </div>
                <label class="label page_ac_type">
                    <span>Ferramenta de Captura:</span>
                    <input type="radio" rel="lp_activecampaing" name="page_ac_type" value="1" <?= !$page_ac_type || $page_ac_type == 1 ? 'checked' : '' ?> /> ActiveCampaign
                    <input type="radio" rel="lp_codigo" name="page_ac_type" value="2" <?= $page_ac_type && $page_ac_type == 2 ? 'checked' : '' ?>/> Código HTML
                </label>
                <div class="lp_activecampaing lp_type" <?= !$page_ac_type && $page_ac_type == 2 ? 'style="display: none;"' : '' ?>>
                    <div class="label_50">
                        <label class="label">
                            <span class="legend">Active Campaing Host</span>
                            <input type="text" name="page_ac_host" value="<?= $page_ac_host; ?>" required/>
                        </label>
                        <label class="label">
                            <span class="legend">Active Campaing Form ID</span>
                            <input type="text" name="page_ac_form" value="<?= $page_ac_form; ?>" required/>
                        </label>
                    </div>
                </div>

                <div class="lp_codigo lp_type" <?= !$page_ac_type || $page_ac_type != 2 ? 'style="display: none;"' : '' ?>>
                    <label class="label">
                        <span class="legend">Código Formulário</span>
                        <textarea name="page_ac_code" rows="10" placeholder="INSIRA O CÓDIGO GERADO PELA FERRAMENTA DE E-MAIL MARKETING"><?= $page_ac_code ?></textarea>
                    </label>

                    <!--<p><b>OBS:</b> PARA ADICIONAR O SYTLE DO FORMULÁRIO DE CAPTURA DO ACTIVE PAGES, ADICIONAR NA TAG FORM A CLASS active_form</p>-->
                </div>

                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">SALVAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>

                <div class="clear"></div>
            </form>
            <div class="lp_activecampaing lp_type" <?= $page_ac_type && $page_ac_type == 2 ? 'style="display: none;"' : '' ?>>
                <div class="box_content wc_normalize_height panel_header" style="margin-top: 5px;">
                    <h2>Campos Captura</h2>
                </div>
                <div class="panel">
                    <p>Novo Campo</p>

                    <form class="panel" name="page_social" action="" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="callback" value="LandingPages"/>
                        <input type="hidden" name="callback_action" value="add_input"/>
                        <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                        <div class="label_50">
                            <label class="label">
                                <span class="legend">CAMPO NAME</span>
                                <input type="text" name="input_name" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">CAMPO PLACEHOLDER</span>
                                <input type="text" name="input_placeholder" value="" required/>
                            </label>
                        </div>

                        <div class="label_50">
                            <label class="label">
                                <span class="legend">TIPO CAMPO</span>
                                <select name="input_type">
                                    <option value="text">text</option>
                                    <option value="email">email</option>
                                </select>
                            </label>
                            <label class="label">
                                <span class="legend">CLASSE CSS</span>
                                <input type="text" name="input_class" value="" required/>
                            </label>
                        </div>

                        <div class="wc_actions">
                            <label class="label_check label_publish <?= ($input_required == 1 ? 'active' : ''); ?>"><input style="margin-top: -1px;" type="checkbox" value="1" name="input_required"> Campo Obrigatório?</label>
                            <button name="public" value="1" class="btn btn_green icon-share">SALVAR</button>
                            <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                        </div>


                        <div class="clear"></div>
                    </form>
                </div>

                <div class="box_content wc_normalize_height panel_header" style="margin-top: 5px;">
                    <h2>Lista Campos</h2>
                </div>

                <?php
                $Read->ExeRead(DB_LP_INPUTS, "WHERE input_page = :id", "id={$page_id}");
                if ($Read->getResult()):
                    foreach ($Read->getResult() as $Input):
                        echo "<div class='panel_header' id='{$Input['input_id']}'>";
                        echo "<span rel='panel_header' class='j_delete_action icon-cancel-circle btn btn_red' id='{$Input['input_id']}'>Excluir</span>";
                        echo "<span rel='panel_header' callback='LandingPages' callback_action='delete_input' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='{$Input['input_id']}'>EXCLUIR AGORA!</span>";
//                    echo "<span style='margin-right: 5px;' class='j_edit_input icon-pencil2 btn btn_blue'>Editar</span>";
                        echo "<span style='margin-left: 5px;'>";
                        echo '<form class="auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">';
                        echo '<input type="hidden" name="callback" value="LandingPages"/>';
                        echo '<input type="hidden" name="callback_action" value="edit_input"/>';
                        echo "<input type='hidden' name='input_id' value='{$Input['input_id']}' />";
                        echo "<input type='hidden' name='page_id' value='{$page_id}' />";
                        echo "<label class='label_check label_publish " . ($Input['input_required'] == 1 ? 'active' : '') . "'>";
                        echo "<input style='margin-top: -1px;' type='checkbox' value='1' name='input_required'";
                        if ($Input['input_required'] == 1):
                            echo " checked";
                        endif;
                        echo " >Obrigatório</label>";
                        echo "</form>";
                        echo "</span>";
                        echo "<p>{$Input['input_name']} | {$Input['input_placeholder']} | {$Input['input_class']} | {$Input['input_type']} </p>";
                        echo "</div>";
                    endforeach;
                else:
                    echo "<div class='panel'>";
                    echo "<p>Não possui campos cadastrados</p>";
                    echo "</div>";
                endif;
                ?>
            </div>
        </div>


        <div class="wc_tab_target none" id="venda">
            <div class="box_content wc_normalize_height panel_header" style="margin-top: 5px;">
                <h2>Botão Venda</h2>
            </div>

            <form class="panel auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                <div class="label_50">
                    <label class="label">
                        <span class="legend">BOTÃO VENDA</span>
                        <input type="text" name="page_venda_button" value="<?= $page_venda_button; ?>" required/>
                    </label>

                  <!--  <label class="label page_ac_type">
                        <span>VENDA TIPO:</span>
                        <input type="radio" rel="lp_pdt" name="page_venda_type" value="1" <?= !$page_venda_type || $page_venda_type == 1 ? 'checked' : '' ?> /> Produto
                        <input type="radio" rel="lp_curso" name="page_venda_type" value="2" <?= $page_venda_type && $page_venda_type == 2 ? 'checked' : '' ?>/> Curso
                    </label>-->
                </div>

              <!--  <div class="lp_type lp_pdt" <?= $page_venda_type && $page_venda_type == 2 ? 'style="display: none;"' : '' ?>>
                    <label class="label">
                        <span>SELECIONE O PRODUTO:</span>
                        <select name="page_venda_pdt">
                            <option value="">SELECIONE UM PRODUTO</option>
                            <?php
                            $Read->ExeRead(DB_PDT);

                            foreach ($Read->getResult() as $Pdt):
                                ?>
                                <option <?= $page_venda_pdt == $Pdt['pdt_id'] ? 'selected' : ''; ?> value="<?= $Pdt['pdt_id'] ?>"><?= $Pdt['pdt_title'] ?></option>
                                <?php
                            endforeach;
                            ?>
                        </select>
                    </label>
                </div>-->

                <div class="lp_type lp_curso" <?= !$page_venda_type || $page_venda_type != 2 ? 'style="display: none;"' : '' ?>>
                    <label class="label">
                        <span>SELECIONE O CURSO:</span>
                        <select name="page_venda_curso">
                            <option value="">SELECIONE UM CURSO</option>
                            <?php
                            $Read->ExeRead(DB_EAD_COURSES);

                            foreach ($Read->getResult() as $Curso):
                                ?>
                                <option <?= $page_venda_curso == $Curso['course_id'] ? 'selected' : ''; ?> value="<?= $Curso['course_id'] ?>"><?= $Curso['course_title'] ?></option>
                                <?php
                            endforeach;
                            ?>
                        </select>
                    </label>
                </div>

                <label class="label">
                    <span class="legend">HOTLINK(OPCIONAL)</span>
                    <input type="text" name="page_venda_hotlink" value="<?= $page_venda_hotlink ?>">
                </label>

                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">SALVAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>
            </form>
        </div>


        <div class="wc_tab_target none" id="download">
            <div class="box_content wc_normalize_height panel_header" style="margin-top: 5px;">
                <h2>Botão Venda</h2>
            </div>

            <form class="panel auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>


                <label class="label">
                    <span class="legend">BOTÃO DOWNLOAD</span>
                    <input type="text" name="page_download_button" value="<?= $page_download_button; ?>" required/>
                </label>
                <label class="label">
                    <span class="legend">URL DOWNLOAD</span>
                    <input type="text" name="page_download_url" value="<?= $page_download_url; ?>" required/>
                </label>
                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">SALVAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>
            </form>
        </div>

        <div class="panel wc_tab_target none" id="confirma">

            <form class="auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                <label class="label">
                    <span class="legend">PÁGINA CONFIRMAÇÃO</span>
                    <select name="page_confirm">
                        <?php foreach (getWcConfirmaType() as $Key => $Value):
                            ?>
                            <option <?= $page_confirm == $Key ? 'selected' : ''; ?> value="<?= $Key ?>"><?= $Value ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="label">
                    <span class="legend">PÁGINA VÍDEO</span>
                    <input type="text" name="page_video_confirma" value="<?= $page_video_confirma; ?>" />
                </label>
                <label class="label">
                    <span class="legend">PÁGINA TÍTULO</span>
                    <input type="text" name="page_confirme_title" value="<?= $page_confirme_title; ?>" />
                </label>
                <label class="label">
                    <span class="legend">PÁGINA HEDLINE</span>
                    <input type="text" name="page_confirme_headline" value="<?= $page_confirme_headline; ?>" />
                </label>
                <label class="label">
                    <span class="legend">PÁGINA SUBJECT</span>
                    <input type="text" name="page_confirme_subject" value="<?= $page_confirme_subject; ?>" />
                </label>

                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>

                <div class="clear"></div>
            </form>
        </div>
        <div class="panel wc_tab_target none" id="obrigado">

            <form class="auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                <label class="label">
                    <span class="legend">PÁGINA OBRIGADO </span>
                    <select name="page_tankyou">
                        <?php foreach (getWcObrigadoType() as $Key => $Value):
                            ?>
                            <option <?= $page_tankyou == $Key ? 'selected' : ''; ?> value="<?= $Key ?>"><?= $Value ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="label">
                    <span class="legend">PÁGINA VÍDEO</span>
                    <input type="text" name="page_video_obrigado" value="<?= $page_video_obrigado; ?>" required/>
                </label>
                <label class="label">
                    <span class="legend">PÁGINA TÍTULO</span>
                    <input type="text" name="page_tanks_title" value="<?= $page_tanks_title; ?>" required/>
                </label>
                <label class="label">
                    <span class="legend">PÁGINA HEDLINE</span>
                    <input type="text" name="page_tanks_content" value="<?= $page_tanks_content; ?>" required/>
                </label>
                <label class="label">
                    <span class="legend">PÁGINA BOTÃO</span>
                    <input type="text" name="page_tanks_cta" value="<?= $page_tanks_cta; ?>" required/>
                </label>
                <label class="label">
                    <span class="legend">PÁGINA DOWNLOAD</span>
                    <input type="text" name="page_tanks_link" value="<?= $page_tanks_link; ?>" required/>
                </label>

                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>

                <div class="clear"></div>
            </form>
        </div>

        <div class="panel wc_tab_target none" id="social">

            <form class="auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                <div class="label_50">
                    <label class="label">
                        <span class="legend">SOCIAL TITLE:</span>
                        <input type="text" name="page_site_name" value="<?= $page_site_name ? $page_site_name : SITE_SOCIAL_NAME ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">GOOGLE AUTOR:</span>
                        <input type="text" name="page_g_author" value="<?= $page_g_author ? $page_g_author : SITE_SOCIAL_GOOGLE_AUTHOR; ?>" />
                    </label>
                </div>
                <div class="label_50">
                    <label class="label">
                        <span class="legend">GOOLGE PÁGINA:</span>
                        <input type="text" name="page_g_page" value="<?= $page_g_page ? $page_g_page : SITE_SOCIAL_GOOGLE_PAGE ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">GOOGLE ADS ID:</span>
                        <input type="text" name="page_g_ads_id" value="<?= $page_g_ads_id ? $page_g_ads_id : SITE_SOCIAL_GOOGLE; ?>" />
                    </label>
                </div>
                <div class="label_50">
                    <label class="label">
                        <span class="legend">GOOLGE ADS LABEL:</span>
                        <input type="text" name="page_g_ads_label" value="<?= $page_g_ads_label ? $page_g_ads_label : '' ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">GOOGLE ANALYTICS:</span>
                        <input type="text" name="page_g_analytics" value="<?= $page_g_analytics ? $page_g_analytics : ''; ?>" />
                    </label>
                </div>
                <div class="label_50">
                    <label class="label">
                        <span class="legend">FACEBOOK AUTOR:</span>
                        <input type="text" name="page_fb_author" value="<?= $page_fb_author ? $page_fb_author : SITE_SOCIAL_FB_AUTHOR ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">FACEBOOK PÁGINA:</span>
                        <input type="text" name="page_fb_page" value="<?= $page_fb_page ? $page_fb_page : SITE_SOCIAL_FB_PAGE; ?>" />
                    </label>
                </div>
                <div class="label_50">
                    <label class="label">
                        <span class="legend">FACEBOOK PIXEL:</span>
                        <input type="text" name="page_fb_pixel" value="<?= $page_fb_pixel ? $page_fb_pixel : '' ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">YOUTUBE CANAL:</span>
                        <input type="text" name="page_yt_channel" value="<?= $page_yt_channel ? $page_yt_channel : SITE_SOCIAL_YOUTUBE; ?>" />
                    </label>
                </div>
                <div class="label_50">
                    <label class="label">
                        <span class="legend">TWITTER:</span>
                        <input type="text" name="page_twitter" value="<?= $page_twitter ? $page_twitter : '' ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">INSTAGRAM:</span>
                        <input type="text" name="page_instagram" value="<?= $page_instagram ? $page_instagram : SITE_SOCIAL_INSTAGRAM; ?>" />
                    </label>
                </div>

                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>

                <div class="clear"></div>
            </form>


        </div>



        <div class="panel wc_tab_target none" id="legal">
            <form class="auto_save" name="page_social" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="LandingPages"/>
                <input type="hidden" name="callback_action" value="manager"/>
                <input type="hidden" name="page_id" value="<?= $PageId; ?>"/>

                <label class="label">
                    <span class="legend">POLÍTICA DE PRIVACIDADE:</span>
                    <input type="text" name="page_politicas" value="<?= $page_politicas ? $page_politicas : '' ?>" required/>
                </label>

                <label class="label">
                    <span class="legend">TERMOS DE USO:</span>
                    <input type="text" name="page_termos" value="<?= $page_termos ? $page_termos : '' ?>" required/>
                </label>

                <label class="label">
                    <span class="legend">AVISO LEGAL:</span>
                    <input type="text" name="page_aviso" value="<?= $page_aviso ? $page_aviso : '' ?>" required/>
                </label>
                <label class="label">
                    <span class="legend">COPYRIGHT:</span>
                    <input type="text" name="page_copyright" value="<?= $page_copyright ? $page_copyright : '' ?>" required/>
                </label>

                <div class="wc_actions">
                    <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>

                <div class="clear"></div>
            </form>
        </div>
    </div>

    <article class="box box30">
        <div class="course_create_cover">
            <div class="upload_progress none">0%</div>
            <?php
            $CourseCover = (!empty($page_cover) && file_exists("../_activepages/{$page_cover}") && !is_dir("../_activepages/{$page_cover}") ? "_activepages/{$page_cover}" : 'admin/_img/no_image.jpg');
            ?>
            <img class="course_thumb page_cover" alt="Capa" title="Capa" src="../tim.php?src=<?= $CourseCover; ?>&w=<?= IMAGE_W / 2; ?>&h=<?= IMAGE_H / 2; ?>" default="../tim.php?src=<?= $CourseCover; ?>&w=<?= IMAGE_W / 2; ?>&h=<?= IMAGE_H / 2; ?>"/>
        </div>

        <div class="box_conf_menu no_icon">
            <a class='conf_menu wc_tab wc_active' href='#course'><span class="icon-lab">Landing Page</span></a>
            <a class='conf_menu wc_tab' href='#home'><span class="icon-home">Home</span></a>
           <!--       <a class='conf_menu wc_tab' href='#confirma'><span class="icon-checkmark">Confirmação</span></a>
            <a class='conf_menu wc_tab' href='#obrigado'><span class="icon-smile">Obrigado</span></a>
            <a class='conf_menu wc_tab' href='#captura'><span class="icon-filter">Captura</span></a>-->
            <a class='conf_menu wc_tab' href='#venda'><span class="icon-cart">Venda</span></a>
            <!--      <a class='conf_menu wc_tab' href='#download'><span class="icon-download">Download</span></a>-->
         <!--   <a class='conf_menu wc_tab' href='#social'><span class="icon-rocket">Redes Sociais</span></a>
<!--            <a class='conf_menu wc_tab' href='#depoimento_video'><span class="icon-play">Depoimento Vídeo</span></a>
            <a class='conf_menu wc_tab' href='#depoimento_texto'><span class="icon-hangouts">Depoimento Texto</span></a>
            <a class='conf_menu wc_tab' href='#sobre'><span class="icon-info">Sessão Sobre</span></a>
            <a class='conf_menu wc_tab' href='#autor'><span class="icon-users">Sessão Autor/Palestrantes</span></a>-->
            <a class='conf_menu wc_tab' href='#legal'><span class="icon-lock">Legal</span></a>

        </div>
    </article>
</div>

<script>
    $('input[name=page_ac_type]').change(function () {
        $('.lp_type').fadeOut(0);
        $('.' + $(this).attr('rel')).fadeIn(0);
    });
    $('input[name=page_venda_type]').change(function () {
        $('.lp_type').fadeOut(0);
        $('.' + $(this).attr('rel')).fadeIn(0);
    });


</script>
