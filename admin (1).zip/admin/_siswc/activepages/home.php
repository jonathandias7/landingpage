<?php
$AdminLevel = LEVEL_WC_ACTIVEPAGES;
if (!APP_ACTIVEPAGES || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

$Title = filter_input(INPUT_POST, 'title', FILTER_DEFAULT);
if ($Title):
    $Read->FullRead("SELECT * FROM " . DB_LP_PAGES . " WHERE page_title LIKE '%' :id '%'", "id={$Title}");
else:
    $Read->ExeRead(DB_LP_PAGES, "ORDER BY page_title");
endif;

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">Active Pages</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            Active Pages
        </p>
    </div>

    <div class="dashboard_header_search">
        <form style="width: 60%; display: inline-block" name="searchOrders" action="" method="post" enctype="multipart/form-data" class="ajax_off">
            <input name="title" value="<?= isset($Title) ? $Title : '' ?>" placeholder="buscar..." />

            <button class="btn btn_blue icon icon-search icon-notext"></button>
        </form>
    </div>
</header>

<div class="dashboard_content">
    <?php
    if (!$Read->getResult()):
        Erro("<span class='al_center icon-notification'>Ainda não existem lading pages. Começe cadastrando sua primeira landing page!</span>", E_USER_NOTICE);
    else:
        foreach ($Read->getResult() as $Page):
            extract($Page);

            $Cover = (file_exists("../_activepages/{$page_cover}") && !is_dir("../_activepages/{$page_cover}") ? "_activepages/{$page_cover}" : 'admin/_img/no_image.jpg');
            $Status = ($page_status != 1 ? 'inactive' : '');

            $CourseDragAndDrop = (empty($segment_title) ? 'wc_draganddrop' : null);

            echo "<article class='box box25 wc_ead_course {$Status} {$CourseDragAndDrop}' callback='Courses' callback_action='courses_order' id='{$page_id}'>";
            echo "<div class='wc_ead_coursecover'>";
            echo "<img src='../tim.php?src={$Cover}&w=" . IMAGE_W / 3 . "&h=" . IMAGE_H / 3 . "' title='{$page_title}' alt='{$page_title}'/>";
            echo "</div>";
            echo "<div class='box_content wc_normalize_height'>";
            echo "<h1><a target='_blank' href='" . BASE . "/{$page_name}' title='" . ($page_title ? $page_title : "Edite essa landing page!") . "'>" . ($page_title ? $page_title : "Edite essa landing page!") . "</a></h1>";
            echo "<p class='wc_ead_coursestats'><span>" . date("d/m/Y", strtotime($page_date_start)) . " INICIO</span><span>" . date("d/m/Y", strtotime($page_date_and)) . " FIM</span></p>";
            echo "</div>";
            echo "<div class='wc_ead_courseactions' style='font-size: 0.875em;'>";
            echo "<a class='btn " . ($Status ? "btn_yellow" : "btn_blue") . " m_top icon-pencil2' style='margin-right: 10px;' href='dashboard.php?wc=activepages/create&id={$page_id}' title='Editar Curso'>Editar</a>";
            echo "<a target='_blanck' class='btn btn_green m_top icon-eye' href='" . BASE . "/{$page_name}' title='Ver Active Page'>Ver</a>";
            echo "</div>";
            echo "</article>";
        endforeach;
    endif;
    ?>
</div> 
