<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$Active = filter_input(INPUT_GET, 'active', FILTER_DEFAULT);
$Sessao = filter_input(INPUT_GET, 'id', FILTER_DEFAULT);
$Tipo = filter_input(INPUT_GET, 'tipo', FILTER_DEFAULT);
if ($Active):
    $Read->ExeRead(DB_LP_PAGES, "WHERE page_id = :id", "id={$Active}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = "<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma landing page que não existe ou que foi removido recentemente!";
        header('Location: dashboard.php?wc=activepages/home');
    endif;
else:
    $_SESSION['trigger_controll'] = "<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma landing page que não existe ou que foi removido recentemente!";
    header('Location: dashboard.php?wc=activepages/home');
endif;

if ($Active && $Sessao):
    $Read->ExeRead(DB_LP_SECTIONS, "WHERE section_id = :id", "id={$Sessao}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        header('Location: dashboard.php?wc=activepages/home');
    endif;

elseif ($Active && $Tipo):
    $Create = new Create();
    $PostCreate = ['section_status' => 0,
        'section_type' => $Tipo,
        'section_page' => $Active,
        'section_title' => 'Nova Sessão'];
    $Create->ExeCreate(DB_LP_SECTIONS, $PostCreate);
    header('Location: dashboard.php?wc=activepages/sessao&active=' . $Active . '&id=' . $Create->getResult());
endif;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">Active Pages</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=activepages/home">Active Pages</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=activepages/sessoes&id=<?= $page_id ?>">Seções</a>
            <span>/</span>
            <?= $page_title ?>
        </p>
    </div>

    <div class="dashboard_header_search" id="<?= $PageId; ?>">
        <a title="Gerenciar Landing Page!" href="dashboard.php?wc=activepages/sessoes&id=<?= $page_id ?>" class="wc_view btn btn_green icon-page-break">Seções!</a>
    </div>
</header>

<div class="dashboard_content">
    <?php if (!$Sessao): ?>
        <section class="box_content sessao">
            Selecione o tipo:<br>
            <?php foreach (getWcSessaoType() as $Key => $Type): ?>
                <article class="box box25">
                    <a href="dashboard.php?wc=activepages/sessao&active=<?= $page_id ?>&tipo=<?= $Key ?>">
                        <img src="_siswc/activepages/img/<?= $Type['img'] ?>" title="<?= $Type['title'] ?>" alt="<?= $Type['title'] ?>">
                        <h1><?= $Type['title'] ?></h1>
                    </a>
                </article>
            <?php endforeach; ?>
        </section>
        <?php
    elseif ($section_type):
        ?>
        <div class="box box70">
            <div class="panel">
                <form class="auto_save" name="page_create" action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="callback" value="LandingPages"/>
                    <input type="hidden" name="callback_action" value="sessao_maneger"/>
                    <input type="hidden" name="section_id" value="<?= $section_id ?>" />
                    <input type="hidden" name="section_type" value="<?= $section_type ?>" />
                    <h1>Sessão <?= getWcSessaoType($section_type)['title'] ?></h1><br>

                    <label class="label">
                        <span class="legend">Título Sessão</span>
                        <input type="text" name="section_title" placeholder="Título da Sessão" value="<?= $section_title ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">Hedline Sessão</span>
                        <input type="text" name="section_hedline" placeholder="Hedline da Sessão" value="<?= $section_hedline ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">Botão</span>
                        <select name="section_button">
                            <option value="0">Nenhum</option>
                            <?php foreach (getWcButtonType() as $Key => $Value):
                                ?>
                                <option <?= $section_button == $Key ? 'selected' : ''; ?> value="<?= $Key ?>"><?= $Value ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label class="label">
                        <span class="legend">Páginas</span>
                        <input style="display: inline-block;width: auto;" type="checkbox" name="section_home" value="1" <?= $section_home ? 'checked' : '' ?> /> Home
                        <input style="display: inline-block;width: auto;" type="checkbox" name="section_confirma" value="1" <?= $section_confirma ? 'checked' : '' ?> /> Confirma
                        <input style="display: inline-block;width: auto;" type="checkbox" name="section_obrigado" value="1" <?= $section_obrigado ? 'checked' : '' ?> /> Obrigado
                    </label>
                </form>
            </div>
            <?php
            switch ($section_type):
                case 1:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <form class="auto_save" name="page_create" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="sessao_maneger"/>
                            <input type="hidden" name="section_id" value="<?= $section_id ?>" />
                            <input type="hidden" name="section_type" value="<?= $section_type ?>" />
                            <label class="label">
                                <span class="legend">Instagram ID</span>
                                <input type="text" name="insta_id" placeholder="ID Instagram" value="<?= $insta_id ?>" />
                            </label>
                            <label class="label">
                                <span class="legend">Instagram Token</span>
                                <input type="text" name="insta_token" placeholder="Token Instagram" value="<?= $insta_token ?>" />
                            </label>

                            <p>INSTRUÇÕES: </p>    
                            <p>* <b>APP:</b> Para obter o token acesse (<a href="https://www.instagram.com/developer/">https://www.instagram.com/developer/</a>) para criar sua APP. </p>
                            <p>Em secure desmarque a opção
                                * Disable implicit OAuth e salve sua APP. <b>Anote o CLIENTE_ID e o REDIRECT URL</b>
                            </p>
                            <p>* <b>AUTH:</b> Para autenticar acesse https://www.instagram.com/oauth/authorize/?client_id=<b>CLINETE_ID</b>&redirect_uri=<b>REDIRECT_URL</b>&response_type=token&scope=<b>public_content|basic</b>
                            </p><p>* Você será solicitado para permissão, depois disso basta copiar o parâmetro TOKEM. Até o primeiro ponto(.) você tem o userId. A chave completa é o AcessToken
                            </p>
                        </form>
                    </div>
                    <?php
                    break;
                case 2:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Nova Categoria</h1><br>
                        <form id="depoimento_video" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_galeria"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="cat_section" value="<?= $Sessao; ?>"/>

                            <label class="label">
                                <span class="legend">Título Categoria</span>
                                <input type="text" name="cat_title" value="" required/>
                            </label>
                            <label class="label">
                                <span class="legend">Fotos (JPG <?= THUMB_W; ?>x<?= THUMB_H; ?>px):</span>
                                <input type="file" name="image[]" multiple required/>
                            </label>

                            <div class="wc_actions">
                                <label class="label_check label_publish"><input style="margin-top: -1px;" type="checkbox" value="1" name="cat_status"> Publicar Agora!</label>
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Galeria de Fotos</h1><br>
                    </div>
                    <?php
                    $Read->ExeRead(DB_LP_GALLERY_CAT, "WHERE cat_section = :cat", "cat={$Sessao}");
                    if (!$Read->getResult()):
                        echo Erro("<span class='al_center icon-notification'>Ainda não existem categorias de imagens</span>", E_USER_NOTICE);
                    else:
                        foreach ($Read->getResult() as $Cat):
                            $Read->ExeRead(DB_LP_GALLERY, "WHERE gallery_cat = :cat", "cat={$Cat['cat_id']}");
                            if (!$Read->getResult()):
                                echo Erro("<span class='al_center icon-notification'>Ainda não existem fotos cadastradas nessa categoria</span>", E_USER_NOTICE);
                            else:
                                ?>
                                <div class="panel section_gal" style="margin-top: 10px;" id='<?= $Cat['cat_id'] ?>'>
                                    <section class="gallery_cat" style="padding: 5px;">
                                        <div class="section_header" style="padding: 10px;background: #f1f1f1;">
                                            <h3 style="display: inline-block;"><?= $Cat['cat_title'] ?> </h3>
                                            <div class="wc_ead_course" style='font-size: 0.875em;display: inline-block;'>
                                                <span rel='section_gal' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $Cat['cat_id'] ?>'></span>
                                                <span rel='section_gal' callback='LandingPages' callback_action='delete_cat' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='<?= $Cat['cat_id'] ?>'>Remover Categoria?</span>
                                            </div>
                                        </div>
                                        <form name="page_social" action="" method="post" enctype="multipart/form-data">
                                            <input type="hidden" name="callback" value="LandingPages"/>
                                            <input type="hidden" name="callback_action" value="edit_galeria"/>
                                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                                            <input type="hidden" name="cat_section" value="<?= $Sessao; ?>"/>
                                            <input type="hidden" name="cat_id" value="<?= $Cat['cat_id'] ?>"/>
                                            <input type="hidden" name="cat_status" value="<?= $Cat['cat_status'] ?>"/>
                                            <div class="label_50">
                                                <label class="label">
                                                    <span class="legend">Adicionar Fotos (JPG <?= THUMB_W; ?>x<?= THUMB_H; ?>px):</span>
                                                    <input type="file" name="image[]" multiple required/>
                                                </label>
                                                <div class="label">
                                                    <span class="legend">-</span>
                                                    <button name="public" value="1" class="btn btn_green icon-share">Salvar</button>
                                                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                                                </div>
                                            </div>
                                        </form>
                                        <?php
                                        foreach ($Read->getResult() as $Gallery):
                                            ?>                        
                                            <article class="course_segment box wc_draganddrop" callback="Galeria" callback_action="galeria_order" id="<?= $Gallery['gallery_id']; ?>">
                                                <div class='box_content pdt_single_image'>
                                                    <img rel='LandingPages' id='<?= $Gallery['gallery_id']; ?>' src="<?= BASE ?>/tim.php?src=_activepages/<?= $Gallery['gallery_cover'] ?>&w=200&h=200" title="" alt="" />
                                                </div>
                                                <form class="auto_save" name="legenda_add" action="" method="post" enctype="multipart/form-data">
                                                    <input type="hidden" name="callback" value="LandingPages"/>
                                                    <input type="hidden" name="callback_action" value="galeria_legenda"/>
                                                    <input type="hidden" name="gallery_id" value="<?= $Gallery['gallery_id']; ?>"/>

                                                    <input type="text" name="gallery_title" value="<?= $Gallery['gallery_title'] ?>" />
                                                </form>
                                            </article>
                                            <?php
                                        endforeach;
                                        ?>
                                    </section>
                                </div>
                            <?php
                            endif;
                        endforeach;
                    endif;
                    ?>

                    <?php
                    break;
                case 3:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Novo Vídeo</h1>
                        <form id="depoimento_video" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_video"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="section_id" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="video_id" value=""/>

                            <label class="label">
                                <span class="legend">Cliente</span>
                                <input type="text" name="video_user" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">Descrição</span>
                                <input type="text" name="video_desc" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">VÍDEO ID</span>
                                <input type="text" name="video_yt_id" value="" required/>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Vídeo</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>

                        </form>
                    </div>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Vídeos</h1>

                        <?php
                        $Read->ExeRead(DB_LP_VIDEOS, "WHERE video_section = :pg", "pg={$Sessao}");
                        if ($Read->getResult()):
                            foreach ($Read->getResult() as $Video):
                                ?>
                                <div class="box box25 wc_ead_course" id="<?= $Video['video_id'] ?>">
                                    <div class='wc_ead_coursecover'>
                                        <?php
                                        if (is_numeric($Video['video_yt_id'])):
                                            $video = unserialize(file_get_contents("http://vimeo.com/api/v2/video/{$Video['video_yt_id']}.php"));
                                        endif;
                                        ?>

                                        <img src="<?= isset($video) ? $video[0]['thumbnail_medium'] : "https://i1.ytimg.com/vi/{$Video['video_yt_id']}/mqdefault.jpg" ?>" alt="<?= $Video['video_user']; ?>" title="<?= $Video['video_user']; ?>"/>
                                    </div>
                                    <div class='box_content wc_normalize_height'>
                                        <p><b><?= $Video['video_user'] ?></b> <?= $Video['video_desc'] ?></p>
                                    </div>
                                    <div class='wc_ead_courseactions' style='font-size: 0.875em;'>
                                        <a class='btn btn_blue m_top icon-pencil2 icon-notext j_edit_video' rel="<?= $Video['video_id'] ?>" yt="<?= $Video['video_yt_id']; ?>" user="<?= $Video['video_user'] ?>" desc="<?= $Video['video_desc'] ?>" style='margin-right: 10px;' href='#' title='Editar Vídeo'></a>
                                        <span rel='wc_ead_course' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $Video['video_id'] ?>'></span>
                                        <span rel='wc_ead_course' callback='LandingPages' callback_action='delete_video' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='<?= $Video['video_id'] ?>'>Remover Vídeo?</span>
                                    </div>
                                </div>
                                <?php
                            endforeach;
                        else:
                            echo Erro("<span class='al_center icon-notification'>Ainda não existe depoimentos em vídeo cadastrados</span>", E_USER_NOTICE);
                        endif;
                        ?>
                    </div>
                    <?php
                    break;
                case 4:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Novo depoimento</h1>
                        <form id="depoimento_texto" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_depoimento"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="section_id" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="depoimento_id" value=""/>

                            <label class="label">
                                <span class="legend">Cliente</span>
                                <input type="text" name="depoimento_user" value="" required/>
                            </label>
                            <label class="label">
                                <span class="legend">Profissão</span>
                                <input type="text" name="depoimento_profissao" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">DEPOIMENTO:</span>
                                <textarea id="depoimento_text" class="work_mce" name="depoimento_text" rows="3"></textarea>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Depoimento</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Depoimentos</h1>
                        <?php
                        $Read->ExeRead(DB_LP_DEPOIMENTOS, "WHERE depoimento_section = :id", "id={$Sessao}");
                        if ($Read->getResult()):
                            foreach ($Read->getResult() as $Depoimentos):
                                ?>
                                <div class="box box50 wc_ead_course wc_dep" id="<?= $Depoimentos['depoimento_id'] ?>">
                                    <div class='box_content wc_normalize_height panel'>
                                        <h2 class="icon-user"><?= $Depoimentos['depoimento_user'] ?></h2>
                                        <p><?= $Depoimentos['depoimento_text'] ?></p>
                                    </div>
                                    <div class='wc_ead_courseactions' style='font-size: 0.875em;'>
                                        <a class='btn btn_blue m_top icon-pencil2 j_edit_depoimento' rel="<?= $Depoimentos['depoimento_id'] ?>" prof="<?= $Depoimentos['depoimento_profissao']; ?>" user="<?= $Depoimentos['depoimento_user'] ?>" texto='<?= $Depoimentos['depoimento_text'] ?>' style='margin-right: 10px;' href='#' title='Editar Depoimento'>Editar</a>
                                        <span rel='wc_dep' class='j_delete_action icon-cancel-circle btn btn_red' id='<?= $Depoimentos['depoimento_id'] ?>'>Excluir</span>
                                        <span rel='wc_dep' callback='LandingPages' callback_action='delete_depoimento' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='<?= $Depoimentos['depoimento_id'] ?>'>Remover Depoimento?</span>
                                    </div>
                                </div>
                                <?php
                            endforeach;
                        else:
                            echo "Ainda não existe depoimentos cadastrados";
                        endif;
                        ?>
                    </div>
                    <?php
                    break;
                case 5:
                    ?>
                    <div class="panel">
                        <h3>Adicionar Vídeo</h3>
                        <form id="depoimento_video" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_video"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="section_id" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="video_id" value=""/>

                            <label class="label">
                                <span class="legend">Título Vídeo</span>
                                <input type="text" name="video_user" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">VÍDEO ID</span>
                                <input type="text" name="video_yt_id" value="" required/>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Vídeo</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>

                        </form>
                    </div>

                    <div class="panel" style="margin-top: 10px;">
                        <h1>Vídeos</h1>

                        <?php
                        $Read->ExeRead(DB_LP_VIDEOS, "WHERE video_section = :pg", "pg={$Sessao}");
                        if ($Read->getResult()):
                            foreach ($Read->getResult() as $Video):
                                ?>
                                <div class="box box25 wc_ead_course" id="<?= $Video['video_id'] ?>">
                                    <div class='wc_ead_coursecover'>

                                        <?php
                                        if (is_numeric($Video['video_yt_id'])):
                                            $video = unserialize(file_get_contents("http://vimeo.com/api/v2/video/{$Video['video_yt_id']}.php"));
                                        endif;
                                        ?>

                                        <img src="<?= isset($video) ? $video[0]['thumbnail_medium'] : "https://i1.ytimg.com/vi/{$Video['video_yt_id']}/mqdefault.jpg" ?>" alt="<?= $Video['video_user']; ?>" title="<?= $Video['video_user']; ?>"/>
                                    </div>
                                    <div class='box_content wc_normalize_height'>
                                        <p><b><?= $Video['video_user'] ?></b>
                                    </div>
                                    <div class='wc_ead_courseactions' style='font-size: 0.875em;'>
                                        <a class='btn btn_blue m_top icon-pencil2 icon-notext j_edit_video' rel="<?= $Video['video_id'] ?>" yt="<?= $Video['video_yt_id']; ?>" user="<?= $Video['video_user'] ?>" desc="<?= $Video['video_desc'] ?>" style='margin-right: 10px;' href='#' title='Editar Vídeo'></a>
                                        <span rel='wc_ead_course' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $Video['video_id'] ?>'></span>
                                        <span rel='wc_ead_course' callback='LandingPages' callback_action='delete_video' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='<?= $Video['video_id'] ?>'>Remover Vídeo?</span>
                                    </div>
                                </div>
                                <?php
                            endforeach;
                        else:
                            echo Erro("<span class='al_center icon-notification'>Ainda não existe vídeo cadastrados</span>", E_USER_NOTICE);
                        endif;
                        ?>
                    </div>
                    <?php
                    break;
                case 6:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Novo Post</h1>
                        <form id="depoimento_texto" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_post"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="post_section" value="<?= $Sessao; ?>"/>
                            <label class="label">
                                <span class="legend">SELECIONE O POST</span>
                                <select name="post_id">
                                    <option value="">Selecione o post</option>
                                    <?php
                                    $Read->ExeRead(DB_POSTS, "WHERE post_status = 1");
                                    if ($Read->getResult()):
                                        foreach ($Read->getResult() as $Post):
                                            $Read->exeRead(DB_LP_POSTS, "WHERE post_id = :id AND post_section = :section", "id={$Post['post_id']}&section={$Sessao}");
                                            if (!$Read->getResult()):
                                                ?>
                                                <option value="<?= $Post['post_id'] ?>"><?= $Post['post_title'] ?></option>
                                                <?php
                                            endif;
                                        endforeach;
                                    else:
                                        ?>
                                        <option value="" disabled>Cadaste um post</option>
                                    <?php
                                    endif;
                                    ?>
                                </select>
                            </label>
                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Adicionar Post</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>

                    <div class="panel" style="margin-top: 10px;">
                        <h1>Posts</h1>
                        <?php
                        $Read->ExeRead(DB_LP_POSTS, "WHERE post_section = :id", "id={$Sessao}");
                        if (!$Read->getResult()):
                            echo Erro("<span class='al_center icon-notification'>Ainda não existe posts cadastrados</span>", E_USER_NOTICE);
                        else:
                            foreach ($Read->getResult() as $LpPost):
                                $Read->ExeRead(DB_POSTS, "WHERE post_id = :id", "id={$LpPost['post_id']}");
                                foreach ($Read->getResult() as $POST):
                                    extract($POST);

                                    $PostCover = (file_exists("../uploads/{$post_cover}") && !is_dir("../uploads/{$post_cover}") ? "uploads/{$post_cover}" : 'admin/_img/no_image.jpg');
                                    $PostStatus = ($post_status == 1 && strtotime($post_date) >= strtotime(date('Y-m-d H:i:s')) ? '<span class="btn btn_blue icon-clock icon-notext wc_tooltip"><span class="wc_tooltip_baloon">Agendado</span></span>' : ($post_status == 1 ? '<span class="btn btn_green icon-checkmark icon-notext wc_tooltip"><span class="wc_tooltip_baloon">Publicado</span></span>' : '<span class="btn btn_yellow icon-warning icon-notext wc_tooltip"><span class="wc_tooltip_baloon">Pendente</span></span>'));
                                    $post_title = (!empty($post_title) ? $post_title : 'Edite esse rascunho para poder exibir como artigo em seu site!');

                                    $postTags = null;
                                    if ($post_tags):
                                        foreach (explode(",", $post_tags) AS $tags):
                                            $tag = ltrim(rtrim($tags));
                                            $postTags .= "<a class='icon-price-tag radius' title='Artigos marcados com {$tag}' href='dashboard.php?wc=posts/home&s={$S}&cat={$C}&tag=" . urlencode($tag) . "'>{$tag}</a>";
                                        endforeach;
                                    endif;

                                    $Category = null;
                                    if (!empty($post_category)):
                                        $Read->FullRead("SELECT category_id, category_title FROM " . DB_CATEGORIES . " WHERE category_id = :ct", "ct={$post_category}");
                                        if ($Read->getResult()):
                                            $Category = "<span class='icon-bookmark'><a title='Artigos em {$Read->getResult()[0]['category_title']}' href='dashboard.php?wc=posts/home&cat={$Read->getResult()[0]['category_id']}'>{$Read->getResult()[0]['category_title']}</a></span> ";
                                        endif;
                                    endif;

                                    if (!empty($post_category_parent)):
                                        $Read->FullRead("SELECT category_title, category_id FROM " . DB_CATEGORIES . " WHERE category_id IN({$post_category_parent})");
                                        if ($Read->getResult()):
                                            foreach ($Read->getResult() as $SubCat):
                                                $Category .= "<span class='icon-bookmarks'><a title='Artigos em {$SubCat['category_title']}' href='dashboard.php?wc=posts/home&s={$S}&cat={$SubCat['category_id']}&tag=" . urlencode($T) . "'>{$SubCat['category_title']}</a></span> ";
                                            endforeach;
                                        endif;
                                    endif;

                                    echo "<article class='box box25 post_single' id='{$LpPost['id']}'>           
                <div class='post_single_cover'>
                    <a title='Ver artigo no site' target='_blank' href='" . BASE . "/artigo/{$post_name}'><img alt='{$post_title}' title='{$post_title}' src='../tim.php?src={$PostCover}&w=" . IMAGE_W / 2 . "&h=" . IMAGE_H / 2 . "'/></a>
                    <div class='post_single_status'>
                        <span class='btn wc_tooltip'>" . str_pad($post_views, 4, 0, STR_PAD_LEFT) . " <span class='wc_tooltip_baloon'>Visualizações</span></span>
                        {$PostStatus}
                        " . (APP_POSTS_INSTANT_ARTICLE && $post_instant_article == '1' ? "<span class='btn btn_blue icon-facebook2 icon-notext wc_tooltip'><span class='wc_tooltip_baloon'>Instant Article</span></span>" : '') . " 
                    </div>
                    " . (!empty($postTags) ? "<div class='post_single_tag'>{$postTags}</div>" : "") . "
                </div>
                <div class='post_single_content wc_normalize_height'>
                    <h1 class='title'><a title='Ver artigo no site' target='_blank' href='" . BASE . "/artigo/{$post_name}'>{$post_title}</a></h1>
                    <p class='post_single_cat'>{$Category}</p>
                </div>
                <div class='post_single_actions'>
                    <a title='Editar Artigo' href='dashboard.php?wc=posts/create&id={$post_id}' class='post_single_center icon-pencil btn btn_blue'>Editar</a>
                    <span rel='post_single' class='j_delete_action icon-cancel-circle btn btn_red' id='{$LpPost['id']}'>Deletar</span>
                    <span rel='post_single' callback='LandingPages' callback_action='delete_post' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='{$LpPost['id']}'>Retirar Post?</span>
                </div>
            </article>";
                                endforeach;
                            endforeach;
                        endif;
                        ?>
                    </div>
                    <?php
                    break;
                case 7:

                    if ($section_pdt && $section_promo_type == 1):
                        $Read->ExeRead(DB_PDT, "WHERE pdt_id = :id", "id={$section_pdt}");
                        extract($Read->getResult()[0]);
                    endif;
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Promoção</h1>
                        <form id="depoimento_texto" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_oferta"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="section_id" value="<?= $Sessao; ?>"/>
                            <label class="label page_ac_type">
                                <span>VENDA TIPO:</span>
                                <input type="radio" rel="lp_pdt" name="section_promo_type" value="1" <?= !$section_promo_type || $section_promo_type == 1 ? 'checked' : '' ?> /> Produto
                                <input type="radio" rel="lp_curso" name="section_promo_type" value="2" <?= $section_promo_type && $section_promo_type == 2 ? 'checked' : '' ?>/> Curso
                                <input type="radio" rel="lp_outro" name="section_promo_type" value="3" <?= $section_promo_type && $section_promo_type == 3 ? 'checked' : '' ?>/> Outros
                            </label>
                            <div class="lp_type lp_pdt" <?= $section_promo_type && $section_promo_type != 1 ? 'style="display: none;"' : '' ?>>
                                <label class="label">
                                    <span class="legend">Produto</span>
                                    <select class="j_pdt" name="section_pdt">
                                        <option value="">Selecione o Produto</option>
                                        <?php
                                        $Read->ExeRead(DB_PDT, "WHERE pdt_status = 1");
                                        if ($Read->getResult()):
                                            foreach ($Read->getResult() as $Post):
                                                ?>
                                                <option <?= isset($section_pdt) && $section_pdt == $Post['pdt_id'] ? 'selected ' : '' ?>value="<?= $Post['pdt_id'] ?>"><?= $Post['pdt_title'] ?></option>
                                                <?php
                                            endforeach;
                                        else:
                                            ?>
                                            <option value="" disabled>Cadaste um produto</option>
                                        <?php
                                        endif;
                                        ?>
                                    </select>
                                </label>


                                <p class="section">Oferta:</p>

                                <label class="label">
                                    <span class="legend">Promoção: (860,00)</span>
                                    <input type="text" name="pdt_offer_price" value="<?= isset($pdt_offer_price) ? number_format($pdt_offer_price, '2', ',', '.') : "0,00"; ?>" placeholder="Preço Promocional:"/>
                                </label>

                                <label class="label">
                                    <span class="legend">Início da Promoção:</span>
                                    <input type="text" class="formTime" name="pdt_offer_start" value="<?= (isset($pdt_offer_start) ? date('d/m/Y H:i', strtotime($pdt_offer_start)) : null); ?>"/>
                                </label>

                                <label class="label">
                                    <span class="legend">Fim da Promoção:</span>
                                    <input type="text" class="formTime" name="pdt_offer_end" value="<?= (isset($pdt_offer_end) ? date('d/m/Y H:i', strtotime($pdt_offer_end)) : null); ?>"/>
                                </label>

                            </div>

                            <div class="lp_type lp_curso" <?= !$section_promo_type || ($section_promo_type != 2) ? 'style="display: none;"' : '' ?>>

                                <label class="label">
                                    <span>Curos:</span>
                                    <select name="section_curso">
                                        <option value="">Selecione um curso</option>
                                        <?php
                                        $Read->ExeRead(DB_EAD_COURSES, "WHERE course_status = 1");
                                        if ($Read->getResult()):
                                            foreach ($Read->getResult() as $Curso):
                                                ?>
                                                <option <?= $section_curso == $Curso['course_id'] ? 'selected' : ''; ?> value="<?= $Curso['course_id'] ?>"><?= $Curso['course_title'] ?></option>
                                                <?php
                                            endforeach;
                                        else:
                                            ?>
                                            <option value="0" disabled="disabled">Cadastre um curso antes</option>
                                        <?php
                                        endif;
                                        ?>
                                    </select>
                                </label>

                            </div>
                            <div class="lp_type lp_curso lp_outro" <?= !$section_promo_type || ($section_promo_type != 2 && $section_promo_type != 3) ? 'style="display: none;"' : '' ?>>
                                <p class="section">Oferta:</p>
                                <div class="lp_type lp_outro" <?= $section_promo_type != 3 ? 'style="display: none;"' : '' ?>>
                                <label class="label">
                                    <span class="legend">Valor: (860,00)</span>
                                    <input type="text" name="section_price" value="<?= isset($section_price) ? number_format($section_price, '2', ',', '.') : "0,00"; ?>" placeholder="Preço:"/>
                                </label>
                                </div>
                                <label class="label">
                                    <span class="legend">Parcelas</span>
                                    <input type="number" name="section_promo_parcelas" value="<?= isset($section_promo_parcelas) ? $section_promo_parcelas : 1; ?>" />
                                </label>
                                <label class="label">
                                    <span class="legend">Promoção: (860,00)</span>
                                    <input type="text" name="section_promo_price" value="<?= isset($section_promo_price) ? number_format($section_promo_price, '2', ',', '.') : "0,00"; ?>" placeholder="Preço Promocional:"/>
                                </label>

                                <label class="label">
                                    <span class="legend">Início da Promoção:</span>
                                    <input type="text" class="formTime" name="section_promo_start" value="<?= (isset($section_promo_start) ? date('d/m/Y H:i', strtotime($section_promo_start)) : null); ?>"/>
                                </label>

                                <label class="label">
                                    <span class="legend">Fim da Promoção:</span>
                                    <input type="text" class="formTime" name="section_promo_end" value="<?= (isset($section_promo_end) ? date('d/m/Y H:i', strtotime($section_promo_end)) : null); ?>"/>
                                </label>
                            </div>


                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <?php
                    break;
                case 8:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Nova Pergunta</h1>
                        <form id="perguntas" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_pergunta"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="pergunta_section" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="pergunta_id" value=""/>

                            <label class="label">
                                <span class="legend">Pergunta</span>
                                <input type="text" name="pergunta_title" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">Resposta:</span>
                                <textarea id="pergunta_resposta" class="work_mce" name="pergunta_resposta" rows="3"></textarea>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Pergunta</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Perguntas Frequentes</h1>
                        <?php
                        $Read->ExeRead(DB_LP_PERGUNTAS, "WHERE pergunta_section = :id", "id={$Sessao}");
                        if ($Read->getResult()):
                            foreach ($Read->getResult() as $Pergunta):
                                ?>
                                <article class="product_category box box100" id="<?= $Pergunta['pergunta_id'] ?>">
                                    <header>
                                        <h1 class="icon-info"><?= $Pergunta['pergunta_title'] ?> <span class="j_resposta"><a href="#" class="j_pergunta" rel="<?= $Pergunta['pergunta_id'] ?>">[Resposta]</a></span></h1>
                                        <a title="Editar Categoria!" href="#" class="btn btn_blue icon-pencil icon-notext j_edit_pergunta" alt="<?= $Pergunta['pergunta_title'] ?>"  rel="<?= $Pergunta['pergunta_id'] ?>"></a>
                                        <span rel="product_category" class="j_delete_action btn btn_red icon-cancel-circle icon-notext" id="<?= $Pergunta['pergunta_id'] ?>"></span>
                                        <span rel="product_category" callback="LandingPages" callback_action="delete_pergunta" class="j_delete_action_confirm btn btn_yellow icon-warning" style="display: none;" id="<?= $Pergunta['pergunta_id'] ?>">Deletar Categoria?</span>
                                    </header>

                                    <article class="product_subcategory" style="display: none;background: #f1f1f1;">
                                        <div class="htmlchars">
                                            <?= $Pergunta['pergunta_resposta'] ?>
                                        </div>
                                    </article>
                                </article>
                                <?php
                            endforeach;
                        else:
                            echo Erro("<span class='al_center icon-notification'>Ainda não existe perguntas cadastrados</span>", E_USER_NOTICE);
                        endif;
                        ?>
                    </div>
                    <?php
                    break;
                case 9:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Novo Serviço</h1>
                        <form id="servicos" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_service"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="service_section" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="service_id" value=""/>

                            <label class="label">
                                <span class="legend">Ícone: <a class="icon-IcoMoon" target="_blank" title="Consultar Ícones" href="dashboard.php?wc=config/samples#icons">VER ÍCONES DISPONÍVEIS!</a></span>
                                <input style="font-size: 1.5em;" type="text" name="service_icon" value="" placeholder="Ícone do Serviço:" required/>
                            </label>

                            <label class="label">
                                <span class="legend">Título</span>
                                <input type="text" name="service_title" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">Descrição:</span>
                                <textarea id="service_desc" name="service_desc" rows="3"></textarea>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Serviço</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Serviços</h1>
                        <?php
                        $Read->ExeRead(DB_LP_SERVICE, "WHERE service_section = :id", "id={$Sessao}");
                        if ($Read->getResult()):
                            foreach ($Read->getResult() as $Servico):
                                ?>
                                <article style="text-align: center;" class="product_category box box25" id="<?= $Servico['service_id'] ?>">
                                    <header>
                                        <span style="display: block;font-size: 2.4em;" class="icon-notext <?= $Servico['service_icon'] ?>"></span>
                                        <h1><?= $Servico['service_title'] ?></h1>
                                        <p class="service_desc"><?= $Servico['service_desc'] ?></p>
                                        <a title="Editar Serviço!" href="#" class="btn btn_blue icon-pencil icon-notext j_edit_service" alt="<?= $Servico['service_title'] ?>" icon="<?= $Servico['service_icon'] ?>"  rel="<?= $Servico['service_id'] ?>"></a>
                                        <span rel="product_category" class="j_delete_action btn btn_red icon-cancel-circle icon-notext" id="<?= $Servico['service_id'] ?>"></span>
                                        <span rel="product_category" callback="LandingPages" callback_action="delete_service" class="j_delete_action_confirm btn btn_yellow icon-warning" style="display: none;" id="<?= $Servico['service_id'] ?>">Deletar Serviço?</span>
                                    </header>
                                </article>
                                <?php
                            endforeach;
                        else:
                            echo Erro("<span class='al_center icon-notification'>Ainda não existe serviços cadastrados</span>", E_USER_NOTICE);
                        endif;
                        ?>
                    </div>
                    <?php
                    break;
                case 10:
                    $Read->ExeRead(DB_LP_SOBRE, "WHERE sobre_section = :id", "id={$Sessao}");
                    if ($Read->getResult()):
                        extract($Read->getResult()[0]);
                    endif;
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Sobre</h1>
                        <form id="autor" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_sobre"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="sobre_section" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="sobre_id" value="<?= isset($sobre_id) ? $sobre_id : '' ?>"/>

                            <label class="label">
                                <span class="legend">Foto (400x400)</span>
                                <input type="file" class="wc_loadimage" name="sobre_cover"/>
                            </label>
                            <div class="course_create_cover" style="max-width: 80px;margin-bottom: 10px;">
                                <div class="upload_progress none">0%</div>
                                <?php
                                $AutorCover = (!empty($sobre_cover) && file_exists("../_activepages/{$sobre_cover}") && !is_dir("../_activepages/{$sobre_cover}") ? "_activepages/{$sobre_cover}" : 'admin/_img/no_image.jpg');
                                ?>
                                <img class="course_thumb sobre_cover" alt="Capa" title="Capa" src="../tim.php?src=<?= $AutorCover; ?>&w=<?= 80 ?>&h=<?= 80 ?>" default="../tim.php?src=<?= $AutorCover; ?>&w=<?= 80 ?>&h=<?= 80 ?>"/>
                            </div>

                            <label class="label">
                                <span class="legend">Descrição:</span>
                                <textarea id="sobre_desc" class="work_mce" name="sobre_desc" rows="3"><?= isset($sobre_desc) ? $sobre_desc : '' ?></textarea>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <?php
                    break;
                case 11:

                    $Read->ExeRead(DB_LP_AUTOR, "WHERE autor_section = :id", "id={$Sessao}");
                    if ($Read->getResult()):
                        extract($Read->getResult()[0]);
                    endif;
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Novo Autor</h1>
                        <form id="autor" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_autor"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="autor_section" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="autor_id" value="<?= isset($autor_id) ? $autor_id : '' ?>"/>

                            <label class="label">
                                <span class="legend">Foto (400x400)</span>
                                <input type="file" class="wc_loadimage" name="autor_cover"/>
                            </label>
                            <div class="course_create_cover" style="max-width: 80px;margin-bottom: 10px;">
                                <div class="upload_progress none">0%</div>
                                <?php
                                $AutorCover = (!empty($autor_cover) && file_exists("../_activepages/{$autor_cover}") && !is_dir("../_activepages/{$autor_cover}") ? "_activepages/{$autor_cover}" : 'admin/_img/no_image.jpg');
                                ?>
                                <img class="course_thumb autor_cover" alt="Capa" title="Capa" src="../tim.php?src=<?= $AutorCover; ?>&w=<?= 80 ?>&h=<?= 80 ?>" default="../tim.php?src=<?= $AutorCover; ?>&w=<?= 80 ?>&h=<?= 80 ?>"/>
                            </div>
                            <label class="label">
                                <span class="legend">Nome</span>
                                <input type="text" name="autor_title" value="<?= isset($autor_title) ? $autor_title : '' ?>" required/>
                            </label>

                            <label class="label">
                                <span class="legend">Descrição:</span>
                                <textarea id="autor_desc" class="work_mce" name="autor_desc" rows="3"><?= isset($autor_desc) ? $autor_desc : '' ?></textarea>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Autor</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <?php
                    break;
                case 12:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Novo Palestrante</h1>
                        <form id="palestrante" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_palestrante"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="palestrante_section" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="palestrante_id" value=""/>

                            <label class="label">
                                <span class="legend">Foto (400x400)</span>
                                <input type="file" class="wc_loadimage" name="palestrante_cover"/>
                            </label>
                            <div class="course_create_cover" style="max-width: 80px;margin-bottom: 10px;">
                                <div class="upload_progress none">0%</div>
                                <?php
                                $PalestranteCover = (!empty($palestrante_cover) && file_exists("../_activepages/{$palestrante_cover}") && !is_dir("../_activepages/{$palestrante_cover}") ? "_activepages/{$palestrante_coverg}" : 'admin/_img/no_image.jpg');
                                ?>
                                <img class="course_thumb palestrante_cover" alt="Capa" title="Capa" src="../tim.php?src=<?= $PalestranteCover; ?>&w=<?= 80 ?>&h=<?= 80 ?>" default="../tim.php?src=<?= $CourseCover; ?>&w=<?= 80 ?>&h=<?= 80 ?>"/>
                            </div>
                            <label class="label">
                                <span class="legend">Nome</span>
                                <input type="text" name="palestrante_title" value="" required/>
                            </label>
                            <label class="label">
                                <span class="legend">Especialidade</span>
                                <input type="text" name="palestrante_prof" value="" required/>
                            </label>

                            <label class="label">
                                <span class="legend">Descrição:</span>
                                <textarea id="palestrante_desc" class="work_mce" name="palestrante_desc" rows="3"></textarea>
                            </label>

                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Palestrante</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Palestrantes</h1>
                        <?php
                        $Read->ExeRead(DB_LP_PALESTRANTES, "WHERE palestrante_section = :id", "id={$Sessao}");
                        if ($Read->getResult()):
                            foreach ($Read->getResult() as $Palestrante):
                                $Cover = (!empty($Palestrante['palestrante_cover']) && file_exists("../_activepages/{$Palestrante['palestrante_cover']}") && !is_dir("../_activepages/{$Palestrante['palestrante_cover']}") ? BASE . "/_activepages/{$Palestrante['palestrante_cover']}" : 'admin/_img/no_image.jpg');
                                ?>
                                <article style="text-align: center;" class="product_category box box25" id="<?= $Palestrante['palestrante_id'] ?>">
                                    <header style="text-align: center;">
                                        <img class="pl_cover" style="border-radius: 100%;width: 100px; height: 100px;" src="<?= $Cover ?>" class="icon-notext " />
                                        <h1><?= $Palestrante['palestrante_title'] ?></h1>
                                        <p class="service_desc"><?= $Palestrante['palestrante_prof'] ?></p>
                                        <div class="palestrante_desc" style="display: none;"><?= $Palestrante['palestrante_desc'] ?></div>
                                        <a title="Editar Palestrante!" href="#" class="btn btn_blue icon-pencil icon-notext j_edit_palestrante" alt="<?= $Palestrante['palestrante_title'] ?>" prof="<?= $Palestrante['palestrante_prof'] ?>"  rel="<?= $Palestrante['palestrante_id'] ?>"></a>
                                        <span rel="product_category" class="j_delete_action btn btn_red icon-cancel-circle icon-notext" id="<?= $Palestrante['palestrante_id'] ?>"></span>
                                        <span rel="product_category" callback="LandingPages" callback_action="delete_palestrante" class="j_delete_action_confirm btn btn_yellow icon-warning" style="display: none;" id="<?= $Palestrante['palestrante_id'] ?>">Deletar Palestrante?</span>
                                    </header>
                                </article>
                                <?php
                            endforeach;
                        else:
                            echo Erro("<span class='al_center icon-notification'>Ainda não existe palestrantes cadastrados</span>", E_USER_NOTICE);
                        endif;
                        ?>
                    </div>
                    <?php
                    break;
                case 13:
                    $Read->ExeRead(DB_LP_MAP, "WHERE map_section = :id", "id={$Sessao}");
                    if ($Read->getResult()):
                        extract($Read->getResult()[0]);
                    endif;
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <h1>Novo Autor</h1>
                        <form id="autor" name="page_social" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="add_map"/>
                            <input type="hidden" name="page_id" value="<?= $Active; ?>"/>
                            <input type="hidden" name="map_section" value="<?= $Sessao; ?>"/>
                            <input type="hidden" name="map_id" value="<?= isset($map_id) ? $map_id : '' ?>"/>


                            <label class="label">
                                <span class="legend">Nome Local</span>
                                <input type="text" name="map_title" value="<?= isset($map_title) ? $map_title : '' ?>" required/>
                            </label>
                            <label class="label">
                                <span class="legend">Endereço</span>
                                <input type="text" name="map_addr" value="<?= isset($map_addr) ? $map_addr : '' ?>" required/>
                            </label>
                            <label class="label">
                                <span class="legend">Coordenadas (-15.815749, -47.844784)</span>
                                <input type="text" name="map_coord" value="<?= isset($map_coord) ? $map_coord : '' ?>" required/>
                            </label>
                            <label class="label">
                                <span class="legend">Google Maps Key</span>
                                <input type="text" name="map_key" value="<?= isset($map_key) ? $map_key : '' ?>" required/>
                            </label>

                            <p>Pegar Chave Google Maps: <a href="https://developers.google.com/maps/documentation/javascript/get-api-key?hl=pt-br#key" target="_blank" >https://developers.google.com/maps/documentation/javascript/get-api-key?hl=pt-br#key</a></p>


                            <div class="wc_actions">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar Mapa</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <?php
                    break;
                case 14:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <form class="auto_save" name="page_create" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="sessao_maneger"/>
                            <input type="hidden" name="section_id" value="<?= $section_id ?>" />
                            <input type="hidden" name="section_type" value="<?= $section_type ?>" />
                            <textarea name="section_ads_code" rows="10" placeholder="INSIRA O CÓDIGO GERADO PELO GOOGLE ADSENSE"><?= $section_ads_code ?></textarea>

                            <div class="wc_actions" style="margin-top: 15px;">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <?php
                    break;
                case 15:
                    ?>
                    <div class="panel" style="margin-top: 10px;">
                        <form class="auto_save" name="page_create" action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="sessao_maneger"/>
                            <input type="hidden" name="section_id" value="<?= $section_id ?>" />
                            <input type="hidden" name="section_type" value="<?= $section_type ?>" />
                            <label class="label">
                                <span class="legend">Data</span>
                                <input name="section_date" class="formTime" value="<?= $section_date ? date("d/m/Y H:i:s", strtotime($section_date)) : '' ?>">
                            </label>
                            <div class="wc_actions" style="margin-top: 15px;">
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                        </form>
                    </div>
                    <?php
                    break;
                case 16:
                    ?>

                    <div class="page_gerent_sections">
                        <div class="panel_header success">
                            <span>
                                <span class="fl_right btn btn_green icon-plus icon-notext j_pacote" title="Adicionar Pacote"></span>
                                <span class="fl_right btn btn_green icon-notext icon-spinner9 wc_drag_active" title="Organizar Módulos"></span>
                            </span>
                            <h2 class="icon-file-text2">Pacotes:</h2>


                        </div>
                        <div class="panel">
                            <article class="page_gerent_section wc_draganddrop" callback="LandingPages" callback_action="section_order" id="17">
                                <h1 class="row_title icon-checkmark">
                                    PACOTE GOLD
                                </h1><p class="row info">
                                    <span>áte 21/12/2017</span>                                </p><p class="row">
                                    <a href="dashboard.php?wc=activepages/sessao&amp;active=3&amp;id=17" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                    <span rel="page_gerent_section" class="j_delete_action btn btn_red icon-cancel-circle icon-notext" id="17"></span>
                                    <span rel="page_gerent_section" callback="LandingPages" callback_action="section_delete" class="j_delete_action_confirm btn btn_yellow icon-warning" style="display: none;" id="17">Deletar Categoria?</span>

                                </p>
                            </article>
                        </div>
                    </div>


                    <div class="workcontrol_pacote" style="display: block;">
                        <form name="pdt_size" action="" method="post">
                            <input type="hidden" name="callback" value="LandingPages"/>
                            <input type="hidden" name="callback_action" value="pacote_create"/>
                            <input type="hidden" name="section_id" value="<?= $section_id ?>" />
                            <input type="hidden" name="section_type" value="<?= $section_type ?>" />
                            <label class="label">
                                <span style="width: 100%;text-align: left;" class="legend">Nome Pacote</span>
                                <input style="width: 100%;margin: 0;" type="text" name="pacote_title" value="">
                            </label>
                            <label class="label">
                                <span style="width: 100%;text-align: left;" class="legend">Beneficios do Pacote(separado por vírgula)</span>
                                <textarea style="width: 100%;margin: 0;" name="pacote_intens" rows="5"></textarea>
                                <p style="font-size: 0.7em;text-transform: uppercase;">Ex: Acesso aos 2 dias do Evento, Material de Apoio, Café da Manhã, Almoço </p>
                            </label>

                            <div class="wc_actions" style="margin-top: 15px;">
                                <label class="label_check label_publish"><input style="margin-top: -1px;" type="checkbox" value="1" name="pacote_status"> Publicar Agora!</label>
                                <button name="public" value="1" class="btn btn_green icon-share">Salvar</button>
                                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                            </div>
                            <div class="workcontrol_pdt_size_close">X</div>
                            <div class="clear"></div>
                        </form>
                    </div>


                    <?php
                    break;
            endswitch;
            ?>
        </div>
        <div class="box box30">
            <div class="course_create_cover">
                <div class="upload_progress none">0%</div>
                <?php
                $CourseCover = (!empty($section_background_img) && file_exists("../_activepages/{$section_background_img}") && !is_dir("../_activepages/{$section_background_img}") ? "_activepages/{$section_background_img}" : 'admin/_img/no_image.jpg');
                ?>
                <img class="course_thumb section_background_img" alt="Capa" title="Capa" src="../tim.php?src=<?= $CourseCover; ?>&w=<?= IMAGE_W / 2; ?>&h=<?= IMAGE_H / 2; ?>" default="../tim.php?src=<?= $CourseCover; ?>&w=<?= IMAGE_W / 2; ?>&h=<?= IMAGE_H / 2; ?>"/>
            </div>
            <div class="panel">
                <form class="auto_save" name="page_create" action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="callback" value="LandingPages"/>
                    <input type="hidden" name="callback_action" value="sessao_maneger"/>
                    <input type="hidden" name="section_id" value="<?= $section_id ?>" />
                    <input type="hidden" name="section_type" value="<?= $section_type ?>" />
                    <label class="label">
                        <span class="legend">IMAGEM FUNDO</span>
                        <input type="file" class="wc_loadimage" name="section_background_img"/>
                    </label>
                    <label class="label">
                        <span class="legend">COR FUNDO (#ffffff)</span>
                        <input type="text" name="section_background_color" placeholder="Cor de fundo" value="<?= $section_background_color ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">COR TÍTULO (#ffffff)</span>
                        <input type="text" name="section_title_color" placeholder="Cor do título" value="<?= $section_title_color ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">COR HEDLINE (#ffffff)</span>
                        <input type="text" name="section_hedline_color" placeholder="Cor da Hedline" value="<?= $section_hedline_color ?>" />
                    </label>
                    <label class="label">
                        <span class="legend">COR TEXTO (#ffffff)</span>
                        <input type="text" name="section_text_color" placeholder="Cor do Texto" value="<?= $section_text_color ?>" />
                    </label>

                    <div class="wc_actions">
                        <label class="label_check label_publish <?= ($section_status == 1 ? 'active' : ''); ?>"><input style="margin-top: -1px;" type="checkbox" value="1" name="section_status" <?= ($section_status == 1 ? 'checked' : ''); ?>> Publicar Agora!</label>
                        <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                        <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                    </div>
                </form>
            </div>

        </div>
        <?php
    endif;
    ?>



</div>

<script>

    $('.j_edit_video').click(function () {
        var id = $(this).attr('rel');
        var desc = $(this).attr('desc');
        var yt = $(this).attr('yt');
        var user = $(this).attr('user');

        $('input[name=video_user]').val(user);
        $('input[name=video_desc]').val(desc);
        $('input[name=video_yt_id]').val(yt);
        $('input[name=video_id]').val(id);
        $('#depoimento_video').find('input[name=callback_action]').val('edit_video');



        return false;
    });
    $('.j_edit_depoimento').click(function () {
        var id = $(this).attr('rel');
        var texto = $(this).attr('texto');
        var prof = $(this).attr('prof');
        var user = $(this).attr('user');
        $('input[name=depoimento_user]').val(user);
        tinyMCE.get('depoimento_text').setContent(texto);
        $('input[name=depoimento_profissao]').val(prof);
        $('input[name=depoimento_id]').val(id);
        $('#depoimento_texto').find('input[name=callback_action]').val('edit_depoimento');



        return false;
    });

    $('.j_pergunta').click(function () {
        $("#" + $(this).attr('rel')).find('.product_subcategory').slideToggle();
        return false;
    });

    $('.j_edit_pergunta').click(function () {
        var id = $(this).attr('rel');
        var texto = $('#' + id).find(".htmlchars").html();
        var title = $(this).attr('alt');

        $('input[name=pergunta_title]').val(title);
        tinyMCE.get('pergunta_resposta').setContent(texto);
        $('input[name=pergunta_id]').val(id);
        $('#perguntas').find('input[name=callback_action]').val('edit_pergunta');



        return false;
    });

    $('.j_edit_service').click(function () {
        var id = $(this).attr('rel');
        var texto = $('#' + id).find('.service_desc').html();
        var icon = $(this).attr('icon');
        var title = $(this).attr('alt');

        $('input[name=service_title]').val(title);
        $('input[name=service_id]').val(id);
        $('input[name=service_icon]').val(icon);
        $('#service_desc').val(texto);
        $('#servicos').find('input[name=callback_action]').val('edit_service');



        return false;
    });
    $('.j_edit_palestrante').click(function () {
        var id = $(this).attr('rel');
        var texto = $('#' + id).find('.palestrante_desc').html();
        var prof = $(this).attr('prof');
        var title = $(this).attr('alt');
        var cover = $('#' + id).find('.pl_cover').attr('src');


        $('input[name=palestrante_title]').val(title);
        $('input[name=palestrante_id]').val(id);
        $('input[name=palestrante_prof]').val(prof);
        tinyMCE.get('palestrante_desc').setContent(texto);
        $('#palestrante').find('input[name=callback_action]').val('edit_palestrante');
        $('#palestrante').find('.palestrante_cover').attr('src', cover);


        return false;
    });

    $('.j_pdt').change(function () {
        var id = $(this).val();
        var callback = 'LandingPages';
        var callback_action = 'find_pdt';

        $.post('_ajax/' + callback + '.ajax.php', {callback: callback, callback_action: callback_action, key: id}, function (data) {
            $('input[name=pdt_offer_price]').val(data.pdt_offer_price);
            $('input[name=pdt_offer_start]').val(data.pdt_offer_start);
            $('input[name=pdt_offer_end]').val(data.pdt_offer_end);
        }, 'json');
    });


    $('input[name=section_promo_type]').change(function () {
        $('.lp_type').fadeOut(0);
        $('.' + $(this).attr('rel')).fadeIn(0);
    });



</script>