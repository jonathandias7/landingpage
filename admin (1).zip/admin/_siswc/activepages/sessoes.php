<?php
$AdminLevel = LEVEL_WC_ACTIVEPAGES;
if (!APP_ACTIVEPAGES || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

$ActiveId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($ActiveId):
    $Read->ExeRead(DB_LP_PAGES, "WHERE page_id = :id", "id={$ActiveId}");
    if ($Read->getResult()):
        $FormData = array_map('htmlspecialchars', $Read->getResult()[0]);
        extract($FormData);


        $Cover = (file_exists("../_activepages/{$page_cover}") && !is_dir("../_activepages/{$page_cover}") ? "_activepages/{$page_cover}" : 'admin/_img/no_image.jpg');

    else:
        $_SESSION['trigger_controll'] = "<b>OPPSS {$Admin['user_name']}</b>, você tentou gerenciar um curso que não existe ou que foi removido recentemente!";
        header('Location: dashboard.php?wc=teach/courses');
    endif;
else:
    $_SESSION['trigger_controll'] = "<b>OPPSS {$Admin['user_name']}</b>, você tentou gerenciar um curso que não existe ou que foi removido recentemente!";
    header('Location: dashboard.php?wc=teach/courses');
endif;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-lab">Gerenciar <?= $page_title ? $page_title : 'Curso'; ?></h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=activepages/home">Active Pages</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=activepages/create&id=<?= $page_id; ?>">Editar <?= $page_title; ?></a>
        </p>
    </div>

    <div class="dashboard_header_search">
        <a title="Gerenciar Curso!" href="dashboard.php?wc=activepages/create&id=<?= $ActiveId; ?>" class="wc_view btn btn_blue icon-lab">Editar Page!</a>
    </div>
</header>

<div class="dashboard_content">
    <form class="auto_save" name="course_create" action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="callback" value="Courses"/>
        <input type="hidden" name="callback_action" value="manager"/>
        <input type="hidden" name="course_id" value="<?= $ActiveId; ?>"/>

        <div class="box box70">
            <div class="page_gerent_sections">
                <div class="panel_header success">
                    <span>
                        <a href="dashboard.php?wc=activepages/sessao&active=<?= $page_id; ?>" class="fl_right btn btn_green icon-plus icon-notext" title="Adicionar Módulo"></a>
                        <span class="fl_right btn btn_green icon-notext icon-spinner9 wc_drag_active" title="Organizar Módulos"></span>
                    </span>
                    <h2 class="icon-file-text2">Seções:</h2>
                </div>
                <div class="panel">
                    <?php
                    $Read->ExeRead(DB_LP_SECTIONS, "WHERE section_page = :id ORDER BY section_order ASC", "id={$ActiveId}");

                    if (!$Read->getResult()):
                        echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem módulo cadastrados. Clique em <span class='icon-plus icon-notext'></span> para cadastrar o primeiro!</div>";
                    else:
                        foreach ($Read->getResult() as $Module):
                            extract($Module);
                            ?>
                            <article class="page_gerent_section wc_draganddrop" callback='LandingPages' callback_action='section_order' id="<?= $section_id; ?>">
                                <h1 class="row_title <?= (!empty($section_status) ? 'icon-checkmark' : 'icon-cross'); ?>">
                                    <?= $section_title; ?>[<?= getWcSessaoType($section_type)['title']; ?>]
                                </h1><p class="row info">
                                    <?= $section_home ? '<span>Home</span>' : '' ?><?= $section_confirma ? '<span>Confirma</span>' : '' ?><?= $section_obrigado ? '<span>Obrigado</span>' : '' ?>
                                </p><p class="row">
                                    <a href="dashboard.php?wc=activepages/sessao&active=<?= $ActiveId; ?>&id=<?= $section_id; ?>" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                    <span rel='page_gerent_section' class='j_delete_action btn btn_red icon-cancel-circle icon-notext' id='<?= $section_id; ?>'></span>
                                    <span rel='page_gerent_section' callback='LandingPages' callback_action='section_delete' class='j_delete_action_confirm btn btn_yellow icon-warning' style='display: none;' id='<?= $section_id; ?>'>Deletar Categoria?</span>

                                </p>
                            </article>
                            <?php
                        endforeach;
                    endif;
                    ?>
                    <div class="clear"></div>
                </div>
            </div>
        </div>

        <div class="box box30">
            <img src='../tim.php?src=<?= $Cover; ?>&w=<?= IMAGE_W / 3; ?>&h=<?= IMAGE_H / 3; ?>' title='<?= $page_title; ?>' alt='<?= $page_title; ?>'/>
            <div class='course_gerent_thumb panel'>
                <h1>Curso <?= $page_title; ?></h1>
            </div>
        </div>
    </form>
</div>