<?php
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

//Usuario
//recebe o valor passado pelo id (enviado da li dentro do wc_menu.php)

// Entenda o filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
// filter_input = realiza uma filtragem recebida por um botão ou input
// 1 - parametro(pode ser via GET OU POST) - Nesse caso INPUT_GET = Recebera o valor do enviado pelo input pelo GET(url)
// 2 - parametro - 'id' = nome do campo que irá ser filtrado (o nome id  é opcional)
// 3 - parametro - formato aceito pelo filtro(FILTER_VALIDATE_INT =  só irá aceitar valores inteiros)

$Id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    
    //verifica se existe o id
    //exemplo https://euqueroqueimarporti.com.br/admin/dashboard.php?wc=mdpcustom/create&id=
         if($Id){
             $Read->ExeRead('mdp_custom', "WHERE custom_id = :id","id={$Id}");
                if($Read->getResult()):
             extract($Read->getResult()[0]);
             
           
             endif;
             
        }else{
            
        $create = ['custom_id' => 1];
        $Create->ExeCreate('mdp_custom', $create);
        Header("Location: dashboard.php?wc=mdpcustom/create&id=1");
         exit;
}
?>


<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-droplet">CUSTOMIZAR</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
          Conta
        </p>
    </div>


</header>


<div class="dashboard_content">

    <div class="box box100">

        

        <div class="panel">
             <div class="mdplogo workcontrol_imageupload none" id="post_control">
    <div class="workcontrol_imageupload_content">
        <form name="workcontrol_post_upload" action="" method="post" enctype="multipart/form-data">
           
            <input type="hidden" name="callback" value="MDPCustom"/>
            <input type="hidden" name="callback_action" value="sendimage_logo"/>
            <div class="upload_progress none" style="padding: 5px; background: #00B594; color: #fff; width: 0%; text-align: center; max-width: 100%;">0%</div>
            <div style="overflow: auto; max-height: 300px;">
                <img class="image image_default" alt="Nova Imagem" title="Nova Imagem" src="<?= INCLUDE_PATH .'/img/logo/logo.png'; ?>" default="../tim.php?src=admin/_img/no_image.jpg&w=<?= IMAGE_W; ?>&h=<?= IMAGE_H; ?>"/>
            </div>
            <div class="workcontrol_imageupload_actions">
                <input class="wc_loadimage" type="file" name="image" required/>
                <span class="workcontrol_imageupload_close icon-cancel-circle btn btn_red" id="post_control" style="margin-right: 8px;">Fechar</span>
                <button class="btn btn_green icon-image">Enviar e Inserir!</button>
                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
            </div>
            <div class="clear"></div>
        </form>
    </div>
</div>
 <div class="mdpicon workcontrol_imageupload none" id="post_control">
    <div class="workcontrol_imageupload_content">
        <form name="workcontrol_post_upload" action="" method="post" enctype="multipart/form-data">
           
            <input type="hidden" name="callback" value="MDPCustom"/>
            <input type="hidden" name="callback_action" value="sendimage_icon"/>
            <div class="upload_progress none" style="padding: 5px; background: #00B594; color: #fff; width: 0%; text-align: center; max-width: 100%;">0%</div>
            <div style="overflow: auto; max-height: 300px;">
                 <img class="image image_default" alt="Nova Imagem" title="Nova Imagem" src="<?= INCLUDE_PATH .'/img/favicon.png'; ?>" default="../tim.php?src=admin/_img/no_image.jpg&w=<?= IMAGE_W; ?>&h=<?= IMAGE_H; ?>"/>
            </div>
            <div class="workcontrol_imageupload_actions">
                <input class="wc_loadimage" type="file" name="image" required/>
                <span class="workcontrol_imageupload_close icon-cancel-circle btn btn_red" id="post_control" style="margin-right: 8px;">Fechar</span>
                <button class="btn btn_green icon-image">Enviar e Inserir!</button>
                 <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
            
            </div>
            <div class="clear"></div>
        </form>
    </div>
</div>
            
            <div class="mdpbg workcontrol_imageupload none" id="post_control">
    <div class="workcontrol_imageupload_content">
        <form name="workcontrol_post_upload" action="" method="post" enctype="multipart/form-data">
           
            <input type="hidden" name="callback" value="MDPCustom"/>
            <input type="hidden" name="callback_action" value="sendimage_fundo"/>
              <input type="hidden" name="tipo" value="3"/>
            <div class="upload_progress none" style="padding: 5px; background: #00B594; color: #fff; width: 0%; text-align: center; max-width: 100%;">0%</div>
            <div style="overflow: auto; max-height: 300px;">
              <img class="image image_default" alt="Nova Imagem" title="Nova Imagem" src="<?= INCLUDE_PATH .'/images/default.jpg'; ?>" default="../tim.php?src=admin/_img/no_image.jpg&w=<?= IMAGE_W; ?>&h=<?= IMAGE_H; ?>"/>
      </div>
            <div class="workcontrol_imageupload_actions">
                <input class="wc_loadimage" type="file" name="image" required/>
                <span class="workcontrol_imageupload_close icon-cancel-circle btn btn_red" id="post_control" style="margin-right: 8px;">Fechar</span>
                <button class="btn btn_green icon-image">Enviar e Inserir!</button>
                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
            </div>
            <div class="clear"></div>
        </form>
    </div>
</div>
<div class="mdpbg1 workcontrol_imageupload none" id="post_control">
    <div class="workcontrol_imageupload_content">
        <form name="workcontrol_post_upload" action="" method="post" enctype="multipart/form-data">
           
            <input type="hidden" name="callback" value="MDPCustom"/>
            <input type="hidden" name="callback_action" value="sendimage_fundo1"/>
              <input type="hidden" name="tipo" value="3"/>
            <div class="upload_progress none" style="padding: 5px; background: #00B594; color: #fff; width: 0%; text-align: center; max-width: 100%;">0%</div>
            <div style="overflow: auto; max-height: 300px;">
                <img class="image image_default" alt="Nova Imagem" title="Nova Imagem" src="<?= INCLUDE_PATH .'/images/default1.jpg'; ?>" default="../tim.php?src=admin/_img/no_image.jpg&w=<?= IMAGE_W; ?>&h=<?= IMAGE_H; ?>"/>
     
            </div>
            <div class="workcontrol_imageupload_actions">
                <input class="wc_loadimage" type="file" name="image" required/>
                <span class="workcontrol_imageupload_close icon-cancel-circle btn btn_red" id="post_control" style="margin-right: 8px;">Fechar</span>
                <button class="btn btn_green icon-image">Enviar e Inserir!</button>
                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
            </div>
            <div class="clear"></div>
        </form>
    </div>
</div>
            <div class="mdpbg2 workcontrol_imageupload none" id="post_control">
    <div class="workcontrol_imageupload_content">
        <form name="workcontrol_post_upload" action="" method="post" enctype="multipart/form-data">
           
            <input type="hidden" name="callback" value="MDPCustom"/>
            <input type="hidden" name="callback_action" value="sendimage_fundo2"/>
              <input type="hidden" name="tipo" value="3"/>
            <div class="upload_progress none" style="padding: 5px; background: #00B594; color: #fff; width: 0%; text-align: center; max-width: 100%;">0%</div>
            <div style="overflow: auto; max-height: 300px;">
                 <img class="image image_default" alt="Nova Imagem" title="Nova Imagem" src="<?= INCLUDE_PATH .'/images/default2.jpg'; ?>" default="../tim.php?src=admin/_img/no_image.jpg&w=<?= IMAGE_W; ?>&h=<?= IMAGE_H; ?>"/>
            </div>
            <div class="workcontrol_imageupload_actions">
                <input class="wc_loadimage" type="file" name="image" required/>
                <span class="workcontrol_imageupload_close icon-cancel-circle btn btn_red" id="post_control" style="margin-right: 8px;">Fechar</span>
                <button class="btn btn_green icon-image">Enviar e Inserir!</button>
                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
            </div>
            <div class="clear"></div>
        </form>
    </div>
</div>
	<div class="label_100">	
						<div class="label_33">	
					    	<label class="label">
						<a class='btn btn_green' id='mdplogo'>ALTERAR LOGO</a>
						</label>
					    	<label class="label">
						<a class='btn btn_red' id='mdpicon'>ALTERAR ICON</a>
						</label>
							<label class="label">
						<a class='btn btn_blue' id='mdpbg'>ALTERAR BG</a>
						</label>
						</div>

           <form class="auto_save" name="variacao_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="MDPCustom"/>
                <input type="hidden" name="callback_action" value="custom_update"/>
                <div class="label_50 m_top">
				<input type="hidden" name="custom_id" value="<?= $Id?>"/>
				    
				    
                    	<input id='inpbkg' type="hidden" name="custom_background" value="<?= $custom_background;?>">
                    	<input id='inpcor' type="hidden" name="custom_color" value="<?= $custom_color;?>">
                        <input id='inpcorh' type="hidden" name="custom_color_hover" value="<?= $custom_color_hover;?>">
                     	<input id='inprod' type="hidden" name="custom_rodape" value="<?= $custom_rodape;?>">
                    	<input id='inpbtn' type="hidden" name="custom_btn" value="<?= $custom_btn;?>">
                        <input id='inpbtnh' type="hidden" name="custom_btn_hover" value="<?= $custom_btn_hover;?>">
					
					
						 <div class="panel_header default">
						     
                            <h2 class="icon-home al_center">CUSTOMIZAR CORES</h2>
                        </div>
                        
						<div class="label_50 m_top">	
					    	<label class="label">
    								<span class="legend">Cor de Fundo</span>
								 
								 <input type="color" id='background' value="" />
								 
						     <input type="text" style='background:<?= $custom_background;?>!important' id='backgroundinput' disabled='disabled' name="custom_background"  value="<?= ($custom_background ? $custom_background : null ); ?>"/>
							</label>
							
							<label class="label">
    								<span class="legend">Cor de Fundo Secundaria</span>
    								 <input type="color" id='rodape' value="" />
								<input type="text" style='background:<?= $custom_rodape;?>!important' disabled='disabled' id='rodapeinput'/>
							</label>
							
							</div>
							
							<div class="panel_header default">
                            <h2 class="icon-droplet al_center">CUSTOMIZAR FONTES</h2>
                        </div>
							<div class="label_50 m_top">	
					    	<label class="label">
    							<span class="legend">Cor da Fonte</span>
								<input type="color" id='color' value="" />
								<input type="text" style='background:<?= $custom_color;?>!important' disabled='disabled' id='colorinput'/>
							</label>
							
							<label class="label">
    								<span class="legend">Cor Efeito do Mouse</span>
							    <input type="color" id='colorh' value="" />
								<input type="text" style='background:<?= $custom_color_hover;?>!important' disabled='disabled' id='colorhinput'/>
							</label>
							
							</div>
							<div class="panel_header default">
                            <h2 class="icon-pencil2 al_center">CUSTOMIZAR BOTÕES</h2>
                        
							</div>
							<div class="label_50 m_top">	
					    	<label class="label">
    								<span class="legend">Cor dos botões</span>
								   <input type="color" id='btn' value="" />
								<input type="text" style='background:<?= $custom_btn;?>!important' disabled='disabled' id='btninput'/>
							</label>
							
							<label class="label">
    								<span class="legend">Cor Efeito do Mouse</span>
								<input type="color" id='btnh' value="" />
								<input type="text" style='background:<?= $custom_btn_hover;?>!important' disabled='disabled' id='btnhinput'/>
							</label>
							
							</div>
							
							<div class="panel_header default">
                            <h2 class="icon-pencil2 al_center">TEXTOS SOBRE FUNDOS</h2>
                        
							</div>
							<div class="label_50 m_top">	
					    	<label class="label">
    								<span class="legend">Texto Fundo 1</span>
								<input type="text"  name="custom_txt_bgone" value="<?= $custom_txt_bgone;?>" placeholder='Ex: Cursos gratuitos' />
							</label>		
							<label class="label">
							    	<span class="legend">Texto Fundo 2</span>
						    	<input type="text"  name="custom_txt_bgtwo" value="<?= $custom_txt_bgtwo;?>" placeholder='Ex: Outros Cursos gratuitos'/>
							</label>
                        </div>
                        <!-- <div class="panel_header default">
                            <h2 class="icon-droplet al_center">CUSTOMIZAR FUNDOS</h2>
                        </div>
						<div class="m_top label_50">	
					    	<label class="label al_right">
						<a class='btn btn_blue' id='mdpbg1'>ALTERAR BACKGROUND 1</a>
						<br/>
						</label>
					    	<label class="label">
						<a class='btn btn_light' id='mdpbg2'>ALTERAR BACKGROUND 2</a>
				            <br/>
				        	</label>
						</div>-->
              </div>
		<script>
		    //BACKGROUND
		    $('html').on('change','#background',function(){
		        var background = $(this).val();
		        if(background){
		            
		           
		             $('#inpbkg').html('<input type="hidden" name="custom_background" value="'+ background +'">');
		             $('#backgroundinput').css({'color': background,'background': background});
		        }
		    });
		    
		    //RODAPE
		     $('html').on('change','#rodape',function(){
		        var rodape = $(this).val();
		        if(rodape){
		            
		            $('#inprod').html('<input type="hidden" name="custom_rodape" value="'+ rodape +'">');
		            $('#rodapeinput').css({'color': rodape, 'background': rodape});
		            
		        }
		    });
		    
		    //COLOR
		     $('html').on('change','#color',function(){
		        var color = $(this).val();
		        if(color){
		            
		            $('#inpcor').html('<input type="hidden" name="custom_color" value="'+ color +'">');
		            $('#colorinput').css({'color': color, 'background': color});
		            
		        }
		    });
		    //COLOR HOVER
		     $('html').on('change','#colorh',function(){
		        var colorh = $(this).val();
		        if(colorh){
		            
		            $('#inpcorh').html('<input type="hidden" name="custom_color_hover" value="'+ colorh +'">');
		            $('#colorhinput').css({'color': colorh, 'background': colorh});
		            
		        }
		    });
		     //BTN
		     $('html').on('change','#btn',function(){
		        var btn = $(this).val();
		        if(btn){
		            
		            $('#inpbtn').html('<input type="hidden" name="custom_btn" value="'+ btn +'">');
		            $('#btninput').css({'color': btn, 'background': btn});
		            
		        }
		    });
		    //COLOR HOVER
		     $('html').on('change','#btnh',function(){
		        var btnh = $(this).val();
		        if(btnh){
		            
		            $('#inpbtnh').html('<input type="hidden" name="custom_btn_hover" value="'+ btnh +'">');
		            $('#btnhinput').css({'color': btnh, 'background': btnh});
		            
		        }
		    });
		    
		    
		</script>
			<hr/>
                <div class=" m_top">&nbsp;</div>
                <a style='text-align:center;'><img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </a><button class="btn btn_green icon-price-tags fl_right">Finalizar </button></a>
				
                <div class="clear"></div>
            </form>
              <div class="panel">	
            <div class="label_100">	
           
				<script>
    $('#mdplogo').click(function(){
        $('.mdplogo').fadeIn();
    });
     $('#mdpicon').click(function(){
        $('.mdpicon').fadeIn();
    });
     $('#mdpbg').click(function(){
        $('.mdpbg').fadeIn();
    });
     $('#mdpbg1').click(function(){
        $('.mdpbg1').fadeIn();
    });
     $('#mdpbg2').click(function(){
        $('.mdpbg2').fadeIn();
    });
</script></div>
        </div>
    </div>
</div>
