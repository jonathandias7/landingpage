<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
$Read = new Read;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">ATRIBUTOS</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            Gerenciar Atributos
        </p>
    </div>
	  <div class="dashboard_header_search">
        <a title="Nova Hellobar" href="dashboard.php?wc=mdpplans/createlist" class="btn btn_green icon-plus">Cadastrar Novo Atributo!</a>
    </div>

</header>

<div class="j_content dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Meus Atributos:</h1>
                <div class="clear"></div>
            </header>
            <div class="box_content">
                <?php
                $Read->FullRead("SELECT * FROM mdp_plans_attr");

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem atributos cadastrados.</div>";
                else:
                    foreach ($Read->getResult() as $attr):
                        extract($attr);
                         $Read->FullRead("SELECT  mdp_plans_id, mdp_plans_title FROM mdp_plans WHERE mdp_plans_id = :id", "id={$mdp_plans_attr_min}");
                        if($Read->getResult()):
                            extract($Read->getResult()[0]);
                        endif;
                     
                      
                        ?>
                     <? //if($result != '3' || $result != 0')://valida o filtro?>
					  <?
					  if($mdp_plans_attr_title != null):?>
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $mdp_plans_attr_id; ?>">
                            <h1 class="row_title icon-profile">
                                <?= $mdp_plans_attr_title; ?>
                            </h1><p class="row">
							<?
							$status = ($mdp_plans_attr_status == 1 ? 'ON' : 'OFF');
							$statusColor = ($mdp_plans_attr_status == 1 ? 'bg_green' : 'bg_red');
							$typeColor = ($mdp_plans_attr_min == 1 ? 'bg_yellow' : 'bg_blue');
							?>
                                <span class="<?= $statusColor?>" style="color:#fff; text-align:center; font-size:1em; width:100px;"><b> <?= $status;?></b></span><span class="<?= $typeColor?>" style="color:#fff; text-align:center; font-size:1em; width:200px;"><b>APARTIR DO:  <?= $mdp_plans_title;?></b></span>
                            </p><p class="row">
                                <a title="Editar essa Avaliação" href="dashboard.php?wc=mdpplans/createlist&attr=<?= $mdp_plans_attr_id; ?>" class="btn btn_blue icon-pencil2 icon-notext"></a>
								<a rel="course_list" class="j_delete_action icon-cancel-circle btn btn_red icon-notext" id="<?= $mdp_plans_attr_id; ?>"></a>
								<a rel="course_list" callback='MDPPlans' callback_action="attr_delete" class="j_delete_action_confirm icon-warning btn btn_yellow" style="display: none ;margin-top: 30px;" id="<?= $mdp_plans_attr_id; ?>">Deletar Avaliação?</a>
                </p>
                        </article>
                        <?php
						/* else:
						echo $result;*/
						endif; 
                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		
    </section>
</div>

