<?php
/*****************************
SUPORTE MDP SOFTWARES LTDA
PROJETO: MDP TUTORIAL
SOBRE: Sistema de Tutoriais dinamico.
Pietro Napoleão | atendimento@mdpempresarial.com.br
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2019 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/

$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

 
//Usuario

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

$chars = array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
$serial = '';
$max = count($chars)-1;
for($i=0;$i<20;$i++){
    $serial .= (!($i % 5) && $i ? '-' : '').$chars[rand(0, $max)];
}
echo $serial;

$AId = filter_input(INPUT_GET, 'appon', FILTER_VALIDATE_INT);

$host_id = null;
$panel_id = null;
$user_id = null;
if ($AId):
    $Read->ExeRead("mdp_app_on", "WHERE appon_id = :app", "app={$AId}");
    if ($Read->getResult()):
	
        extract($Read->getResult()[0]);
	endif;
else:
$Capp = ['appon_status' => 0, 'app_key' => $serial];
if (empty($Create)):
    $Create = new Create;
endif;
$Create->ExeCreate("mdp_app_on", $Capp);
Header('Location: dashboard.php?wc=mdpsecurity/create&appon='. $Create->getResult());
exit;
endif;


?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-play">EDITAR O app <?= strtoupper((isset($app_title) ? $app_title : "")); ?></h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
           Gerianciar o app <?= (isset($app_title) ? $app_title : ""); ?>
        </p>
    </div>

</header>


<div class="dashboard_content">

    <div class="box box100">

        

        <div class="panel">
           <form class="" name="avaliacao_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="MDPSecurity"/>
                <input type="hidden" name="callback_action" value="appon_edite"/>
				<input type="hidden" name="appon_id" value="<?= $appon_id?>"/>
				<input type="hidden" name="app_ip" value="127.0.0.1"/>
            
				
            
							<div class="label_100">	
							<div class='m_top'>
							<h3 class="icon-cog">CONFIGURAÇÕES</h3>
						</div>	
						<div class="m_top label_33">
						<label class="label">
								<span class="legend">APP</span>
								<select  name="app_id" style="font-size:1.2em;border:solid 3px #00b594;"  required="required">
									<?php
								
									 $Read->FullRead("SELECT app_id, app_title FROM ". "mdp_app");
									if ($Read->getResult()):
									foreach ($Read->getResult() as $a):
                                    echo "<option ";
                                    if ($a['app_id'] == $app_id):
                                        echo " selected='selected'";
                                    endif;
									 
									echo " value='{$a['app_id']}'>";
									if($a['app_title'] != null): 
										echo strtoupper($a['app_title']);
									endif;
									echo "</option>";
									endforeach;
								endif;
							?>
							</select>
						</label>
						<label class="label">
						<span class="legend">USUARIO</span>
								<select  name="app_user" style="font-size:1.2em;border:solid 3px #00b594;"  required="required">
									<?php
								
									 $Read->FullRead("SELECT user_id, user_name, user_lastname FROM ". DB_USERS);
									if ($Read->getResult()):
									foreach ($Read->getResult() as $u):
                                    echo "<option ";
                                    if ($u['user_id'] == $user_id):
                                        echo "style='background:#00b594' selected='selected'";
                                    endif;
									echo " value='{$u['user_id']}'>";
									if($u['user_name'] != null): 
										echo strtoupper($u['user_name'] ." ".$u['user_lastname']);
									endif;
									echo "</option>";
									endforeach;
								endif;
							?>
							</select>
						</label>											
							<label class="label">
						<span class="legend">URL:</span>
						<input value="<?= (isset($app_url) && $app_url != null ? $app_url :'');?>" style="font-size:1.2em;border:solid 3px #00b594;" type="text" placeholder="ex: https://www.mdpempresarial.com.br" name="app_url" required/>
					</label>
						<br/>
						</div>
							
					
		
					
					<div class="m_top label_33">
					<label class="label">
                        <span class="legend">KEY:</span>
                        <input value="<?= (isset($app_key) && $app_key != null ? $app_key : $serial);?>" style="font-size:1.2em;border:solid 3px #00b594;" type="text" placeholder="ex: https://www.mdpempresarial.com.br" name="app_key" required/>

                    </label>
						<label class="label">
                        <span class="legend">STATUS:</span>
                        <select style="font-size:1.2em;color:#000;border:solid 3px #00b594;" name="appon_status">
                            <option value="1"   <?= ($appon_status == 1 ? 'selected="selected"' :'');?>>Ativado</option>
                            <option value="0"  <?= ($appon_status == 0 ? 'selected="selected"' :'');?>>Desativado</option>
                        </select>
                    </label>
					<label class="label">
                        <span class="legend">NOTIFICADO?</span>
                        <select style="font-size:1.2em;color:#000;border:solid 3px #00b594;" name="app_notifica">
                            <option value="1"   <?= ($app_notifica == 1 ? 'selected="selected"' :'');?>>Notificado</option>
                            <option value="0"  <?= ($app_notifica == 0 ? 'selected="selected"' :'');?>>Não Notificado</option>
                        </select>
                    </label>
					 </div>
					 
				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Finalizar </button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>