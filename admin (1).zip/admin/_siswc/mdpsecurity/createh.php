<?php
/*****************************
SUPORTE MDP SOFTWARES LTDA
PROJETO: MDP TUTORIAL
SOBRE: Sistema de Tutoriais dinamico.
Pietro Napoleão | atendimento@mdpempresarial.com.br
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2019 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

//Usuario
$HId = filter_input(INPUT_GET, 'host', FILTER_VALIDATE_INT);


if ($HId):
    $Read->ExeRead(DB_TUTORIAIS_HOST, "WHERE host_id = :host", "host={$HId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
	endif;
else:
$Chost = ['host_status' => 0,'host_color' => '#282828'];
if (empty($Create)):
    $Create = new Create;
endif;
$Create->ExeCreate(DB_TUTORIAIS_HOST, $Chost);
Header('Location: dashboard.php?wc=mdptutorial/createh&host='. $Create->getResult());
exit;
endif;


?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">EDITAR HOST</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
          Gerenciar Host
        </p>
    </div>

    <div class="dashboard_header_search">
        <a title="Voltar para lista de bancos" href="dashboard.php?wc=mdptutorial/homeh" class="btn btn_blue icon-plus">Voltar</a>
    </div>

</header>


<div class="dashboard_content">

    <div class="box box100">

        

        <div class="host">
           <form class="" name="host_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="MDPTuto"/>
                <input type="hidden" name="callback_action" value="host_edite"/>
				<input type="hidden" name="host_id" value="<?= $host_id?>"/>
            
			
						<div class="label_100">	
						<div class="m_top label_50">
							
						<label class="label">
								<span class="legend">NOME DO HOST</span>
								<input style="font-size: 1.4em;color:#000;border:solid 3px #00b594;" type="text"placeholder="Ex: (YouTube, Vimeo,etc...)" value="<?= (isset($host_title) ? $host_title : ""); ?>" name="host_title" required/>
					
						</label>
						<label class="label">
								<span class="legend">BASE DO HOST</span>
								<input style="font-size: 1.4em;color:#000;border:solid 3px #00b594;" type="text"placeholder="Ex:(https://youtube.com/" value="<?= (isset($host_url) ? $host_url : ""); ?>" name="host_url" required/>
							</label>
						
											
                
					<label class="label">
                        <span class="legend">STATUS:</span>
                        <select style="font-size: 1.4em;color:#000;border:solid 3px #00b594;" name="host_status">
                            <option value="1"   <?= ($host_status == 0 ? 'selected="selected"' :'');?>>Ativado</option>
                            <option value="0" <?= ($host_status == 0 ? 'selected="selected"' :'');?>>Desativado</option>
                        </select>
                    </label>
					<label class="label">
						<span class="legend">COR:</span>
						<input style="padding:20px;font-size: 1.4em;color:#000;border:solid 3px #00b594;" type="color" value="<?= $host_color?>" name="host_color" required/>
					</label>
					 </div>
                </div>
              
				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Alterar</button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>
