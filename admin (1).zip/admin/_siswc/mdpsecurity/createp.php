<?php
/*****************************
SUPORTE MDP SOFTWARES LTDA
PROJETO: MDP TUTORIAL
SOBRE: Sistema de Tutoriais dinamico.
Pietro Napoleão | atendimento@mdpempresarial.com.br
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2019 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

//Usuario
$PId = filter_input(INPUT_GET, 'panel', FILTER_VALIDATE_INT);


if ($PId):
    $Read->ExeRead(DB_TUTORIAIS_PANEL, "WHERE panel_id = :panel", "panel={$PId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
	endif;
else:
$Cpanel = ['panel_status' => 0,'panel_color' => 'eee'];
if (empty($Create)):
    $Create = new Create;
endif;
$Create->ExeCreate(DB_TUTORIAIS_PANEL, $Cpanel);
Header('Location: dashboard.php?wc=mdptutorial/createp&panel='. $Create->getResult());
exit;
endif;


?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">EDITAR BANCO</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
          Gerenciar Painel
        </p>
    </div>

    <div class="dashboard_header_search">
        <a title="Voltar para lista de bancos" href="dashboard.php?wc=mdptutorial/homep" class="btn btn_blue icon-plus">Voltar</a>
    </div>

</header>


<div class="dashboard_content">

    <div class="box box100">

        

        <div class="panel">
           <form class="" name="panel_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="MDPTuto"/>
                <input type="hidden" name="callback_action" value="panel_edite"/>
				<input type="hidden" name="panel_id" value="<?= $panel_id?>"/>
            
			
						<div class="label_100">	
						<div class="m_top label_33">
							<label class="label">
								<span class="legend">NOME PAINEL</span>
								<input style="font-size: 1.4em;color:#000;border:solid 3px #00b594;" type="text"placeholder="Ex: admin" value="<?= (isset($panel_title) ? $panel_title : ""); ?>" placeholder="ex:(admin,fornecedor,campus,etc...)" name="panel_title" required/>
					
						</label>
						
						
											
                
					<label class="label">
                        <span class="legend">STATUS:</span>
                        <select style="font-size: 1.4em;color:#000;border:solid 3px #00b594;" name="panel_status">
                            <option value="1"   <?= ($panel_status == 0 ? 'selected="selected"' :'');?>>Ativado</option>
                            <option value="0"   <?= ($panel_status == 0 ? 'selected="selected"' :'');?>>Desativado</option>
                        </select>
                    </label>
					<label class="label">
						<span class="legend">COR:</span>
						<input style="padding:20px;font-size: 1.4em;color:#000;border:solid 3px #00b594;" type="color" value="<?= $panel_color?>" name="panel_color" required/>
					</label>
					 </div>
                </div>
              
				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Alterar</button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>
