<?php
/*****************************
SUPORTE MDP SOFTWARES LTDA
PROJETO: MDP TUTORIAL
SOBRE: Sistema de Tutoriais dinamico.
Pietro Napoleão | atendimento@mdpempresarial.com.br
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2019 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acesser esse página!</div>');
endif;
$PdtId = filter_input(INPUT_GET, 'pdt', FILTER_VALIDATE_INT);

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-office">CLASS</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            Gerenciar Class
        </p>
    </div>
			<div class="dashboard_header_search">
        <a title="Novo O" href="dashboard.php?wc=mdptutorial/createc	" class="btn btn_green icon-plus">Cadastrar Class!</a>
    </div>
</header> 

<div class="dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Lista de Host:</h1>
                <div class="clear"></div>
		
            </header>
            <div class="box_content">
                <?php
                $Read->ExeRead(DB_TUTORIAIS_CLASS);

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem Host cadastrados!</div>";
                else:
                    foreach ($Read->getResult() as $class):
                        extract($class);
                        

					 ?>
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $class_id; ?>">
                             <h1 style='max-width:280px;' class="row_title">
                              
                                <?= " <b style='padding:5px 15px;width:50px;height:50px;background:{$class_color};'></b><span style='width:100%!important;color:#000; padding:5px 5px;  text-align:center; font-size:1.2em; width:300px;'>". $class_title . " "; ?> 
                            </h1><p class="row">
							<?
							$tipo = ($class_status == 1 ? 'ATIVO' : 'DESATIVADO');
							$typeColor = ($class_status == 1 ? 'bg_green' : 'bg_red');
							?>
                             <span class="<?= $typeColor?>" style="color:#fff; text-align:center; font-size:1em; width:200px;"><b><?= $tipo;?></b></span>
                             </p><p class="row">
		
                                <a title="Editar esse banco" href="dashboard.php?wc=mdptutorial/createc&class=<?= $class_id; ?>" class="btn btn_blue icon-pencil2 icon-notext"></a>
								<a rel="course_list" class="j_delete_action icon-cancel-circle btn btn_red icon-notext" id="<?= $class_id; ?>"></a>
								<a rel="course_list" callback='MDPTuto' callback_action="class_delete" class="j_delete_action_confirm icon-warning btn btn_yellow" style="display: none ;margin-top: 30px;" id="<?= $class_id; ?>">Deletar class?</a>
                </p>
                        </article>
                        <?php
						// else:
						//echo $result;
						//endif; 
					//endif;
                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		
    </section>
</div>

