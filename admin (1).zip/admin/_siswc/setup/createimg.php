<?php
$AdminLevel = LEVEL_WC_PAGES;
if (!APP_PAGES || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

$SetupId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($SetupId):
    $Read->ExeRead("mdp_setup_img", "WHERE setup_img_id = :id", "id={$SetupId}");
    if ($Read->getResult()):
        $FormData = array_map('htmlspecialchars', $Read->getResult()[0]);
        extract($FormData);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma página que não existe ou que foi removida recentemente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=attr/home');
        exit;
    endif;
else:
    $SetupCreate = ['setup_img_status' => 0];
    $Create->ExeCreate("mdp_setup_img", $SetupCreate);
    header('Location: dashboard.php?wc=setup/createimg&id=' . $Create->getResult());
    exit;
endif;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-page-break"><?= $setup_img_title ? $setup_img_title : 'Nova Imagem'; ?></h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=pages/home">Setup Imagem</a>
            <span class="crumb">/</span>
            Gerenciar Imagem
        </p>
    </div>

    <div class="dashboard_header_search">
        <a target="_blank" title="Ver no site" href="<?= BASE; ?>" class="wc_view btn btn_green icon-eye">Ver no site!</a>
    </div>
</header>

<div class="workcontrol_imageupload none" id="post_control">
    <div class="workcontrol_imageupload_content">
        <form name="workcontrol_post_upload" action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="callback" value="MDPSetup"/>
            <input type="hidden" name="callback_action" value="sendimage"/>
            <input type="hidden" name="setup_img_id" value="<?= $SetupId; ?>"/>
			
            <div class="upload_progress none" style="padding: 5px; background: #00B594; color: #fff; width: 0%; text-align: center; max-width: 100%;">0%</div>
            <div style="overflow: auto; max-height: 300px;">
                <img class="image image_default" alt="Nova Imagem" title="Nova Imagem" src="../tim.php?src=admin/_img/no_image.jserv&w=<?= IMAGE_W; ?>&h=<?= IMAGE_H; ?>" default="../tim.php?src=admin/_img/no_image.jserv&w=<?= IMAGE_W; ?>&h=<?= IMAGE_H; ?>"/>
            </div>
            <div class="workcontrol_imageupload_actions">
                <input class="wc_loadimage" type="file" name="image" required/>
                <span class="workcontrol_imageupload_close icon-cancel-circle btn btn_red" id="post_control" style="margin-right: 8px;">Fechar</span>
                <button class="btn btn_green icon-image">Enviar e Inserir!</button>
                <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
            </div>
            <div class="clear"></div>
        </form>
    </div>
</div>

<div class="dashboard_content">

    <form class="auto_save" name="setup_img_add" action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="callback" value="MDPSetup"/>
        <input type="hidden" name="callback_action" value="manage"/>
        <input type="hidden" name="setup_img_id" value="<?= $SetupId; ?>"/>
        <div class="box box70">

            <div class="panel_header default">
                <h2 class="icon-page-break">Insira as informações da Imagem</h2>
            </div>

            <div class="panel">
                <label class="label">
                    <span class="legend">Título:</span>
                    <input style="font-size: 1.4em;" type="text" name="setup_img_title" value="<?= $setup_img_title; ?>" placeholder="Título da Imagem:" required/>
                </label>

                <div class="clear"></div>
            </div>
        </div>

        <div class="box box30">

            <div class="panel_header default">
                <h2>Dados Adicionais</h2>
            </div>

            <div class="panel">
                <div class="post_create_cover m_botton">
                    <div class="upload_progress none">0%</div>
                    <?php
                    $SetupCover = (!empty($setup_img_cover) && file_exists("../uploads/{$setup_img_cover}") && !is_dir("../uploads/{$setup_img_cover}") ? "uploads/{$setup_img_cover}" : 'admin/_img/no_image.jserv');
                    ?>
                    <img class="post_thumb setup_img_cover" alt="Capa" title="Capa" src="../tim.php?src=<?= $SetupCover; ?>&w=<?= IMAGE_W / 3; ?>&h=<?= IMAGE_H / 3; ?>" default="../tim.php?src=<?= $SetupCover; ?>&w=<?= IMAGE_W / 3; ?>&h=<?= IMAGE_H / 3; ?>"/>
                </div>

                <label class="label">
                    <span class="legend">Capa:</span>
                    <input type="file" class="wc_loadimage" name="setup_img_cover"/>
                </label>

                <div class="m_top">&nbsp;</div>
                <div class="wc_actions" style="text-align: center; margin-bottom: 10px;">
                    <label class="label_check label_publish <?= ($setup_img_status == 1 ? 'active' : ''); ?>"><input style="margin-top: -1px;" type="checkbox" value="1" name="setup_img_status" <?= ($setup_img_status == 1 ? 'checked' : ''); ?>> Publicar Agora!</label>
                    <button name="public" value="1" class="btn btn_green icon-share">ATUALIZAR</button>
                    <img class="form_load none" style="margin-left: 10px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                </div>
            </div>
        </div>
    </form>
</div>