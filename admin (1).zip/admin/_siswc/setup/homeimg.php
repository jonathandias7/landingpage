<?php
$AdminLevel = LEVEL_WC_PAGES;
if (!APP_PAGES || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">Imagem</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            Imagem
        </p>
    </div>

    

</header>
<div class="dashboard_content">
    <?php
    $Read->ExeRead("mdp_setup_img");
    if ($Read->getResult()):
      
        foreach ($Read->getResult() as $PAGE):
            extract($PAGE);
            $setup_img_status = ($setup_img_status == 1 ? '<span class="icon-checkmark font_green">Publicada</span>' : '<span class="icon-warning font_yellow">Rascunho</span>');
            $setup_img_cover = (!empty($setup_img_cover) ? BASE . "/tim.php?src=uploads/{$setup_img_cover}&w=" . IMAGE_W / 4 . "&h=" . IMAGE_H / 4 . "" : "");

            echo "<article class='box box25 page_single wc_draganddrop' callback='MDPSetup' callback_action='setup_order' id='{$setup_img_id}'>
                <a title='Ver página no site' target='_blank' href='" . BASE . "/{$setup_img_name}'><img alt='' title='' src='{$setup_img_cover}'/></a>
                <div class='box_content wc_normalize_height'>
                    <h1 class='title'><a title='Ver página no site' target='_blank' href='" . BASE . "/{$setup_img_name}'>/{$setup_img_title}</a></h1>
                    <p>{$setup_img_status}</p>
                </div>
                <div class='page_single_action'>
                    <a title='Editar Serviço' href='dashboard.php?wc=setup/createimg&id={$setup_img_id}' class='post_single_center icon-pencil btn btn_blue'>Editar</a>
                    <span rel='setup_img_single' class='j_delete_action icon-cancel-circle btn btn_red' id='{$setup_img_id}'>Excluir</span>
                    <span rel='setup_img_single' callback='MDPSetup' callback_action='delete' class='j_delete_action_confirm icon-warning btn btn_yellow' style='display: none' id='{$setup_img_id}'>Deletar Serviço?</span>
                </div>
            </article>";
        endforeach;

     
    endif;
    ?>
</div>