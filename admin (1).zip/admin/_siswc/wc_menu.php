
<?php
// SETOR ADMINISTRATIVO
if ($_SESSION['userLogin']['user_level'] >= 9): ?>
<!--<li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpcustom/') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-droplet">Customizações</a>
    <ul class="dashboard_nav_menu_sub">
        <li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpcustom/create') ? 'dashboard_nav_menu_sub_li_active' : ''; ?>"><a  title="Variação do produto" href="dashboard.php?wc=mdpcustom/create">&raquo;Customizar</a></li>
        <li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpdep/home') ? 'dashboard_nav_menu_sub_li_active' : ''; ?>"><a class="icon-folder-open" title="Variação do produto" href="dashboard.php?wc=mdpdep/home">Minhas contas</a></li>
    </ul>
</li>-->
<?php
endif;
 if (APP_ACTIVEPAGES && $Admin['user_level'] >= LEVEL_WC_ACTIVEPAGES): ?>
    <li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'activepages/') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-profile" title="Active Pages" href="dashboard.php?wc=activepages/home">Active Pages</a>
        <ul class="dashboard_nav_menu_sub">
            <li class="dashboard_nav_menu_sub_li <?= $getViewInput == 'activepages/pages' ? 'dashboard_nav_menu_active' : ''; ?>"><a title="Ver Active Pages" href="dashboard.php?wc=activepages/home">&raquo; Ver Active Pages</a></li>
            <li class="dashboard_nav_menu_sub_li <?= $getViewInput == 'activepages/create' ? 'dashboard_nav_menu_active' : ''; ?>"><a title="Nova Active Page" href="dashboard.php?wc=activepages/create">&raquo; Nova Active Page</a></li>
        </ul>
    </li>
    <link rel="stylesheet" href="_siswc/activepages/css/style.css"/>
<?php endif; ?>