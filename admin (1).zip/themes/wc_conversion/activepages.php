<?php

echo '<div class="wc_ativepages">';
require '_activepages/index.php';
echo '</div>';


