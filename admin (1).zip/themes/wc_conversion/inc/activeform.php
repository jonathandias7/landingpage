<form method="POST" target="_blank" action="https://upinside.activehosted.com/proc.php" id="_form_334_">
    <input type="hidden" name="u" value="334" />
    <input type="hidden" name="f" value="334" />
    <input type="hidden" name="s" />
    <input type="hidden" name="c" value="0" />
    <input type="hidden" name="m" value="0" />
    <input type="hidden" name="act" value="sub" />
    <input type="hidden" name="v" value="2" />
    <input type='email' class="email" placeholder="Insira seu E-mail" name='email'
           required /><button id="_form_334_submit" class="_submit" type="submit"><?= (empty($AC_BUTTON) ? 'QUERO RECEBER!' : $AC_BUTTON); ?></button>
</form>