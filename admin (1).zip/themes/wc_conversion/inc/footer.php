<footer class="main_footer">
    <div class="wc_privacity">
        <div class="content">
        
            <div class="copy">
            
				<a  href="<?= BASE; ?>" title="<?= SITE_NAME; ?> - <?= SITE_SUBNAME; ?>">
            <img style='' class="main_logo" src="<?= INCLUDE_PATH; ?>/images/logo.png" alt="<?= SITE_NAME; ?> - <?= SITE_SUBNAME; ?>" title="<?= SITE_NAME; ?> - <?= SITE_SUBNAME; ?>"/>
				</a><br/><br/>
                Copyright © <?= date('Y'); ?> <?= SITE_NAME; ?> - Todos os direitos reservados.
            </div>
            <div class="clear"></div>
        </div>
    </div>
</footer>