<ul class="main_nav_menu jwc_menu">
    <li><a title="<?= SITE_NAME; ?> | Home" href="<?= BASE;?>">Home</a></li>
    <li><a class="wc_goto" title="<?= SITE_NAME; ?> | Sobre" href="#a">Sobre</a></li>
    <li><a class="wc_goto" title="<?= SITE_NAME; ?> | Últimas" href="#b">Últimas</a></li>
    <li><a class="wc_goto" title="<?= SITE_NAME; ?> | Veja Mais" href="#c">Veja Mais</a></li>
</ul>